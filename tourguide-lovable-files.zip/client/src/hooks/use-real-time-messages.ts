import { useState, useEffect, useCallback } from 'react';
import { useWebSocket } from './use-websocket';
import type { ChatMessage } from '@shared/schema';

interface UseRealTimeMessagesOptions {
  sessionId: number;
  userId: string;
  enabled?: boolean;
}

interface UseRealTimeMessagesReturn {
  messages: ChatMessage[];
  sendMessage: (content: string, messageType?: string, metadata?: any) => Promise<void>;
  isLoading: boolean;
  isConnected: boolean;
}

export function useRealTimeMessages({
  sessionId,
  userId,
  enabled = true
}: UseRealTimeMessagesOptions): UseRealTimeMessagesReturn {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load initial messages once
  useEffect(() => {
    if (!sessionId || !enabled) return;
    
    const loadMessages = async () => {
      try {
        const response = await fetch(`/api/chat-sessions/${sessionId}/messages?userId=${userId}`);
        if (response.ok) {
          const data = await response.json();
          setMessages(data);
        }
      } catch (error) {
        console.error('Failed to load messages:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadMessages();
  }, [sessionId, userId, enabled]);

  // Real-time WebSocket communication
  const { sendMessage: sendWebSocketMessage, isConnected } = useWebSocket(sessionId, {
    onMessage: (data: any) => {
      if (data.type === 'chat_message' && data.sessionId === sessionId) {
        const newMessage: ChatMessage = {
          id: data.messageId,
          sessionId: data.sessionId,
          senderType: data.senderType,
          senderId: data.senderId,
          content: data.content,
          messageType: data.messageType || 'text',
          metadata: data.metadata || null,
          deletedBy: [],
          isRead: false,
          readBy: [],
          createdAt: data.timestamp || new Date().toISOString()
        };
        
        setMessages(prev => {
          // Prevent duplicate messages
          if (prev.some(msg => msg.id === newMessage.id)) return prev;
          return [...prev, newMessage];
        });
      }
    }
  });

  // Send message function with optimistic updates
  const sendMessage = useCallback(async (
    content: string, 
    messageType: string = 'text', 
    metadata?: any
  ): Promise<void> => {
    if (!content.trim()) return;

    try {
      // Send to server
      const response = await fetch(`/api/chat-sessions/${sessionId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          content: content.trim(),
          messageType,
          senderType: userId.startsWith('tourist_') ? 'user' : 'guide',
          senderId: userId,
          metadata
        })
      });
      
      if (response.ok) {
        const savedMessage = await response.json();
        
        // Add to local state immediately (optimistic update)
        setMessages(prev => {
          if (prev.some(msg => msg.id === savedMessage.id)) return prev;
          return [...prev, savedMessage];
        });
        
        // Broadcast via WebSocket for real-time updates to other users
        sendWebSocketMessage({
          type: "chat_message",
          sessionId,
          messageId: savedMessage.id,
          content: content.trim(),
          messageType,
          senderType: savedMessage.senderType,
          senderId: userId,
          metadata,
          timestamp: savedMessage.createdAt
        });
      } else {
        throw new Error('Failed to send message');
      }
    } catch (error) {
      console.error('Failed to send message:', error);
      throw error;
    }
  }, [sessionId, userId, sendWebSocketMessage]);

  return {
    messages,
    sendMessage,
    isLoading,
    isConnected
  };
}