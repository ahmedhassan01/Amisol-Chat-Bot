import { useEffect, useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';

interface UseBrowserNotificationsOptions {
  onNewMessage?: (data: any) => void;
}

export function useBrowserNotifications({ onNewMessage }: UseBrowserNotificationsOptions = {}) {
  const { toast } = useToast();

  // Request notification permission
  const requestPermission = useCallback(async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      return permission === 'granted';
    }
    return false;
  }, []);

  // Show browser notification
  const showBrowserNotification = useCallback((title: string, body: string, icon?: string) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      const notification = new Notification(title, {
        body,
        icon: icon || '/favicon.ico',
        badge: '/favicon.ico',
        tag: 'tourguide-chat',
        requireInteraction: false,
        silent: false
      });

      // Auto close after 5 seconds
      setTimeout(() => {
        notification.close();
      }, 5000);

      return notification;
    }
    return null;
  }, []);

  // Show both browser and toast notification
  const showNotification = useCallback((title: string, description: string) => {
    // Show toast notification
    toast({
      title,
      description,
      duration: 4000,
    });

    // Show browser notification if permitted
    showBrowserNotification(title, description);
  }, [toast, showBrowserNotification]);

  // Initialize notifications and request permission on first use
  useEffect(() => {
    requestPermission();
  }, [requestPermission]);

  return {
    showNotification,
    showBrowserNotification,
    requestPermission,
    isSupported: 'Notification' in window,
    permission: 'Notification' in window ? Notification.permission : 'denied'
  };
}