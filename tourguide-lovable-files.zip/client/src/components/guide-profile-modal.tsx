import { useState } from "react";
import React from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User, Mail, Phone, Languages, Star, MapPin, Upload, Camera } from "lucide-react";
import type { Guide } from "@shared/schema";

const guideProfileSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email("Invalid email"),
  phone: z.string().optional(),
  specialties: z.string().optional(),
  languages: z.string().optional(),
  profileImage: z.string().optional(),
});

interface GuideProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  guideId: number;
}

export default function GuideProfileModal({ isOpen, onClose, guideId }: GuideProfileModalProps) {
  const { toast } = useToast();
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const { data: guide, isLoading } = useQuery<Guide>({
    queryKey: ["/api/guides", guideId],
    enabled: isOpen && !!guideId,
  });

  const updateGuideMutation = useMutation({
    mutationFn: async (data: any) => {
      let profileImageUrl = data.profileImage;
      
      // Upload image if selected
      if (selectedImage) {
        const formData = new FormData();
        formData.append('file', selectedImage);
        
        const uploadResponse = await fetch('/api/upload', {
          method: 'POST',
          body: formData,
        });
        
        if (uploadResponse.ok) {
          const uploadResult = await uploadResponse.json();
          profileImageUrl = uploadResult.url;
        }
      }
      
      const response = await fetch(`/api/guides/${guideId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...data,
          profileImage: profileImageUrl,
          specialties: data.specialties ? data.specialties.split(",").map((s: string) => s.trim()) : [],
          languages: data.languages ? data.languages.split(",").map((l: string) => l.trim()) : [],
        }),
      });
      if (!response.ok) throw new Error("Failed to update profile");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/guides"] });
      queryClient.invalidateQueries({ queryKey: ["/api/guides", guideId] });
      onClose();
      toast({ title: "Profile updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update profile", variant: "destructive" });
    },
  });

  const form = useForm({
    resolver: zodResolver(guideProfileSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      specialties: "",
      languages: "",
      profileImage: "",
    },
  });

  // Update form when guide data is loaded
  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setSelectedImage(file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  React.useEffect(() => {
    if (guide) {
      form.reset({
        name: guide.name || "",
        email: guide.email || "",
        phone: guide.phone || "",
        specialties: guide.specialties ? guide.specialties.join(", ") : "",
        languages: guide.languages ? guide.languages.join(", ") : "",
        profileImage: guide.profileImage || "",
      });
      setImagePreview(guide.profileImage || null);
      setSelectedImage(null);
    }
  }, [guide, form]);

  if (isLoading) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent>
          <div className="flex items-center justify-center p-6">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-travel-blue"></div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader className="pb-2">
          <DialogTitle className="text-lg">Update Profile</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          {/* Compact Profile Header */}
          <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded">
            <div className="relative">
              <Avatar className="w-12 h-12">
                <AvatarImage src={imagePreview || guide?.profileImage || undefined} />
                <AvatarFallback className="text-sm">{guide?.name?.[0]}</AvatarFallback>
              </Avatar>
              <label className="absolute -bottom-1 -right-1 w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center cursor-pointer hover:bg-blue-700 transition-colors shadow-lg border-2 border-white">
                <Camera className="w-3 h-3 text-white" />
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="hidden"
                />
              </label>
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-medium truncate">{guide?.name}</h3>
              <div className="flex items-center space-x-3 text-xs text-gray-600">
                <span>⭐ {guide?.rating || "0"}</span>
                <span>{guide?.totalHelped || 0} helped</span>
                <Badge variant={guide?.isActive ? "default" : "secondary"} className="text-xs px-1 py-0">
                  {guide?.isActive ? "Active" : "Inactive"}
                </Badge>
              </div>
              <p className="text-xs text-blue-600 mt-1">📷 Click camera icon to upload photo</p>
            </div>
          </div>

          {/* Edit Form */}
          <Form {...form}>
            <form onSubmit={form.handleSubmit((data) => updateGuideMutation.mutate(data))} className="space-y-4">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Name</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input type="email" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone</FormLabel>
                    <FormControl>
                      <Input {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="specialties"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Specialties (comma separated)</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="e.g., Historical Tours, Adventure Tours, Medical Assistance" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="languages"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Languages (comma separated)</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="e.g., English, Arabic, German" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              {/* Photo Upload Status */}
              {selectedImage && (
                <div className="text-sm text-green-600 bg-green-50 p-3 rounded-lg border border-green-200">
                  ✓ New photo ready to upload: {selectedImage.name}
                </div>
              )}
              
              {!selectedImage && (
                <div className="text-sm text-gray-500 bg-gray-50 p-3 rounded-lg text-center">
                  Click the camera icon on your avatar above to upload a new profile photo
                </div>
              )}
              
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button type="submit" disabled={updateGuideMutation.isPending}>
                  {updateGuideMutation.isPending ? "Updating..." : "Update Profile"}
                </Button>
              </div>
            </form>
          </Form>
        </div>
      </DialogContent>
    </Dialog>
  );
}