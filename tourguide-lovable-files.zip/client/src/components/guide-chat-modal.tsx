import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useBrowserNotifications } from "@/hooks/use-browser-notifications";
import { useRealTimeMessages } from "@/hooks/use-real-time-messages";
import { queryClient } from "@/lib/queryClient";
import { Send, Paperclip, Mic, Phone, MessageSquare, X } from "lucide-react";
import VoiceRecordingModal from "./voice-recording-modal";
import type { ChatSession, Guide, ChatMessage } from "@shared/schema";

interface GuideChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  chatSession: ChatSession;
  currentGuide: Guide;
}

export default function GuideChatModal({ 
  isOpen, 
  onClose, 
  chatSession, 
  currentGuide 
}: GuideChatModalProps) {
  const [message, setMessage] = useState("");
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const { showNotification } = useBrowserNotifications();

  // Real-time messaging with persistent state
  const { 
    messages, 
    sendMessage: sendRealTimeMessage, 
    isLoading: isLoadingMessages, 
    isConnected 
  } = useRealTimeMessages({
    sessionId: chatSession.id,
    userId: currentGuide.id.toString(),
    enabled: isOpen
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Auto-mark messages as read when opening chat modal
  useEffect(() => {
    if (isOpen && chatSession && messages.length > 0) {
      // Mark unread tourist messages as read
      const unreadTouristMessages = messages.filter(msg => 
        msg.senderType === 'user' && 
        !(msg.readBy || []).includes(currentGuide.id.toString())
      );
      
      if (unreadTouristMessages.length > 0) {
        // Mark the entire session as read
        fetch(`/api/chat-sessions/${chatSession.id}/mark-read`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: currentGuide.id.toString() }),
        }).then(() => {
          // Invalidate all unread count caches
          queryClient.invalidateQueries({ queryKey: ["/api/guide-unread-counts"] });
          queryClient.invalidateQueries({ queryKey: ["/api/chat-sessions/unread-counts"] });
          queryClient.invalidateQueries({ queryKey: ["/api/chat-sessions"] });
        }).catch(console.error);
      }
    }
  }, [isOpen, chatSession, messages, currentGuide]);

  // Send text message handler
  const handleSendMessage = async () => {
    if (!message.trim()) return;
    
    try {
      await sendRealTimeMessage(message.trim(), "text");
      setMessage("");
      setTimeout(() => scrollToBottom(), 100);
      showNotification("Message sent", "Your reply has been sent to the tourist");
    } catch (error) {
      toast({
        title: "Failed to send message",
        description: "Please try again.",
        variant: "destructive",
      });
    }
  };

  // Voice message handler
  const handleVoiceMessage = async (audioBlob: Blob) => {
    try {
      await sendRealTimeMessage("Voice message sent", "voice", { duration: "0:05" });
      setIsVoiceModalOpen(false);
      showNotification("Voice message sent", "Your voice message has been sent to the tourist");
    } catch (error) {
      toast({
        title: "Failed to send voice message",
        description: "Please try again.",
        variant: "destructive",
      });
    }
  };

  // File upload handler
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        const result = await response.json();
        await sendRealTimeMessage(`File uploaded: ${file.name}`, "file", { 
          fileName: file.name,
          fileUrl: result.url,
          fileSize: file.size
        });
        toast({
          title: "File uploaded",
          description: `${file.name} has been sent`
        });
      }
    } catch (error) {
      toast({
        title: "Failed to upload file",
        description: "Please try again.",
        variant: "destructive",
      });
    }

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTime = (dateString: string | Date) => {
    const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
    return date.toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const getTouristId = () => {
    const touristMessage = messages.find(msg => msg.senderType === 'user');
    return touristMessage?.senderId || 'tourist_unknown';
  };

  if (!isOpen) return null;

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl max-h-[85vh] md:max-h-[80vh] p-0 w-[95vw] md:w-auto">
          <DialogHeader className="p-3 md:p-4 border-b">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 md:gap-3 min-w-0">
                <MessageSquare className="h-4 w-4 md:h-5 md:w-5 text-blue-600 flex-shrink-0" />
                <div className="min-w-0">
                  <DialogTitle className="text-sm md:text-lg truncate">
                    Chat - {chatSession.category.replace('-', ' ').toUpperCase()}
                  </DialogTitle>
                  <p className="text-xs md:text-sm text-gray-600 truncate">
                    Tourist: {getTouristId().slice(-8)} • Guide: {currentGuide.name}
                    {!isConnected && (
                      <Badge variant="outline" className="ml-1 md:ml-2 text-orange-600 text-xs">
                        Reconnecting...
                      </Badge>
                    )}
                  </p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={onClose} className="h-8 w-8 md:h-9 md:w-9 p-0 flex-shrink-0">
                <X className="h-3 w-3 md:h-4 md:w-4" />
              </Button>
            </div>
          </DialogHeader>

          <div className="flex flex-col h-[65vh] md:h-[60vh]">
            {/* Messages Area */}
            <ScrollArea className="flex-1 p-2 md:p-4">
              {isLoadingMessages ? (
                <div className="text-center py-8 text-gray-500">
                  <div className="animate-pulse">Loading messages...</div>
                </div>
              ) : messages.length === 0 ? (
                <div className="text-center py-8 px-4">
                  <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 md:p-6">
                    <MessageSquare className="h-8 w-8 md:h-12 md:w-12 text-green-600 mx-auto mb-3" />
                    <h3 className="font-medium text-sm md:text-lg text-gray-900 dark:text-gray-100 mb-2">
                      New Tourist Chat
                    </h3>
                    <p className="text-xs md:text-sm text-gray-600 dark:text-gray-400 max-w-xs mx-auto">
                      Waiting for the tourist to start the conversation. You'll be notified when they send a message.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-3 md:space-y-4">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${
                        msg.senderType === "guide" ? "justify-end" : "justify-start"
                      }`}
                    >
                      <div
                        className={`max-w-[85%] md:max-w-[70%] rounded-lg p-2 md:p-3 ${
                          msg.senderType === "guide"
                            ? "bg-blue-600 text-white"
                            : "bg-gray-100 dark:bg-gray-700"
                        }`}
                      >
                        <div className="font-medium text-xs md:text-sm mb-1">
                          {msg.senderType === "guide" ? currentGuide.name : "Tourist"}
                        </div>
                        <div className="text-sm md:text-base break-words">{String(msg.content)}</div>
                        {msg.messageType === "voice" && (
                          <div className="flex items-center gap-2 mt-2">
                            <Mic className="h-3 w-3 md:h-4 md:w-4" />
                            <span className="text-xs">Voice message</span>
                          </div>
                        )}
                        {msg.messageType === "file" && msg.metadata && (
                          <div className="flex items-center gap-2 mt-2">
                            <Paperclip className="h-3 w-3 md:h-4 md:w-4" />
                            <span className="text-xs truncate">
                              {typeof msg.metadata === 'object' && msg.metadata !== null && 'fileName' in msg.metadata 
                                ? (msg.metadata as any).fileName 
                                : 'File attachment'}
                            </span>
                          </div>
                        )}
                        <div className="text-xs opacity-70 mt-1">
                          {formatTime(msg.createdAt)}
                        </div>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </ScrollArea>

            {/* Input Area */}
            <div className="border-t p-2 md:p-4 bg-gray-50 dark:bg-gray-900">
              <div className="flex items-center gap-1 md:gap-2">
                <Input
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Type your reply..."
                  className="flex-1 text-sm md:text-base h-9 md:h-10"
                />
                
                <input
                  ref={fileInputRef}
                  type="file"
                  onChange={handleFileUpload}
                  className="hidden"
                  accept="image/*,application/pdf,.doc,.docx"
                />
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  className="h-9 w-9 md:h-10 md:w-10 p-0"
                  disabled={isLoadingMessages}
                >
                  <Paperclip className="h-3 w-3 md:h-4 md:w-4" />
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsVoiceModalOpen(true)}
                  className="h-9 w-9 md:h-10 md:w-10 p-0"
                  disabled={isLoadingMessages}
                >
                  <Mic className="h-3 w-3 md:h-4 md:w-4" />
                </Button>
                
                <Button 
                  onClick={handleSendMessage} 
                  disabled={!message.trim() || isLoadingMessages}
                  className="h-9 w-9 md:h-10 md:w-auto md:px-3"
                >
                  <Send className="h-3 w-3 md:h-4 md:w-4" />
                </Button>
              </div>
              
              {/* Empty message warning */}
              {message.length > 0 && !message.trim() && (
                <p className="text-xs text-orange-600 mt-1 px-1">
                  Message cannot be empty or contain only spaces
                </p>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <VoiceRecordingModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        onSendVoice={handleVoiceMessage}
      />
    </>
  );
}