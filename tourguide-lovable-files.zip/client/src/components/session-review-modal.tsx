import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Star, ThumbsUp, Clock, UserCheck } from "lucide-react";

interface SessionReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  sessionId: number;
  guideId: number;
  guideName: string;
  touristId: string;
}

export default function SessionReviewModal({
  isOpen,
  onClose,
  sessionId,
  guideId,
  guideName,
  touristId,
}: SessionReviewModalProps) {
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [helpfulness, setHelpfulness] = useState(5);
  const [responsiveness, setResponsiveness] = useState(5);
  const [professionalism, setProfessionalism] = useState(5);
  const [wouldRecommend, setWouldRecommend] = useState(true);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const submitReviewMutation = useMutation({
    mutationFn: async (reviewData: any) => {
      const response = await fetch("/api/session-reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(reviewData),
      });
      if (!response.ok) throw new Error("Failed to submit review");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Review Submitted",
        description: "Thank you for your feedback! Your review helps us improve our service.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/guides"] });
      onClose();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit review. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = () => {
    const reviewData = {
      sessionId,
      guideId,
      touristId,
      rating,
      comment: comment.trim() || null,
      helpfulness,
      responsiveness,
      professionalism,
      wouldRecommend,
    };

    submitReviewMutation.mutate(reviewData);
  };

  const renderStarRating = (value: number, onChange: (value: number) => void, label: string, icon: any) => {
    const Icon = icon;
    return (
      <div className="space-y-2">
        <div className="flex items-center space-x-2">
          <Icon size={18} className="text-blue-600" />
          <span className="text-sm font-medium text-gray-700">{label}</span>
        </div>
        <div className="flex space-x-1">
          {[1, 2, 3, 4, 5].map((star) => (
            <button
              key={star}
              type="button"
              onClick={() => onChange(star)}
              className="focus:outline-none"
            >
              <Star
                size={24}
                className={`${
                  star <= value
                    ? "text-yellow-400 fill-yellow-400"
                    : "text-gray-300"
                } hover:text-yellow-400 transition-colors`}
              />
            </button>
          ))}
        </div>
      </div>
    );
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-sm max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold text-center">
            Rate {guideName}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {/* Overall Rating */}
          {renderStarRating(rating, setRating, "Overall", Star)}

          {/* Simplified Detailed Ratings */}
          <div className="grid grid-cols-1 gap-3">
            {renderStarRating(helpfulness, setHelpfulness, "Helpful", ThumbsUp)}
            {renderStarRating(responsiveness, setResponsiveness, "Quick", Clock)}
          </div>

          {/* Recommendation */}
          <div className="space-y-1">
            <span className="text-sm font-medium text-gray-700">Recommend?</span>
            <div className="flex space-x-4">
              <label className="flex items-center">
                <input
                  type="radio"
                  checked={wouldRecommend === true}
                  onChange={() => setWouldRecommend(true)}
                  className="mr-2 text-blue-600"
                />
                <span className="text-sm">Yes</span>
              </label>
              <label className="flex items-center">
                <input
                  type="radio"
                  checked={wouldRecommend === false}
                  onChange={() => setWouldRecommend(false)}
                  className="mr-2 text-blue-600"
                />
                <span className="text-sm">No</span>
              </label>
            </div>
          </div>

          {/* Comments */}
          <div className="space-y-1">
            <label className="text-sm font-medium text-gray-700">
              Comments (Optional)
            </label>
            <Textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Your feedback..."
              className="min-h-[50px] resize-none text-sm"
              maxLength={200}
            />
            <div className="text-xs text-gray-500 text-right">
              {comment.length}/200
            </div>
          </div>
        </div>

        <div className="flex space-x-3 pt-4">
          <Button
            variant="outline"
            onClick={onClose}
            className="flex-1"
            disabled={submitReviewMutation.isPending}
          >
            Maybe Later
          </Button>
          <Button
            onClick={handleSubmit}
            className="flex-1 bg-blue-600 hover:bg-blue-700"
            disabled={submitReviewMutation.isPending}
          >
            {submitReviewMutation.isPending ? "Submitting..." : "Submit Review"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}