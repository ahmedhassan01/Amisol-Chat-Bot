import { useState, useEffect } from "react";
import { Mic, Square, X } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface VoiceRecordingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSendVoice: (audioBlob: Blob) => void;
}

export default function VoiceRecordingModal({ 
  isOpen, 
  onClose, 
  onSendVoice 
}: VoiceRecordingModalProps) {
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [audioChunks, setAudioChunks] = useState<Blob[]>([]);
  const [recordingTime, setRecordingTime] = useState(0);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isRecording]);

  useEffect(() => {
    if (isOpen && !isRecording) {
      startRecording();
    }
  }, [isOpen]);

  const startRecording = async () => {
    try {
      setError(null);
      setRecordingTime(0);
      setAudioChunks([]);

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      
      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          setAudioChunks(prev => [...prev, event.data]);
        }
      };
      
      recorder.onstop = () => {
        stream.getTracks().forEach(track => track.stop());
      };
      
      setMediaRecorder(recorder);
      recorder.start();
      setIsRecording(true);
    } catch (err) {
      setError("Unable to access microphone. Please check your permissions.");
      console.error("Error starting recording:", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      setIsRecording(false);
    }
  };

  const handleSend = () => {
    if (audioChunks.length > 0) {
      const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });
      onSendVoice(audioBlob);
    }
    handleClose();
  };

  const handleClose = () => {
    if (isRecording) {
      stopRecording();
    }
    setRecordingTime(0);
    setAudioChunks([]);
    setError(null);
    onClose();
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <div className="text-center p-6">
          {error ? (
            <div className="space-y-4">
              <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <X className="text-red-500" size={32} />
              </div>
              <h3 className="text-lg font-semibold text-gray-900">Recording Failed</h3>
              <p className="text-sm text-gray-600">{error}</p>
              <Button onClick={handleClose} variant="outline">
                Close
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className={`w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 ${
                isRecording ? 'bg-red-100 animate-pulse' : 'bg-gray-100'
              }`}>
                <Mic className={`${isRecording ? 'text-red-500' : 'text-gray-500'}`} size={32} />
              </div>
              
              <h3 className="text-lg font-semibold text-gray-900">
                {isRecording ? 'Recording Voice Message' : 'Preparing Recording'}
              </h3>
              
              <p className="text-sm text-gray-600">
                {isRecording ? 'Speak clearly into your microphone' : 'Getting ready to record...'}
              </p>
              
              {isRecording && (
                <div className="text-2xl font-mono text-travel-blue">
                  {formatTime(recordingTime)}
                </div>
              )}
              
              <div className="flex items-center justify-center space-x-4 pt-4">
                <Button 
                  onClick={handleClose} 
                  variant="outline"
                >
                  Cancel
                </Button>
                
                {isRecording ? (
                  <Button 
                    onClick={stopRecording}
                    className="bg-red-500 hover:bg-red-600 text-white"
                  >
                    <Square className="mr-2" size={16} />
                    Stop Recording
                  </Button>
                ) : audioChunks.length > 0 ? (
                  <Button 
                    onClick={handleSend}
                    className="bg-travel-blue hover:bg-blue-700"
                  >
                    Send Voice Message
                  </Button>
                ) : null}
              </div>
              
              {!isRecording && audioChunks.length > 0 && (
                <p className="text-xs text-gray-500">
                  Recording completed • Duration: {formatTime(recordingTime)}
                </p>
              )}
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
