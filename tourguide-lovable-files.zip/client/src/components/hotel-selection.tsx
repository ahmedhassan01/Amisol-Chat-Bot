import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Building2, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import type { Hotel } from "@shared/schema";

interface HotelSelectionProps {
  selectedCategory: string;
  onHotelSelected: (hotel: Hotel, sessionData: any) => void;
  onBack: () => void;
}

export default function HotelSelection({ selectedCategory, onHotelSelected, onBack }: HotelSelectionProps) {
  const [selectedHotel, setSelectedHotel] = useState<Hotel | null>(null);
  const { toast } = useToast();

  // Get tourist ID
  const getTouristId = () => {
    let touristId = localStorage.getItem('touristId');
    if (!touristId) {
      touristId = `tourist_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem('touristId', touristId);
    }
    return touristId;
  };

  // Fetch hotels
  const { data: hotels = [], isLoading } = useQuery<Hotel[]>({
    queryKey: ["/api/hotels"],
    queryFn: async () => {
      const response = await fetch("/api/hotels");
      if (!response.ok) throw new Error("Failed to fetch hotels");
      return response.json();
    },
  });

  // Create chat session with hotel assignment
  const createSessionMutation = useMutation({
    mutationFn: async (hotel: Hotel) => {
      const response = await fetch("/api/chat-sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          category: selectedCategory, 
          hotelId: hotel.id,
          isActive: true,
          userId: getTouristId()
        }),
      });
      if (!response.ok) throw new Error("Failed to create session");
      return response.json();
    },
    onSuccess: async (session, hotel) => {
      // Send automatic welcome message to notify the guide
      const categoryMessages: Record<string, string> = {
        "hotel-change": "Hi! I need help with changing my hotel. Can you assist me with the process?",
        "hotel-complain": "Hello, I have a complaint about my hotel that I'd like to discuss with you.",
        "booking-tours": "Hi! I'm interested in booking tours. What options do you have available?",
        "medical": "Hello, I need medical assistance. Can you help me?",
        "general": "Hi! I need some general assistance. Can you help me?"
      };

      const welcomeMessage = categoryMessages[selectedCategory] || "Hello! I need assistance.";
      
      try {
        const response = await fetch(`/api/chat-sessions/${session.id}/messages`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            content: welcomeMessage,
            messageType: "text",
            senderType: "user",
            senderId: getTouristId()
          }),
        });
        
        if (response.ok) {
          console.log("Welcome message sent successfully");
        }
      } catch (error) {
        console.error("Failed to send welcome message:", error);
      }

      onHotelSelected(hotel, session);
      toast({ 
        title: `Connected to ${hotel.name}`, 
        description: "Your assigned guide will assist you shortly." 
      });
    },
    onError: () => {
      toast({ 
        title: "Connection failed", 
        description: "Please try again.", 
        variant: "destructive" 
      });
    },
  });

  const handleHotelSelect = (hotel: Hotel) => {
    setSelectedHotel(hotel);
    createSessionMutation.mutate(hotel);
  };

  const getCategoryTitle = (category: string) => {
    const categoryMap: Record<string, string> = {
      "hotel-change": "Hotel Change",
      "hotel-complain": "Hotel Complaint", 
      "booking-tours": "Booking Tours",
      "medical-assistance": "Medical Assistance",
      "guide-assistance": "Guide Assistance"
    };
    return categoryMap[category] || category;
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 h-full">
        <div className="p-4 border-b border-gray-200">
          <h2 className="text-base font-semibold text-gray-900">Select Your Hotel</h2>
        </div>
        <div className="p-4 flex items-center justify-center">
          <div className="text-sm text-gray-500">Loading hotels...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 h-full">
      <div className="p-3 sm:p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-sm sm:text-base font-semibold text-gray-900">Select Your Hotel</h2>
            <p className="text-xs text-gray-600">For: {getCategoryTitle(selectedCategory)}</p>
          </div>
          <Button variant="ghost" size="sm" onClick={onBack} className="text-xs sm:text-sm">
            Back
          </Button>
        </div>
      </div>
      
      <div className="p-2 sm:p-4 space-y-2 sm:space-y-3 max-h-[calc(100vh-200px)] overflow-y-auto">
        {hotels.filter(hotel => hotel.isActive).map((hotel) => (
          <Card 
            key={hotel.id}
            className={cn(
              "p-3 sm:p-4 cursor-pointer transition-all border-2 hover:border-travel-blue hover:bg-blue-50 touch-manipulation active:scale-98",
              selectedHotel?.id === hotel.id ? "border-travel-blue bg-blue-50" : "border-gray-200"
            )}
            onClick={() => handleHotelSelect(hotel)}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2 sm:space-x-3 flex-1 min-w-0">
                <div className="w-8 h-8 sm:w-10 sm:h-10 bg-travel-blue bg-opacity-10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Building2 size={16} className="text-travel-blue sm:w-5 sm:h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm sm:text-base font-semibold text-gray-900 truncate">{hotel.name}</h3>
                  <p className="text-xs sm:text-sm text-gray-600 truncate">{hotel.address}</p>
                  {hotel.phone && (
                    <p className="text-xs text-gray-500 hidden sm:block">{hotel.phone}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center flex-shrink-0 ml-2">
                {createSessionMutation.isPending && selectedHotel?.id === hotel.id ? (
                  <div className="text-xs sm:text-sm text-gray-500">Connecting...</div>
                ) : (
                  <ChevronRight size={16} className="text-gray-400 sm:w-5 sm:h-5" />
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>
      
      {hotels.filter(hotel => hotel.isActive).length === 0 && (
        <div className="p-4 text-center">
          <p className="text-sm text-gray-500">No hotels available at the moment.</p>
        </div>
      )}
    </div>
  );
}