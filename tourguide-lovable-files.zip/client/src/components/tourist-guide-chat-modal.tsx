import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle 
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  Star, 
  MapPin, 
  Languages, 
  Clock, 
  Send, 
  Mic, 
  Paperclip, 
  User, 
  Bot,
  Phone,
  MessageCircle,
  X
} from "lucide-react";
import { useWebSocket } from "@/hooks/use-websocket";
import { useToast } from "@/hooks/use-toast";
import { useBrowserNotifications } from "@/hooks/use-browser-notifications";
import { apiRequest, queryClient } from "@/lib/queryClient";
import VoiceRecordingModal from "./voice-recording-modal";
import type { Guide, ChatSession, ChatMessage } from "@shared/schema";

interface TouristGuideChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  guideId: number;
  existingSessionId?: number | null;
}

export default function TouristGuideChatModal({ 
  isOpen, 
  onClose, 
  guideId,
  existingSessionId 
}: TouristGuideChatModalProps) {
  const [message, setMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [currentChatSession, setCurrentChatSession] = useState<ChatSession | null>(null);
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const { showNotification } = useBrowserNotifications();

  // Get or create unique tourist identifier for private messaging
  const getTouristId = () => {
    let touristId = localStorage.getItem('touristId');
    if (!touristId) {
      touristId = `tourist_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem('touristId', touristId);
    }
    return touristId;
  };

  const { data: guide, isLoading: isLoadingGuide } = useQuery<Guide>({
    queryKey: ["/api/guides", guideId],
    enabled: !!guideId && isOpen,
  });

  const { data: messages = [], refetch: refetchMessages } = useQuery<ChatMessage[]>({
    queryKey: [`/api/chat-sessions/${currentChatSession?.id}/messages`, getTouristId()],
    queryFn: async () => {
      const response = await fetch(`/api/chat-sessions/${currentChatSession?.id}/messages?userId=${getTouristId()}`);
      if (!response.ok) throw new Error('Failed to fetch messages');
      return response.json();
    },
    enabled: !!currentChatSession?.id,
    refetchInterval: 2000, // Auto-refresh every 2 seconds
  });

  // Auto-mark messages as read when viewing them (but only show notifications for truly new messages)
  useEffect(() => {
    if (isOpen && currentChatSession && messages.length > 0) {
      // Mark unread guide messages as read
      const unreadGuideMessages = messages.filter(msg => 
        msg.senderType === 'guide' && 
        !(msg.readBy || []).includes(getTouristId())
      );
      
      if (unreadGuideMessages.length > 0) {
        // Only show notification if this is a continuing conversation (tourist has sent messages)
        const touristHasSentMessages = messages.some(msg => 
          msg.senderType === 'user' && 
          msg.senderId === getTouristId()
        );
        
        // Only show notifications for active conversations where tourist has participated
        if (touristHasSentMessages) {
          if (unreadGuideMessages.length === 1) {
            showNotification("New Message from Guide", `${guide?.name} replied to your conversation`);
          } else {
            showNotification("New Messages from Guide", `${guide?.name} sent you ${unreadGuideMessages.length} replies`);
          }
        }
        
        // Mark the entire session as read
        fetch(`/api/chat-sessions/${currentChatSession.id}/mark-read`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: getTouristId() }),
        }).then(() => {
          // Refresh unread counts after marking as read
          queryClient.invalidateQueries({ queryKey: ["/api/chat-sessions/unread-counts"] });
        }).catch(console.error);
      }
    }
  }, [isOpen, currentChatSession, messages, guide]);

  // Disable WebSocket for now to prevent connection issues
  const isConnected = false;

  // Query to find existing chat sessions for this tourist-guide pair
  const { data: allChatSessions = [] } = useQuery<ChatSession[]>({
    queryKey: ["/api/chat-sessions"],
    enabled: isOpen,
  });

  // Load existing session or find one for this tourist-guide pair
  useEffect(() => {
    if (isOpen && guideId) {
      // Refresh unread counts when chat opens
      queryClient.invalidateQueries({ queryKey: ["/api/chat-sessions/unread-counts"] });
      
      // If we have an existing session ID (from reply button), use that directly
      if (existingSessionId && allChatSessions.length > 0) {
        const session = allChatSessions.find((session: any) => session.id === existingSessionId);
        if (session) {
          setCurrentChatSession(session);
          return;
        }
      }
      
      // Otherwise, find existing session between this tourist and guide
      if (allChatSessions.length > 0) {
        const touristId = getTouristId();
        const existingSession = allChatSessions.find((session: any) => 
          session.guideId === guideId && 
          session.touristId === touristId && 
          session.category === "direct-guide-chat" &&
          session.isActive
        );
        
        if (existingSession) {
          setCurrentChatSession(existingSession);
        }
      }
    }
  }, [isOpen, guideId, existingSessionId, allChatSessions]);

  // Create private chat session for this specific tourist
  const createSessionMutation = useMutation({
    mutationFn: async () => {
      const touristId = getTouristId();
      const response = await fetch("/api/chat-sessions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          category: "direct-guide-chat",
          guideId: guideId,
          isActive: true,
          touristId: touristId
        })
      });
      if (!response.ok) throw new Error("Failed to create session");
      return response.json();
    },
    onSuccess: (session) => {
      setCurrentChatSession(session);
      queryClient.invalidateQueries({ queryKey: ["/api/chat-sessions"] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to start chat session",
        variant: "destructive"
      });
    }
  });

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async ({ content, messageType, metadata }: {
      content: string;
      messageType: string;
      metadata?: any;
    }) => {
      const response = await fetch(`/api/chat-sessions/${currentChatSession?.id}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          content,
          messageType,
          senderType: "user",
          senderId: getTouristId(), // Add tourist ID to messages
          metadata
        })
      });
      if (!response.ok) throw new Error("Failed to send message");
      return response.json();
    },
    onSuccess: () => {
      refetchMessages();
      setMessage("");
      queryClient.invalidateQueries({ queryKey: [`/api/chat-sessions/${currentChatSession?.id}/messages`] });
      // Scroll to bottom after message is sent
      setTimeout(() => scrollToBottom(), 100);
      
      // Show popup notification with browser notification
      showNotification("Message Sent", `Your message was sent to ${guide?.name}`);
    }
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const startChatSession = () => {
    if (!currentChatSession) {
      createSessionMutation.mutate();
    }
  };

  const handleSendMessage = () => {
    if (!message.trim() || !currentChatSession) return;
    
    sendMessageMutation.mutate({
      content: message.trim(),
      messageType: "text",
      metadata: { userEngaged: true }
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleFileUpload = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentChatSession) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });
      const result = await response.json();
      
      if (response.ok) {
        sendMessageMutation.mutate({
          content: `Shared a file: ${file.name}`,
          messageType: "file",
          metadata: { fileUrl: result.url, fileName: file.name }
        });
      }
    } catch (error) {
      console.error("File upload failed:", error);
      toast({
        title: "Upload failed",
        description: "Could not upload file",
        variant: "destructive"
      });
    }
  };

  const handleVoiceMessage = (audioBlob: Blob) => {
    if (!currentChatSession) return;

    // In a real implementation, this would upload the audio and convert to text
    sendMessageMutation.mutate({
      content: "Voice message sent",
      messageType: "voice",
      metadata: { duration: "0:05", userEngaged: true }
    });

    // Show popup notification for voice message with browser notification
    showNotification("Voice Message Sent", `Your voice message was sent to ${guide?.name}`);
  };



  if (isLoadingGuide) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl h-[90vh] flex flex-col p-0">
          <DialogHeader className="p-6 pb-4 border-b border-gray-200">
            <DialogTitle className="text-xl font-semibold">Loading guide...</DialogTitle>
          </DialogHeader>
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-travel-blue mx-auto mb-4"></div>
              <p className="text-gray-600">Loading guide profile...</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  if (!guide) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl h-[90vh] flex flex-col p-0">
          <DialogHeader className="p-6 pb-4 border-b border-gray-200">
            <DialogTitle className="text-xl font-semibold">Guide not found</DialogTitle>
          </DialogHeader>
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <p className="text-gray-600 mb-4">Could not load guide information</p>
              <Button onClick={onClose}>Close</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl h-[90vh] md:h-[85vh] flex flex-col p-0 w-[95vw] md:w-auto">
          <DialogHeader className="p-3 md:p-6 pb-3 md:pb-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <DialogTitle className="text-lg md:text-xl font-semibold truncate pr-2">
                Chat with {guide.name}
              </DialogTitle>
              <Button variant="ghost" size="sm" onClick={onClose} className="flex-shrink-0">
                <X size={16} />
              </Button>
            </div>
          </DialogHeader>

          <div className="flex flex-1 overflow-hidden flex-col md:flex-row">
            {/* Guide Profile Sidebar */}
            <div className="w-full md:w-80 bg-gray-50 border-b md:border-b-0 md:border-r border-gray-200 p-3 md:p-6 overflow-y-auto max-h-40 md:max-h-none">
              <div className="space-y-6">
                {/* Guide Avatar and Basic Info */}
                <div className="text-center">
                  <Avatar className="w-24 h-24 mx-auto mb-4">
                    <AvatarImage src={guide.profileImage || undefined} />
                    <AvatarFallback className="text-xl bg-travel-blue text-white">
                      {guide.name ? guide.name.charAt(0) : 'G'}
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="text-xl font-semibold text-gray-900">{guide.name}</h3>
                  <p className="text-gray-600 mt-1">{guide.email}</p>
                  
                  <div className="flex items-center justify-center mt-3">
                    <div className="w-2 h-2 bg-success-green rounded-full mr-2"></div>
                    <span className="text-sm text-success-green font-medium">Available</span>
                  </div>
                </div>

                {/* Rating */}
                <div className="text-center">
                  <div className="flex items-center justify-center space-x-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        size={16}
                        className={star <= (guide.rating || 4.9) ? "text-yellow-400 fill-current" : "text-gray-300"}
                      />
                    ))}
                    <span className="ml-2 text-sm text-gray-600">
                      {guide.rating || 4.9}/5
                    </span>
                  </div>
                  <p className="text-sm text-gray-500 mt-1">
                    Helped {guide.totalHelped || 150}+ tourists
                  </p>
                </div>

                {/* Contact Info */}
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <Phone size={16} className="text-gray-400" />
                    <span className="text-sm text-gray-600">{guide.phone || "Not available"}</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <MapPin size={16} className="text-gray-400" />
                    <span className="text-sm text-gray-600">Available for tours</span>
                  </div>
                </div>

                {/* Specialties */}
                {guide.specialties && guide.specialties.length > 0 && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2">Specialties</h4>
                    <div className="flex flex-wrap gap-2">
                      {guide.specialties.map((specialty, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {specialty}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Languages */}
                {guide.languages && guide.languages.length > 0 && (
                  <div>
                    <h4 className="font-medium text-gray-900 mb-2 flex items-center">
                      <Languages size={16} className="mr-2" />
                      Languages
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {guide.languages.map((language, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {language}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Start Chat Button */}
                {!currentChatSession && (
                  <Button 
                    onClick={startChatSession}
                    disabled={createSessionMutation.isPending}
                    className="w-full"
                  >
                    <MessageCircle size={16} className="mr-2" />
                    {createSessionMutation.isPending ? "Starting..." : "Start Chat"}
                  </Button>
                )}
              </div>
            </div>

            {/* Chat Interface */}
            <div className="flex-1 flex flex-col">
              {currentChatSession ? (
                <>
                  {/* Chat Header */}
                  <div className="p-4 border-b border-gray-200 bg-gray-50">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold text-gray-900">Chat with {guide.name}</h3>
                        <p className="text-sm text-gray-600">Direct guide assistance</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-gray-600">Live Chat</span>
                      </div>
                    </div>
                  </div>

                  {/* Messages Area */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {messages.length === 0 && (
                      <div className="flex items-start space-x-3">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={guide.profileImage || undefined} />
                          <AvatarFallback className="bg-success-green text-white text-sm">
                            {guide.name ? guide.name.charAt(0) : 'G'}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="bg-gray-100 rounded-lg p-3 max-w-xs">
                            <p className="text-sm text-gray-800">
                              Hello! I'm {guide.name}, your personal guide. How can I help you today?
                            </p>
                          </div>
                          <p className="text-xs text-gray-500 mt-1">{guide.name} • Just now</p>
                        </div>
                      </div>
                    )}

                    {messages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`flex items-start space-x-3 ${
                          msg.senderType === 'user' ? 'justify-end' : ''
                        }`}
                      >
                        {msg.senderType !== 'user' && (
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={guide.profileImage || undefined} />
                            <AvatarFallback className="bg-success-green text-white text-sm">
                              {guide.name ? guide.name.charAt(0) : 'G'}
                            </AvatarFallback>
                          </Avatar>
                        )}
                        
                        <div className={`flex-1 ${msg.senderType === 'user' ? 'flex justify-end' : ''}`}>
                          <div className={`relative group ${msg.senderType === 'user' ? 'flex flex-col items-end' : ''}`}>
                            <div className={`rounded-lg p-3 max-w-sm ${
                              msg.senderType === 'user' 
                                ? 'bg-travel-blue text-white' 
                                : 'bg-gray-100 text-gray-800'
                            }`}>
                              {msg.messageType === 'voice' ? (
                                <div className="flex items-center space-x-2">
                                  <Mic size={16} />
                                  <span className="text-sm">Voice message ({(msg.metadata as any)?.duration || '0:05'})</span>
                                </div>
                              ) : msg.messageType === 'file' ? (
                                <div className="flex items-center space-x-2">
                                  <Paperclip size={16} />
                                  <span className="text-sm">{(msg.metadata as any)?.fileName || 'File attachment'}</span>
                                </div>
                              ) : (
                                <p className="text-sm">{msg.content}</p>
                              )}
                            </div>

                            
                            <div className="flex items-center space-x-2 mt-1">
                              <p className="text-xs text-gray-500">
                                {msg.senderType === 'user' ? 'You' : guide.name}
                              </p>
                              <span className="text-xs text-gray-400">•</span>
                              <p className="text-xs text-gray-500">
                                {new Date(msg.createdAt).toLocaleDateString()} at {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </p>
                              {msg.readBy && msg.readBy.length > 0 && (
                                <span className="text-xs text-green-600">✓ Read</span>
                              )}
                            </div>
                          </div>
                        </div>

                        {msg.senderType === 'user' && (
                          <Avatar className="w-8 h-8">
                            <AvatarFallback className="bg-gray-300 text-gray-600 text-sm">
                              <User size={16} />
                            </AvatarFallback>
                          </Avatar>
                        )}
                      </div>
                    ))}

                    {isTyping && (
                      <div className="flex items-start space-x-3">
                        <Avatar className="w-8 h-8">
                          <AvatarImage src={guide.profileImage || undefined} />
                          <AvatarFallback className="bg-success-green text-white text-sm">
                            {guide.name ? guide.name.charAt(0) : 'G'}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="bg-gray-100 rounded-lg p-3 max-w-xs">
                            <div className="flex space-x-1">
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                              <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                            </div>
                          </div>
                          <p className="text-xs text-gray-500 mt-1">{guide.name} is typing...</p>
                        </div>
                      </div>
                    )}

                    <div ref={messagesEndRef} />
                  </div>

                  {/* Chat Input */}
                  <div className="p-4 border-t border-gray-200 bg-white">
                    <div className="flex items-end space-x-3">
                      <div className="flex-1">
                        <div className="relative">
                          <Textarea
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                            onKeyDown={handleKeyDown}
                            placeholder="Type your message here..."
                            rows={2}
                            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-travel-blue focus:border-travel-blue resize-none pr-12"
                          />
                          
                          <button
                            className="absolute right-3 top-3 w-8 h-8 p-0 hover:bg-gray-100 rounded flex items-center justify-center"
                            onClick={() => setIsVoiceModalOpen(true)}
                            title="Record voice message"
                            type="button"
                          >
                            <Mic size={16} className="text-gray-600" />
                          </button>
                        </div>
                        
                        <input
                          ref={fileInputRef}
                          type="file"
                          className="hidden"
                          accept="image/*,application/pdf,.doc,.docx"
                          onChange={handleFileChange}
                        />
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <button
                          className="w-10 h-10 p-0 hover:bg-gray-50 border border-gray-300 rounded flex items-center justify-center"
                          onClick={handleFileUpload}
                          title="Attach file"
                          type="button"
                        >
                          <Paperclip size={16} className="text-gray-600" />
                        </button>
                        
                        <button
                          className="w-10 h-10 p-0 bg-travel-blue hover:bg-blue-700 transition-colors rounded flex items-center justify-center disabled:opacity-50"
                          onClick={handleSendMessage}
                          disabled={!message.trim() || sendMessageMutation.isPending}
                          title="Send message"
                          type="button"
                        >
                          <Send size={16} className="text-white" />
                        </button>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                      <span>Press Enter to send, Shift+Enter for new line</span>
                    </div>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center">
                    <MessageCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      Ready to chat with {guide.name}?
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Start a conversation to get personalized travel assistance
                    </p>
                    <Button 
                      onClick={startChatSession}
                      disabled={createSessionMutation.isPending}
                    >
                      <MessageCircle size={16} className="mr-2" />
                      {createSessionMutation.isPending ? "Starting..." : "Start Chat"}
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <VoiceRecordingModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        onSendVoice={handleVoiceMessage}
      />
    </>
  );
}