import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Hotel } from "lucide-react";

interface SimpleGuideAssignmentProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SimpleGuideAssignment({ isOpen, onClose }: SimpleGuideAssignmentProps) {
  const [selectedHotelId, setSelectedHotelId] = useState("");
  const [selectedDays, setSelectedDays] = useState<number[]>([]);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const daysOfWeek = [
    { value: 0, label: "Sunday" },
    { value: 1, label: "Monday" },
    { value: 2, label: "Tuesday" },
    { value: 3, label: "Wednesday" },
    { value: 4, label: "Thursday" },
    { value: 5, label: "Friday" },
    { value: 6, label: "Saturday" },
  ];

  const { data: hotels = [] } = useQuery({
    queryKey: ["/api/hotels"],
  });

  const createAssignmentMutation = useMutation({
    mutationFn: async (assignmentData: any) => {
      const response = await fetch("/api/guide-assignments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(assignmentData),
      });
      if (!response.ok) {
        const error = await response.text();
        throw new Error(`Failed to create assignment: ${error}`);
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: "Hotel assignment created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/guide-assignments"] });
      onClose();
      resetForm();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create assignment.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setSelectedHotelId("");
    setSelectedDays([]);
  };

  const handleDayToggle = (dayValue: number) => {
    setSelectedDays(prev =>
      prev.includes(dayValue)
        ? prev.filter(day => day !== dayValue)
        : [...prev, dayValue]
    );
  };

  const handleSubmit = () => {
    console.log("Form submit - Hotel:", selectedHotelId, "Days:", selectedDays);
    
    if (!selectedHotelId) {
      toast({
        title: "Missing Hotel",
        description: "Please select a hotel.",
        variant: "destructive",
      });
      return;
    }
    
    if (selectedDays.length === 0) {
      toast({
        title: "Missing Days",
        description: "Please select at least one day.",
        variant: "destructive",
      });
      return;
    }

    const assignmentData = {
      guideId: 4, // Fixed guide ID for testing
      hotelId: parseInt(selectedHotelId),
      daysOfWeek: selectedDays,
      customShifts: [{ startTime: "09:00", endTime: "17:00" }],
      weekStartDates: [],
      isActive: true,
    };

    console.log("Creating assignment:", assignmentData);
    createAssignmentMutation.mutate(assignmentData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center text-lg font-semibold">
            <Calendar className="mr-2 text-blue-600" size={20} />
            Create Hotel Assignment
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Hotel Selection */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Hotel</Label>
            <Select value={selectedHotelId} onValueChange={setSelectedHotelId}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a hotel" />
              </SelectTrigger>
              <SelectContent>
                {(hotels as any[]).map((hotel) => (
                  <SelectItem key={hotel.id} value={hotel.id.toString()}>
                    <div className="flex items-center">
                      <Hotel size={16} className="mr-2 text-blue-600" />
                      {hotel.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Days of Week */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Days of Week</Label>
            <div className="grid grid-cols-2 gap-2">
              {daysOfWeek.map((day) => (
                <div key={day.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={`day-${day.value}`}
                    checked={selectedDays.includes(day.value)}
                    onCheckedChange={() => handleDayToggle(day.value)}
                  />
                  <Label htmlFor={`day-${day.value}`} className="text-sm">
                    {day.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <div className="text-xs text-gray-500 mt-4">
            Default shift: 9:00 AM - 5:00 PM
          </div>
        </div>

        <div className="flex space-x-3 pt-4">
          <Button
            variant="outline"
            onClick={onClose}
            className="flex-1"
            disabled={createAssignmentMutation.isPending}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            className="flex-1 bg-blue-600 hover:bg-blue-700"
            disabled={createAssignmentMutation.isPending}
          >
            {createAssignmentMutation.isPending ? "Creating..." : "Create Assignment"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}