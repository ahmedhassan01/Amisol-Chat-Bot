import { ArrowRightLeft, AlertTriangle, Route, UserRound, HelpingHand } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface CategorySidebarProps {
  selectedCategory: string | null;
  onSelectCategory: (category: string) => void;
}

const categories = [
  {
    id: "hotel-change",
    title: "Hotel Change",
    description: "Need assistance with changing your hotel booking",
    icon: ArrowRightLeft,
    color: "blue",
    hoverColor: "hover:border-blue-500 hover:bg-blue-50",
    iconBg: "bg-blue-100 group-hover:bg-blue-500",
    iconColor: "text-blue-500 group-hover:text-white",
    titleColor: "group-hover:text-blue-500"
  },
  {
    id: "hotel-complain",
    title: "Hotel Complain",
    description: "Report issues with your current accommodation",
    icon: AlertTriangle,
    color: "orange",
    hoverColor: "hover:border-orange-500 hover:bg-orange-50",
    iconBg: "bg-orange-100 group-hover:bg-orange-500",
    iconColor: "text-orange-500 group-hover:text-white",
    titleColor: "group-hover:text-orange-500"
  },
  {
    id: "booking-tours",
    title: "Booking Tours",
    description: "Book exciting tours and activities",
    icon: Route,
    color: "green",
    hoverColor: "hover:border-green-500 hover:bg-green-50",
    iconBg: "bg-green-100 group-hover:bg-green-500",
    iconColor: "text-green-500 group-hover:text-white",
    titleColor: "group-hover:text-green-500"
  },
  {
    id: "medical-assistance",
    title: "Need a Doctor",
    description: "Medical assistance and healthcare services",
    icon: UserRound,
    color: "red",
    hoverColor: "hover:border-red-500 hover:bg-red-50",
    iconBg: "bg-red-100 group-hover:bg-red-500",
    iconColor: "text-red-500 group-hover:text-white",
    titleColor: "group-hover:text-red-500",
    hasWhatsApp: true
  },
  {
    id: "guide-assistance",
    title: "Need Guide Assistant",
    description: "General assistance and local guidance",
    icon: HelpingHand,
    color: "purple",
    hoverColor: "hover:border-purple-500 hover:bg-purple-50",
    iconBg: "bg-purple-100 group-hover:bg-purple-500",
    iconColor: "text-purple-500 group-hover:text-white",
    titleColor: "group-hover:text-purple-500"
  }
];

export default function CategorySidebar({ selectedCategory, onSelectCategory }: CategorySidebarProps) {
  const handleCategorySelect = (categoryId: string) => {
    onSelectCategory(categoryId);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 h-full overflow-hidden">
      <div className="p-3 sm:p-4 border-b border-gray-200">
        <h2 className="text-sm sm:text-base font-semibold text-gray-900 mb-1">Welcome to TourGuide Chat</h2>
        <p className="text-xs text-gray-600">How can we help you?</p>
      </div>
      
      <div className="p-2 sm:p-3 space-y-2 overflow-y-auto max-h-[calc(100vh-200px)] sm:max-h-none">
        {categories.map((category) => {
          const IconComponent = category.icon;
          const isSelected = selectedCategory === category.id;
          
          return (
            <Button
              key={category.id}
              variant="ghost"
              className={cn(
                "w-full p-2 sm:p-3 h-auto text-left rounded-lg border transition-all group touch-manipulation active:scale-95",
                isSelected 
                  ? "border-blue-500 bg-blue-50" 
                  : `border-gray-200 ${category.hoverColor} active:bg-gray-50`
              )}
              onClick={() => handleCategorySelect(category.id)}
            >
              <div className="flex items-center space-x-2 sm:space-x-3">
                <div className={cn(
                  "w-6 h-6 sm:w-8 sm:h-8 rounded-lg flex items-center justify-center transition-colors flex-shrink-0",
                  isSelected ? "bg-blue-500" : category.iconBg
                )}>
                  <IconComponent 
                    size={14} 
                    className={cn(
                      "transition-colors sm:w-4 sm:h-4",
                      isSelected ? "text-white" : category.iconColor
                    )} 
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className={cn(
                    "text-xs sm:text-sm font-medium transition-colors leading-tight",
                    isSelected ? "text-blue-500" : `text-gray-900 ${category.titleColor}`
                  )}>
                    {category.title}
                  </h3>
                  {category.hasWhatsApp && (
                    <div className="flex items-center mt-1">
                      <svg className="w-2.5 h-2.5 sm:w-3 sm:h-3 text-green-500 mr-1" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488"/>
                      </svg>
                      <span className="text-xs text-green-600">Emergency</span>
                    </div>
                  )}
                </div>
              </div>
            </Button>
          );
        })}
      </div>
    </div>
  );
}
