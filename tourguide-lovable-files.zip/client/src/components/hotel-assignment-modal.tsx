import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Hotel, Calendar, Clock, User, MapPin, Phone, Mail, X, MessageCircle } from "lucide-react";
import type { GuideAssignment, Guide } from "@/../../shared/schema";

interface HotelAssignmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  assignment: (GuideAssignment & { guide: Guide; hotel: any }) | null;
}

export default function HotelAssignmentModal({ isOpen, onClose, assignment }: HotelAssignmentModalProps) {
  if (!assignment) return null;

  const formatDate = (dateString: string | Date) => {
    const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getDayName = (dayNumber: number) => {
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return days[dayNumber] || `Day ${dayNumber}`;
  };

  const formatTime = (time: string) => {
    try {
      const [hours, minutes] = time.split(':');
      const date = new Date();
      date.setHours(parseInt(hours), parseInt(minutes));
      return date.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      });
    } catch {
      return time;
    }
  };

  // Parse assignment data directly from the assignment object
  const daysOfWeek = assignment.daysOfWeek ? 
    (Array.isArray(assignment.daysOfWeek) ? assignment.daysOfWeek : JSON.parse(assignment.daysOfWeek as string)) : [];
  const customShifts = assignment.customShifts ? 
    (Array.isArray(assignment.customShifts) ? assignment.customShifts : JSON.parse(assignment.customShifts as string)) : [];
  const weekStartDates = assignment.weekStartDates ? 
    (Array.isArray(assignment.weekStartDates) ? assignment.weekStartDates : JSON.parse(assignment.weekStartDates as string)) : [];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 rounded-lg bg-blue-50 border border-blue-200">
                <Hotel className="h-5 w-5 text-blue-600" />
              </div>
              <div>
                <DialogTitle className="text-xl font-semibold text-gray-900">
                  {assignment.hotel?.name || "Hotel Assignment"}
                </DialogTitle>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge variant="secondary">
                    Guide Assignment
                  </Badge>
                  <div className="flex items-center text-sm text-gray-500">
                    <User className="h-4 w-4 mr-1" />
                    {assignment.guide?.name}
                  </div>
                </div>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={onClose}
              className="h-8 w-8 p-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="mt-6 space-y-6">
          {/* Hotel Information */}
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h3 className="font-semibold text-blue-900 mb-3 flex items-center">
              <Hotel className="h-5 w-5 mr-2" />
              Hotel Information
            </h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <MapPin className="h-4 w-4 text-blue-600" />
                <span className="text-sm text-blue-800">
                  {assignment.hotel?.address || "Address not available"}
                </span>
              </div>
              {assignment.hotel?.phone && (
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4 text-blue-600" />
                  <span className="text-sm text-blue-800">{assignment.hotel.phone}</span>
                </div>
              )}
              {assignment.hotel?.email && (
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4 text-blue-600" />
                  <span className="text-sm text-blue-800">{assignment.hotel.email}</span>
                </div>
              )}
            </div>
          </div>

          {/* Guide Information */}
          <div className="p-4 bg-green-50 rounded-lg border border-green-200">
            <h3 className="font-semibold text-green-900 mb-3 flex items-center">
              <User className="h-5 w-5 mr-2" />
              Assigned Guide
            </h3>
            <div className="space-y-2">
              <div className="text-sm text-green-800">
                <span className="font-medium">Name:</span> {assignment.guide?.name}
              </div>
              {assignment.guide?.email && (
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4 text-green-600" />
                  <span className="text-sm text-green-800">{assignment.guide.email}</span>
                </div>
              )}
              {assignment.guide?.phone && (
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4 text-green-600" />
                  <span className="text-sm text-green-800">{assignment.guide.phone}</span>
                </div>
              )}
              {assignment.guide?.specialties && (
                <div className="text-sm text-green-800">
                  <span className="font-medium">Specialties:</span> {assignment.guide.specialties}
                </div>
              )}
              {assignment.guide?.languages && (
                <div className="text-sm text-green-800">
                  <span className="font-medium">Languages:</span> {assignment.guide.languages}
                </div>
              )}
            </div>
          </div>

          {/* Schedule Information */}
          <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
            <h3 className="font-semibold text-yellow-900 mb-3 flex items-center">
              <Calendar className="h-5 w-5 mr-2" />
              Schedule Details
            </h3>
            
            {/* Days of Week */}
            {daysOfWeek.length > 0 && (
              <div className="mb-4">
                <h4 className="text-sm font-medium text-yellow-800 mb-2">Active Days:</h4>
                <div className="flex flex-wrap gap-2">
                  {daysOfWeek.map((day: number, index: number) => (
                    <Badge key={index} variant="outline" className="text-yellow-700 border-yellow-300">
                      {getDayName(day)}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Shift Times */}
            {customShifts.length > 0 && (
              <div className="mb-4">
                <h4 className="text-sm font-medium text-yellow-800 mb-2">Shift Times:</h4>
                <div className="space-y-2">
                  {customShifts.map((shift: any, index: number) => (
                    <div key={index} className="flex items-center space-x-2 text-sm text-yellow-800">
                      <Clock className="h-4 w-4 text-yellow-600" />
                      <span>
                        {formatTime(shift.startTime)} - {formatTime(shift.endTime)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Week Start Dates */}
            {weekStartDates.length > 0 && (
              <div>
                <h4 className="text-sm font-medium text-yellow-800 mb-2">Active Weeks:</h4>
                <div className="space-y-1">
                  {weekStartDates.map((dateStr: string, index: number) => (
                    <div key={index} className="text-sm text-yellow-800">
                      Week starting: {formatDate(dateStr)}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end space-x-3 pt-4 border-t">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
            {assignment.guide?.id && (
              <Button
                variant="default"
                onClick={() => {
                  // Navigate to direct chat with the guide
                  window.location.href = `/chat/${assignment.guide.id}`;
                }}
                className="flex items-center space-x-2"
              >
                <MessageCircle className="h-4 w-4" />
                <span>Chat Guide</span>
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}