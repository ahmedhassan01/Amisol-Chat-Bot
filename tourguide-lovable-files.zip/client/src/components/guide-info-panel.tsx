import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Star, Clock, Languages, Hotel, Phone, ExternalLink, Bus, Megaphone, MessageCircle, Bell, Trash2, CheckCheck } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import TouristGuideChatModal from "./tourist-guide-chat-modal";
import AnnouncementModal from "./announcement-modal";
import HotelAssignmentModal from "./hotel-assignment-modal";
import NotificationBadge from "./notification-badge";
import SessionReviewModal from "./session-review-modal";
import type { Guide, GuideAssignment, Announcement, EmergencyContact, ChatSession } from "@/../../shared/schema";

export default function GuideInfoPanel() {
  const { toast } = useToast();
  const [selectedGuideId, setSelectedGuideId] = useState<number | null>(null);
  const [selectedSessionId, setSelectedSessionId] = useState<number | null>(null);
  const [isGuideChatModalOpen, setIsGuideChatModalOpen] = useState(false);
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<Announcement | null>(null);
  const [isAnnouncementModalOpen, setIsAnnouncementModalOpen] = useState(false);
  const [selectedAssignment, setSelectedAssignment] = useState<(GuideAssignment & { guide: Guide; hotel: any }) | null>(null);
  const [isAssignmentModalOpen, setIsAssignmentModalOpen] = useState(false);
  const [isReviewModalOpen, setIsReviewModalOpen] = useState(false);
  const [reviewSessionData, setReviewSessionData] = useState<{sessionId: number, guideId: number, guideName: string} | null>(null);

  // Helper function to get tourist ID
  const getTouristId = () => {
    let touristId = localStorage.getItem('touristId');
    if (!touristId) {
      touristId = `tourist_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem('touristId', touristId);
    }
    return touristId;
  };

  const { data: guides = [] } = useQuery<Guide[]>({
    queryKey: ["/api/guides"],
  });

  const { data: assignments = [] } = useQuery<(GuideAssignment & { guide: Guide; hotel: any })[]>({
    queryKey: ["/api/guide-assignments"],
  });

  const { data: announcements = [] } = useQuery<Announcement[]>({
    queryKey: ["/api/announcements"],
  });

  const { data: emergencyContacts = [] } = useQuery<EmergencyContact[]>({
    queryKey: ["/api/emergency-contacts"],
  });

  const { data: chatSessions = [], refetch: refetchChatSessions } = useQuery<ChatSession[]>({
    queryKey: ["/api/chat-sessions", getTouristId()],
    queryFn: async () => {
      const touristId = getTouristId();
      const response = await fetch(`/api/chat-sessions?userId=${touristId}`);
      if (!response.ok) throw new Error('Failed to fetch chat sessions');
      return response.json();
    },
    refetchInterval: 3000, // Check for new messages every 3 seconds
  });

  // Delete chat session mutation for tourists
  const deleteSessionMutation = useMutation({
    mutationFn: async (sessionId: number) => {
      const touristId = getTouristId();
      const response = await fetch(`/api/chat-sessions/${sessionId}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: touristId }),
      });
      if (!response.ok) throw new Error('Failed to delete session');
      return response.json();
    },
    onSuccess: () => {
      refetchChatSessions();
      toast({
        title: "Conversation Deleted",
        description: "Your conversation has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete the conversation.",
        variant: "destructive",
      });
    }
  });

  // Mark session as read mutation for tourists
  const markSessionReadMutation = useMutation({
    mutationFn: async (sessionId: number) => {
      const touristId = getTouristId();
      const response = await fetch(`/api/chat-sessions/${sessionId}/mark-read`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: touristId }),
      });
      if (!response.ok) throw new Error('Failed to mark as read');
      return response.json();
    },
    onSuccess: () => {
      refetchChatSessions();
      // Refresh unread counts immediately with tourist ID
      const touristId = getTouristId();
      queryClient.invalidateQueries({ queryKey: ["/api/chat-sessions/unread-counts"] });
      queryClient.invalidateQueries({ queryKey: ["/api/chat-sessions/unread-counts", touristId] });
      // Force refetch immediately
      setTimeout(() => {
        queryClient.refetchQueries({ queryKey: ["/api/chat-sessions/unread-counts", touristId] });
      }, 100);
      toast({
        title: "Marked as Read",
        description: "All messages in this conversation are now marked as read.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to mark messages as read.",
        variant: "destructive",
      });
    }
  });

  // Display all active guides instead of just the first one
  const activeGuides = guides.filter((guide) => guide.isActive);

  // Query to get actual unread message counts
  const { data: unreadCounts = {} } = useQuery<Record<number, number>>({
    queryKey: ["/api/chat-sessions/unread-counts", getTouristId()],
    queryFn: async () => {
      const touristId = getTouristId();
      const response = await fetch(`/api/chat-sessions/unread-counts?userId=${touristId}&timestamp=${Date.now()}`);
      if (!response.ok) throw new Error('Failed to fetch unread counts');
      return response.json();
    },
    refetchInterval: 2000, // Check for unread messages every 2 seconds
  });

  // Count unread messages for each guide
  const getUnreadMessageCount = (guideId: number) => {
    return unreadCounts[guideId] || 0;
  };
  
  // Get all current week's assignments
  const currentWeekAssignments = assignments.filter((a) => a.isActive);

  const handleEmergencyContact = async (contactType: string) => {
    console.log("Emergency contact handler called:", contactType);
    try {
      const response = await fetch("/api/whatsapp/emergency", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contactType,
          message: "Emergency assistance required from TourGuide Chat system."
        }),
      });
      
      const result = await response.json();
      console.log("Emergency response:", result);
      
      if (result.success && result.whatsappUrl) {
        console.log("Opening WhatsApp URL:", result.whatsappUrl);
        window.open(result.whatsappUrl, '_blank');
        toast({
          title: "WhatsApp opened",
          description: `Connecting to ${result.contact?.name || 'emergency contact'}`,
        });
      } else {
        throw new Error(result.error || "Failed to get WhatsApp URL");
      }
    } catch (error) {
      console.error("Emergency contact error:", error);
      toast({
        title: "Connection failed",
        description: "Please try calling directly.",
        variant: "destructive"
      });
    }
  };

  const getDayName = (dayOfWeek: number) => {
    const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    return days[dayOfWeek];
  };

  // Get total unread messages for notification banner
  const totalUnreadMessages = activeGuides.reduce((total, guide) => 
    total + getUnreadMessageCount(guide.id), 0
  );



  // Filter chat sessions for this specific tourist - only show active sessions
  const myChatSessions = chatSessions.filter((session: any) => 
    session.isActive && (
      session.touristId === getTouristId()
    )
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 pb-6">
      {/* Mobile-First Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-3 px-4 sm:py-4 md:py-6">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-lg sm:text-xl md:text-2xl font-bold">TourGuide Chat</h1>
          <p className="text-xs sm:text-sm md:text-base text-blue-100 mt-1">Your travel assistants</p>
        </div>
      </div>
      
      <div className="max-w-4xl mx-auto px-3 sm:px-4 md:px-6 py-3 sm:py-4 md:py-6 space-y-3 sm:space-y-4 md:space-y-6">
      {/* My Conversations Section - Mobile Optimized */}
      {myChatSessions.length > 0 && (
        <Card className="border-green-200 bg-green-50 shadow-sm">
          <CardHeader className="pb-2 px-3 sm:px-6">
            <CardTitle className="flex items-center text-sm sm:text-base text-green-800">
              <MessageCircle className="text-green-600 mr-2" size={16} />
              My Conversations
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 px-3 sm:px-6">
            <div className="space-y-2 sm:space-y-3">
              {myChatSessions.map((session: any) => {
                const sessionGuide = guides.find(g => g.id === session.guideId);
                const guideUnreadCount = sessionGuide ? getUnreadMessageCount(sessionGuide.id) : 0;
                const hasUnreadMessages = guideUnreadCount > 0;
                
                return (
                  <div
                    key={session.id}
                    className={`w-full p-2 sm:p-3 rounded-lg border transition-all ${
                      hasUnreadMessages 
                        ? 'bg-red-50 border-red-300 shadow-md' 
                        : 'bg-white border-green-200 hover:border-green-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div 
                        className="flex-1 cursor-pointer"
                        onClick={() => {
                          if (sessionGuide) {
                            setSelectedGuideId(sessionGuide.id);
                            setSelectedSessionId(session.id);
                            setIsGuideChatModalOpen(true);
                          }
                        }}
                      >
                        <div className="flex items-center space-x-1 sm:space-x-2">
                          <h4 className={`text-sm sm:text-base font-medium ${hasUnreadMessages ? 'text-red-900' : 'text-gray-900'}`}>
                            {sessionGuide?.name || 'Guide'}
                          </h4>
                          {hasUnreadMessages && (
                            <NotificationBadge count={guideUnreadCount} className="bg-red-500 text-white animate-pulse text-xs" />
                          )}
                        </div>
                        <p className={`text-xs sm:text-sm ${hasUnreadMessages ? 'text-red-700' : 'text-gray-600'}`}>
                          {new Date(session.createdAt).toLocaleDateString()}
                        </p>
                        {hasUnreadMessages && (
                          <p className="text-xs sm:text-sm text-red-700 font-medium mt-1">
                            🔴 {guideUnreadCount} new message{guideUnreadCount > 1 ? 's' : ''}
                          </p>
                        )}
                        <p className={`text-xs mt-1 ${hasUnreadMessages ? 'text-red-600 font-medium' : 'text-green-600'}`}>
                          {hasUnreadMessages ? 'Tap to read' : 'Tap to chat'}
                        </p>
                      </div>
                      <div className="flex flex-col sm:flex-row items-end sm:items-center space-y-1 sm:space-y-0 sm:space-x-2">
                        {/* Reply Button */}
                        <Button
                          size="sm"
                          variant={hasUnreadMessages ? "default" : "outline"}
                          className={`text-xs sm:text-sm px-2 sm:px-3 py-1 h-auto min-h-[28px] flex items-center space-x-1 ${
                            hasUnreadMessages 
                              ? 'bg-red-600 hover:bg-red-700 text-white' 
                              : 'text-green-600 hover:text-green-700 hover:bg-green-50'
                          }`}
                          onClick={(e) => {
                            e.stopPropagation();
                            if (sessionGuide) {
                              setSelectedGuideId(sessionGuide.id);
                              setSelectedSessionId(session.id);
                              setIsGuideChatModalOpen(true);
                            }
                          }}
                        >
                          <MessageCircle size={14} />
                          <span className="text-sm font-medium">
                            {hasUnreadMessages ? 'Reply Now' : 'Reply'}
                          </span>
                        </Button>
                        
                        {/* Mark as Read Button - only show if there are unread messages */}
                        {hasUnreadMessages && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-xs sm:text-sm px-2 sm:px-3 py-1 h-auto min-h-[28px] flex items-center space-x-1 text-blue-600 hover:text-blue-700 hover:bg-blue-50 border-blue-300"
                            onClick={(e) => {
                              e.stopPropagation();
                              markSessionReadMutation.mutate(session.id);
                            }}
                            disabled={markSessionReadMutation.isPending}
                          >
                            <CheckCheck size={10} />
                            <span className="hidden sm:inline">Mark Read</span>
                          </Button>
                        )}
                        
                        {/* Review Button - show for conversations with messages */}
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-xs px-2 py-1 h-auto min-h-[28px] flex items-center space-x-1 text-yellow-600 hover:text-yellow-700 hover:bg-yellow-50 border-yellow-300"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (sessionGuide) {
                              setReviewSessionData({
                                sessionId: session.id,
                                guideId: sessionGuide.id,
                                guideName: sessionGuide.name
                              });
                              setIsReviewModalOpen(true);
                            }
                          }}
                        >
                          <Star size={10} />
                          <span className="hidden sm:inline">Review</span>
                        </Button>

                        {/* Delete Button */}
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-xs px-2 py-1 h-auto min-h-[28px] flex items-center space-x-1 text-gray-600 hover:text-red-700 hover:bg-red-50"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (confirm('Are you sure you want to delete this conversation?')) {
                              deleteSessionMutation.mutate(session.id);
                            }
                          }}
                          disabled={deleteSessionMutation.isPending}
                        >
                          <Trash2 size={10} />
                          <span className="hidden sm:inline">Delete</span>
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Notification Banner for New Messages */}
      {totalUnreadMessages > 0 && (
        <Card className="border-blue-200 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Bell size={20} className="text-blue-600 animate-pulse" />
              <div className="flex-1">
                <h3 className="font-medium text-blue-900">
                  You have {totalUnreadMessages} new message{totalUnreadMessages > 1 ? 's' : ''} from your guide{totalUnreadMessages > 1 ? 's' : ''}!
                </h3>
                <p className="text-sm text-blue-700">
                  Check "My Conversations" above or click on guide cards below to reply.
                </p>
              </div>
              <MessageCircle size={20} className="text-blue-600" />
            </div>
          </CardContent>
        </Card>
      )}

      {/* Available Guides - Mobile Optimized */}
      <Card className="shadow-sm">
        <CardHeader className="pb-2 px-3 sm:px-6">
          <CardTitle className="flex flex-col sm:flex-row sm:items-center justify-between text-sm sm:text-base">
            <div className="flex items-center">
              <Bus className="text-blue-600 mr-2" size={16} />
              Guides ({activeGuides.length})
            </div>
            {activeGuides.some(guide => getUnreadMessageCount(guide.id) > 0) && (
              <div className="flex items-center space-x-1 sm:space-x-2 text-blue-600 mt-1 sm:mt-0">
                <Bell size={14} className="animate-pulse" />
                <span className="text-xs sm:text-sm font-medium">New replies!</span>
              </div>
            )}
          </CardTitle>
        </CardHeader>
        
        <CardContent className="pt-0 px-3 sm:px-6">
          <div className="space-y-2 sm:space-y-4">
            {activeGuides.map((guide) => (
              <button
                key={guide.id}
                className="w-full text-left hover:bg-gray-50 rounded-lg p-2 sm:p-3 border border-gray-200 transition-colors"
                onClick={() => {
                  console.log("Guide card clicked:", guide.name);
                  setSelectedGuideId(guide.id);
                  setIsGuideChatModalOpen(true);
                }}
              >
                <div className="flex items-center space-x-2 sm:space-x-3">
                  <div className="relative">
                    <div className="w-8 h-8 sm:w-10 sm:h-10 bg-blue-600 rounded-full flex items-center justify-center">
                      <Bus size={12} className="text-white sm:hidden" />
                      <Bus size={16} className="text-white hidden sm:block" />
                    </div>
                    <NotificationBadge count={getUnreadMessageCount(guide.id)} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm sm:text-base font-medium text-gray-900">{guide.name}</h3>
                      {getUnreadMessageCount(guide.id) > 0 && (
                        <div className="flex items-center space-x-1 text-blue-600">
                          <MessageCircle size={12} />
                          <span className="text-xs font-medium hidden sm:inline">New message</span>
                          <span className="text-xs font-medium sm:hidden">New</span>
                        </div>
                      )}
                    </div>
                    <p className="text-xs sm:text-sm text-gray-600 truncate">{guide.email}</p>
                    <div className="flex items-center mt-1">
                      <div className="w-1.5 h-1.5 sm:w-2 sm:h-2 bg-green-500 rounded-full mr-1 sm:mr-2"></div>
                      <span className="text-xs text-green-500 font-medium">Available</span>
                      <Star className="text-yellow-400 ml-1 sm:ml-2" size={10} />
                      <span className="text-xs text-gray-600 ml-1">{guide.rating || 4.9}</span>
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Hotel Assignments This Week - Mobile Optimized */}
      <Card className="shadow-sm">
        <CardHeader className="pb-2 px-3 sm:px-6">
          <CardTitle className="flex items-center text-sm sm:text-base">
            <Hotel className="text-blue-600 mr-2" size={16} />
            Hotel Assignments
          </CardTitle>
          <p className="text-xs sm:text-sm text-gray-600">Current week schedule</p>
        </CardHeader>
        
        <CardContent className="pt-0 px-3 sm:px-6">
          <div className="space-y-2 sm:space-y-3">
            {currentWeekAssignments.length > 0 ? (
              currentWeekAssignments.map((assignment) => (
                <button 
                  key={assignment.id} 
                  className="w-full flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors text-left"
                  onClick={() => {
                    console.log("Hotel assignment clicked:", assignment.hotel?.name);
                    const guide = activeGuides.find(g => g.id === assignment.guideId);
                    setSelectedAssignment({ ...assignment, guide: guide! });
                    setIsAssignmentModalOpen(true);
                  }}
                >
                  <div className="flex-1">
                    <p className="font-medium text-gray-900 text-sm">{assignment.hotel?.name}</p>
                    <p className="text-xs text-gray-600">
                      Days: {Array.isArray(assignment.daysOfWeek) ? assignment.daysOfWeek.map((day: number) => getDayName(day)).join(", ") : "No days"}<br/>
                      Shifts: {Array.isArray(assignment.customShifts) ? assignment.customShifts.map((shift: any) => `${shift.startTime}-${shift.endTime}`).join(", ") : "No shifts"}
                    </p>
                  </div>
                  <div className="w-2 h-2 rounded-full bg-blue-600"></div>
                </button>
              ))
            ) : (
              <div className="text-center py-4">
                <Hotel className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                <p className="text-sm text-gray-500">No assignments this week</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Emergency Contacts */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center text-base">
            <Phone className="text-red-500 mr-2" size={20} />
            Emergency Contacts
          </CardTitle>
        </CardHeader>
        
        <CardContent className="pt-0">
          <div className="space-y-3">
            {emergencyContacts
              .filter((contact) => contact.type === 'medical')
              .map((contact) => (
                <button
                  key={contact.id}
                  className="w-full flex items-center justify-between p-3 bg-red-50 hover:bg-red-100 border border-red-200 rounded-lg transition-colors"
                  onClick={() => {
                    console.log("Medical emergency contact clicked:", contact.name);
                    handleEmergencyContact('medical');
                  }}
                >
                  <div className="flex items-center space-x-3">
                    <svg className="w-5 h-5 text-green-500" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.885 3.488"/>
                    </svg>
                    <div className="text-left">
                      <p className="font-medium text-gray-900 text-sm">{contact.name}</p>
                      <p className="text-xs text-gray-600">24/7 WhatsApp Support</p>
                    </div>
                  </div>
                  <ExternalLink className="text-gray-400" size={16} />
                </button>
              ))}
            
            {emergencyContacts
              .filter((contact: any) => contact.type === 'guide-manager')
              .map((contact: any) => (
                <button
                  key={contact.id}
                  className="w-full flex items-center justify-between p-3 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors"
                  onClick={() => {
                    console.log("Guide manager contact clicked:", contact.name);
                    window.open(`tel:${contact.phone}`, '_self');
                  }}
                >
                  <div className="flex items-center space-x-3">
                    <Bus className="text-blue-600" size={20} />
                    <div className="text-left">
                      <p className="font-medium text-gray-900 text-sm">{contact.name}</p>
                      <p className="text-xs text-gray-600">Direct line</p>
                    </div>
                  </div>
                  <Phone className="text-gray-400" size={16} />
                </button>
              ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Announcements */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center text-base">
            <Megaphone className="text-orange-500 mr-2" size={20} />
            Announcements
          </CardTitle>
        </CardHeader>
        
        <CardContent className="pt-0">
          <div className="space-y-3">
            {announcements.slice(0, 3).map((announcement) => (
              <button
                key={announcement.id}
                className={`w-full text-left p-3 rounded-r-lg border-l-4 hover:opacity-80 transition-opacity ${
                  announcement.type === 'urgent' 
                    ? 'bg-red-50 border-red-400' 
                    : announcement.type === 'warning'
                    ? 'bg-yellow-50 border-yellow-400'
                    : 'bg-blue-50 border-blue-400'
                }`}
                onClick={() => {
                  console.log("Announcement clicked:", announcement.title);
                  setSelectedAnnouncement(announcement);
                  setIsAnnouncementModalOpen(true);
                }}
              >
                <p className={`text-sm font-medium ${
                  announcement.type === 'urgent' 
                    ? 'text-red-800' 
                    : announcement.type === 'warning'
                    ? 'text-yellow-800'
                    : 'text-blue-800'
                }`}>
                  {announcement.title}
                </p>
                <p className={`text-xs mt-1 ${
                  announcement.type === 'urgent' 
                    ? 'text-red-700' 
                    : announcement.type === 'warning'
                    ? 'text-yellow-700'
                    : 'text-blue-700'
                }`}>
                  {announcement.content}
                </p>
                <p className={`text-xs mt-2 ${
                  announcement.type === 'urgent' 
                    ? 'text-red-600' 
                    : announcement.type === 'warning'
                    ? 'text-yellow-600'
                    : 'text-blue-600'
                }`}>
                  {new Date(announcement.createdAt).toLocaleDateString()}
                </p>
              </button>
            ))}
            {announcements.length === 0 && (
              <div className="text-center py-4">
                <Megaphone className="mx-auto h-8 w-8 text-gray-400 mb-2" />
                <p className="text-sm text-gray-500">No announcements</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Tourist-Guide Chat Modal */}
      {selectedGuideId && (
        <TouristGuideChatModal
          isOpen={isGuideChatModalOpen}
          onClose={() => {
            setIsGuideChatModalOpen(false);
            setSelectedGuideId(null);
            setSelectedSessionId(null);
          }}
          guideId={selectedGuideId}
          existingSessionId={selectedSessionId}
        />
      )}

      {/* Announcement Modal */}
      <AnnouncementModal
        isOpen={isAnnouncementModalOpen}
        onClose={() => {
          setIsAnnouncementModalOpen(false);
          setSelectedAnnouncement(null);
        }}
        announcement={selectedAnnouncement}
      />

      {/* Hotel Assignment Modal */}
      <HotelAssignmentModal
        isOpen={isAssignmentModalOpen}
        onClose={() => {
          setIsAssignmentModalOpen(false);
          setSelectedAssignment(null);
        }}
        assignment={selectedAssignment}
      />

      {/* Session Review Modal */}
      {reviewSessionData && (
        <SessionReviewModal
          isOpen={isReviewModalOpen}
          onClose={() => {
            setIsReviewModalOpen(false);
            setReviewSessionData(null);
          }}
          sessionId={reviewSessionData.sessionId}
          guideId={reviewSessionData.guideId}
          guideName={reviewSessionData.guideName}
          touristId={getTouristId()}
        />
      )}
      </div>
    </div>
  );
}
