import { useState, useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Hotel, Calendar, Clock, Plus, Trash2 } from "lucide-react";
import type { Hotel as HotelType } from "@shared/schema";

interface GuideSelfAssignmentModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function GuideSelfAssignmentModal({ isOpen, onClose }: GuideSelfAssignmentModalProps) {
  const [selectedHotelId, setSelectedHotelId] = useState("");
  const [selectedDays, setSelectedDays] = useState<number[]>([]);
  const [shifts, setShifts] = useState([{ startTime: "09:00", endTime: "17:00" }]);
  const [weekDates, setWeekDates] = useState([""]);

  const { toast } = useToast();
  const { user, getAuthHeaders } = useAuth();
  const queryClient = useQueryClient();

  const daysOfWeek = [
    { value: 0, label: "Sunday" },
    { value: 1, label: "Monday" },
    { value: 2, label: "Tuesday" },
    { value: 3, label: "Wednesday" },
    { value: 4, label: "Thursday" },
    { value: 5, label: "Friday" },
    { value: 6, label: "Saturday" },
  ];

  const { data: hotels = [] } = useQuery<HotelType[]>({
    queryKey: ["/api/hotels"],
  });

  // Get current guide based on user info or default to first guide for testing
  const { data: currentGuide } = useQuery({
    queryKey: ["/api/guides", user?.guideId || 4], // Default to guide ID 4 for testing
    enabled: true,
  });

  const createAssignmentMutation = useMutation({
    mutationFn: async (assignmentData: any) => {
      const response = await fetch("/api/guide-assignments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...getAuthHeaders(),
        },
        body: JSON.stringify(assignmentData),
      });
      if (!response.ok) throw new Error("Failed to create assignment");
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Assignment Created",
        description: "Your hotel assignment has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/guide-assignments"] });
      onClose();
      resetForm();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create assignment. Please try again.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setSelectedHotelId("");
    setSelectedDays([]);
    setShifts([{ startTime: "09:00", endTime: "17:00" }]);
    setWeekDates([""]);
  };

  const handleDayToggle = (dayValue: number) => {
    setSelectedDays(prev =>
      prev.includes(dayValue)
        ? prev.filter(day => day !== dayValue)
        : [...prev, dayValue]
    );
  };

  const addShift = () => {
    setShifts([...shifts, { startTime: "09:00", endTime: "17:00" }]);
  };

  const removeShift = (index: number) => {
    if (shifts.length > 1) {
      setShifts(shifts.filter((_, i) => i !== index));
    }
  };

  const updateShift = (index: number, field: "startTime" | "endTime", value: string) => {
    const updated = [...shifts];
    updated[index] = { ...updated[index], [field]: value };
    setShifts(updated);
  };

  const addWeekDate = () => {
    setWeekDates([...weekDates, ""]);
  };

  const removeWeekDate = (index: number) => {
    if (weekDates.length > 1) {
      setWeekDates(weekDates.filter((_, i) => i !== index));
    }
  };

  const updateWeekDate = (index: number, value: string) => {
    const updated = [...weekDates];
    updated[index] = value;
    setWeekDates(updated);
  };

  const handleSubmit = () => {
    console.log("Form state:", { selectedHotelId, selectedDays, shifts, weekDates });
    
    if (!selectedHotelId) {
      toast({
        title: "Please Select Hotel",
        description: "You must choose a hotel for the assignment.",
        variant: "destructive",
      });
      return;
    }
    
    if (selectedDays.length === 0) {
      toast({
        title: "Please Select Days",
        description: "You must choose at least one day of the week.",
        variant: "destructive",
      });
      return;
    }

    // Create assignment with complete schedule information for guests
    const assignmentData = {
      guideId: 4, // Fixed guide ID for testing
      hotelId: parseInt(selectedHotelId),
      daysOfWeek: selectedDays,
      customShifts: shifts, // Include timing so guests know when guide is available
      weekStartDates: weekDates.filter(date => date.trim() !== ""), // Include specific dates
      isActive: true,
    };

    console.log("Creating assignment:", assignmentData);
    createAssignmentMutation.mutate(assignmentData);
  };

  const selectedHotel = hotels.find((h) => h.id.toString() === selectedHotelId);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center text-xl font-semibold">
            <Calendar className="mr-2 text-blue-600" size={24} />
            Create New Hotel Assignment
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Hotel Selection */}
          <div className="space-y-2">
            <Label className="text-sm font-medium">Select Hotel</Label>
            <Select value={selectedHotelId} onValueChange={setSelectedHotelId}>
              <SelectTrigger>
                <SelectValue placeholder="Choose a hotel" />
              </SelectTrigger>
              <SelectContent>
                {hotels.map((hotel) => (
                  <SelectItem key={hotel.id} value={hotel.id.toString()}>
                    <div className="flex items-center">
                      <Hotel size={16} className="mr-2 text-blue-600" />
                      {hotel.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedHotel && (
              <div className="text-xs text-gray-600 mt-1">
                {selectedHotel.address}
              </div>
            )}
          </div>

          {/* Days of Week */}
          <div className="space-y-3">
            <Label className="text-sm font-medium">Days of Week</Label>
            <div className="grid grid-cols-2 gap-2">
              {daysOfWeek.map((day) => (
                <div key={day.value} className="flex items-center space-x-2">
                  <Checkbox
                    id={`day-${day.value}`}
                    checked={selectedDays.includes(day.value)}
                    onCheckedChange={() => handleDayToggle(day.value)}
                  />
                  <Label htmlFor={`day-${day.value}`} className="text-sm">
                    {day.label}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          {/* Shift Times */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">Shift Times</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addShift}
                className="flex items-center space-x-1"
              >
                <Plus size={14} />
                <span>Add Shift</span>
              </Button>
            </div>
            {shifts.map((shift, index) => (
              <Card key={index} className="p-3">
                <div className="flex items-center space-x-2">
                  <Clock size={16} className="text-gray-500" />
                  <Input
                    type="time"
                    value={shift.startTime}
                    onChange={(e) => updateShift(index, "startTime", e.target.value)}
                    className="flex-1"
                  />
                  <span className="text-gray-500">to</span>
                  <Input
                    type="time"
                    value={shift.endTime}
                    onChange={(e) => updateShift(index, "endTime", e.target.value)}
                    className="flex-1"
                  />
                  {shifts.length > 1 && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => removeShift(index)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 size={14} />
                    </Button>
                  )}
                </div>
              </Card>
            ))}
          </div>

          {/* Week Start Dates */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label className="text-sm font-medium">Week Start Dates (Optional)</Label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={addWeekDate}
                className="flex items-center space-x-1"
              >
                <Plus size={14} />
                <span>Add Date</span>
              </Button>
            </div>
            {weekDates.map((date, index) => (
              <div key={index} className="flex items-center space-x-2">
                <Input
                  type="date"
                  value={date}
                  onChange={(e) => updateWeekDate(index, e.target.value)}
                  className="flex-1"
                  placeholder="Select week start date"
                />
                {weekDates.length > 1 && (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => removeWeekDate(index)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 size={14} />
                  </Button>
                )}
              </div>
            ))}
            <div className="text-xs text-gray-500">
              Leave empty to apply to all weeks
            </div>
          </div>
        </div>

        <div className="flex space-x-3 pt-4">
          <Button
            variant="outline"
            onClick={onClose}
            className="flex-1"
            disabled={createAssignmentMutation.isPending}
          >
            Cancel
          </Button>
          <Button
            onClick={handleSubmit}
            className="flex-1 bg-blue-600 hover:bg-blue-700"
            disabled={createAssignmentMutation.isPending}
          >
            {createAssignmentMutation.isPending ? "Creating..." : "Create Assignment"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}