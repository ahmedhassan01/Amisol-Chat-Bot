import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { useRealTimeMessages } from "@/hooks/use-real-time-messages";
import { Send, Paperclip, Mic, Phone, MessageSquare } from "lucide-react";
import VoiceRecordingModal from "./voice-recording-modal";
import type { ChatMessage } from "@shared/schema";

interface ChatInterfaceProps {
  selectedCategory: string | null;
  chatSession: any;
  selectedHotel: any;
}

function getTouristId() {
  let touristId = localStorage.getItem('touristId');
  if (!touristId) {
    touristId = `tourist_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    localStorage.setItem('touristId', touristId);
  }
  return touristId;
}

export default function ChatInterface({ selectedCategory, chatSession, selectedHotel }: ChatInterfaceProps) {
  const [message, setMessage] = useState("");
  const [isVoiceModalOpen, setIsVoiceModalOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  // Real-time messaging with persistent state
  const { 
    messages, 
    sendMessage: sendRealTimeMessage, 
    isLoading: isLoadingMessages, 
    isConnected 
  } = useRealTimeMessages({
    sessionId: chatSession?.id || 0,
    userId: getTouristId(),
    enabled: !!chatSession?.id
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Send welcome message when session starts
  useEffect(() => {
    if (chatSession?.id && messages.length === 0) {
      const welcomeMessage = `Hello! I'm interested in ${selectedCategory?.replace('-', ' ')} services. I'm staying at ${selectedHotel?.name}. Can you help me?`;
      
      setTimeout(() => {
        sendRealTimeMessage(welcomeMessage, "text").catch(console.error);
      }, 1000);
    }
  }, [chatSession?.id, messages.length, selectedCategory, selectedHotel, sendRealTimeMessage]);

  // Send text message handler
  const handleSendMessage = async () => {
    if (!message.trim()) return;
    
    try {
      // Mark this conversation as actively engaged by adding metadata
      await sendRealTimeMessage(message.trim(), "text", { userEngaged: true });
      setMessage("");
      setTimeout(() => scrollToBottom(), 100);
      toast({
        title: "Message sent",
        description: "Your message has been sent to the guide"
      });
    } catch (error) {
      toast({
        title: "Failed to send message",
        description: "Please try again.",
        variant: "destructive",
      });
    }
  };

  // Voice message handler
  const handleVoiceMessage = async (audioBlob: Blob) => {
    try {
      await sendRealTimeMessage("Voice message sent", "voice", { duration: "0:05", userEngaged: true });
      setIsVoiceModalOpen(false);
      toast({
        title: "Voice message sent",
        description: "Your voice message has been sent"
      });
    } catch (error) {
      toast({
        title: "Failed to send voice message",
        description: "Please try again.",
        variant: "destructive",
      });
    }
  };

  // File upload handler
  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const formData = new FormData();
      formData.append("file", file);

      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        const result = await response.json();
        await sendRealTimeMessage(`File uploaded: ${file.name}`, "file", { 
          fileName: file.name,
          fileUrl: result.url,
          fileSize: file.size
        });
        toast({
          title: "File uploaded",
          description: `${file.name} has been sent`
        });
      }
    } catch (error) {
      toast({
        title: "Failed to upload file",
        description: "Please try again.",
        variant: "destructive",
      });
    }

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTime = (dateString: string | Date) => {
    const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
    return date.toLocaleTimeString([], { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  if (!chatSession) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="h-5 w-5" />
            Select a category to start chatting
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600">Choose a support category to begin your conversation with our guides.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader className="border-b p-3 md:p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 md:gap-3 min-w-0">
              <MessageSquare className="h-4 w-4 md:h-5 md:w-5 text-blue-600 flex-shrink-0" />
              <div className="min-w-0">
                <CardTitle className="text-sm md:text-lg truncate">
                  {selectedCategory?.replace('-', ' ').toUpperCase()} Support
                </CardTitle>
                <p className="text-xs md:text-sm text-gray-600 truncate">
                  {selectedHotel?.name} • Guide: {chatSession.guide?.name || 'Assigning...'}
                  {!isConnected && (
                    <span className="ml-1 md:ml-2 text-orange-600">• Reconnecting...</span>
                  )}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1 md:gap-2 flex-shrink-0">
              <Button variant="outline" size="sm" className="h-8 w-8 md:h-9 md:w-auto md:px-3">
                <Phone className="h-3 w-3 md:h-4 md:w-4" />
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-0">
          <div className="flex flex-col h-[70vh] md:h-[60vh]">
            {/* Messages Area */}
            <ScrollArea className="flex-1 p-2 md:p-4">
              {isLoadingMessages ? (
                <div className="text-center py-8 text-gray-500">
                  <div className="animate-pulse">Loading messages...</div>
                </div>
              ) : messages.length === 0 ? (
                <div className="text-center py-8 px-4">
                  <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 md:p-6">
                    <MessageSquare className="h-8 w-8 md:h-12 md:w-12 text-blue-600 mx-auto mb-3" />
                    <h3 className="font-medium text-sm md:text-lg text-gray-900 dark:text-gray-100 mb-2">
                      Welcome to TourGuide Chat
                    </h3>
                    <p className="text-xs md:text-sm text-gray-600 dark:text-gray-400 max-w-xs mx-auto">
                      Your guide will respond shortly. Feel free to describe what you need help with.
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-3 md:space-y-4">
                  {messages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex ${
                        msg.senderType === "user" ? "justify-end" : "justify-start"
                      }`}
                    >
                      <div
                        className={`max-w-[85%] md:max-w-[70%] rounded-lg p-2 md:p-3 ${
                          msg.senderType === "user"
                            ? "bg-blue-600 text-white"
                            : "bg-gray-100 dark:bg-gray-700"
                        }`}
                      >
                        <div className="font-medium text-xs md:text-sm mb-1">
                          {msg.senderType === "user" ? "You" : (chatSession.guide?.name || "Guide")}
                        </div>
                        <div className="text-sm md:text-base break-words">{String(msg.content)}</div>
                        {msg.messageType === "voice" && (
                          <div className="flex items-center gap-2 mt-2">
                            <Mic className="h-3 w-3 md:h-4 md:w-4" />
                            <span className="text-xs">Voice message</span>
                          </div>
                        )}
                        {msg.messageType === "file" && msg.metadata && (
                          <div className="flex items-center gap-2 mt-2">
                            <Paperclip className="h-3 w-3 md:h-4 md:w-4" />
                            <span className="text-xs truncate">
                              {typeof msg.metadata === 'object' && msg.metadata !== null && 'fileName' in msg.metadata 
                                ? (msg.metadata as any).fileName 
                                : 'File attachment'}
                            </span>
                          </div>
                        )}
                        <div className="text-xs opacity-70 mt-1">
                          {formatTime(msg.createdAt)}
                        </div>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </ScrollArea>

            {/* Input Area */}
            <div className="border-t p-2 md:p-4 bg-gray-50 dark:bg-gray-900">
              <div className="flex items-center gap-1 md:gap-2">
                <Input
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Type your message..."
                  className="flex-1 text-sm md:text-base h-9 md:h-10"
                />
                
                <input
                  ref={fileInputRef}
                  type="file"
                  onChange={handleFileUpload}
                  className="hidden"
                  accept="image/*,application/pdf,.doc,.docx"
                />
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  className="h-9 w-9 md:h-10 md:w-10 p-0"
                  disabled={isLoadingMessages}
                >
                  <Paperclip className="h-3 w-3 md:h-4 md:w-4" />
                </Button>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsVoiceModalOpen(true)}
                  className="h-9 w-9 md:h-10 md:w-10 p-0"
                  disabled={isLoadingMessages}
                >
                  <Mic className="h-3 w-3 md:h-4 md:w-4" />
                </Button>
                
                <Button 
                  onClick={handleSendMessage} 
                  disabled={!message.trim() || isLoadingMessages}
                  className="h-9 w-9 md:h-10 md:w-auto md:px-3"
                >
                  <Send className="h-3 w-3 md:h-4 md:w-4" />
                </Button>
              </div>
              
              {/* Empty message warning */}
              {message.length > 0 && !message.trim() && (
                <p className="text-xs text-orange-600 mt-1 px-1">
                  Message cannot be empty or contain only spaces
                </p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <VoiceRecordingModal
        isOpen={isVoiceModalOpen}
        onClose={() => setIsVoiceModalOpen(false)}
        onSendVoice={handleVoiceMessage}
      />
    </>
  );
}