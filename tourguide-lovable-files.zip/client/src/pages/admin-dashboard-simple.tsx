export default function AdminDashboardSimple() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>
      <p>Simple admin dashboard is working!</p>
    </div>
  );
}