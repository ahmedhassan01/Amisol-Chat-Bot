export default function AdminTest() {
  return (
    <div className="p-8">
      <h1>Admin Test Page</h1>
      <p>This is a simple test page to verify routing works.</p>
    </div>
  );
}