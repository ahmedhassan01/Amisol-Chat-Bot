import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ArrowLeft, Calendar, Building2, MessageCircle, User, Clock, Settings, ChevronDown, Bell, Trash2, CheckCheck } from "lucide-react";
import { useWebSocket } from "@/hooks/use-websocket";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import GuideProfileModal from "@/components/guide-profile-modal";
import GuideChatModal from "@/components/guide-chat-modal";
import NotificationBadge from "@/components/notification-badge";
import GuideSelfAssignmentModal from "@/components/guide-self-assignment-modal";
import type { Guide, GuideAssignment, ChatSession, Hotel } from "@shared/schema";

export default function GuideDashboard() {
  const [selectedGuideId, setSelectedGuideId] = useState<number | null>(null);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [newMessageCount, setNewMessageCount] = useState(0);
  const [selectedChatSession, setSelectedChatSession] = useState<ChatSession | null>(null);
  const [isChatModalOpen, setIsChatModalOpen] = useState(false);
  const [isSelfAssignmentModalOpen, setIsSelfAssignmentModalOpen] = useState(false);
  const { toast } = useToast();

  const { data: guides = [] } = useQuery<Guide[]>({
    queryKey: ["/api/guides"],
  });

  const { data: assignments = [] } = useQuery<(GuideAssignment & { guide: Guide; hotel: Hotel })[]>({
    queryKey: ["/api/guide-assignments"],
  });

  // Auto-select first guide if none selected and guides are loaded
  const currentGuideId = selectedGuideId || (guides.length > 0 ? guides[0].id : null);
  
  const { data: chatSessions = [], refetch: refetchChatSessions } = useQuery<(ChatSession & { guide?: Guide })[]>({
    queryKey: ["/api/chat-sessions", currentGuideId],
    queryFn: async () => {
      const guideId = currentGuideId?.toString() || '';
      const response = await fetch(`/api/chat-sessions?userId=${guideId}`);
      if (!response.ok) throw new Error('Failed to fetch chat sessions');
      return response.json();
    },
    enabled: !!currentGuideId,
  });

  // Delete chat session mutation
  const deleteSessionMutation = useMutation({
    mutationFn: async (sessionId: number) => {
      const guideId = currentGuideId?.toString() || '';
      const response = await fetch(`/api/chat-sessions/${sessionId}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: guideId }),
      });
      if (!response.ok) throw new Error('Failed to delete session');
      return response.json();
    },
    onSuccess: () => {
      refetchChatSessions();
      toast({
        title: "Session Deleted",
        description: "The conversation has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete the conversation.",
        variant: "destructive",
      });
    }
  });

  // Mark session as read mutation
  const markSessionReadMutation = useMutation({
    mutationFn: async (sessionId: number) => {
      const guideId = currentGuideId?.toString() || '';
      const response = await fetch(`/api/chat-sessions/${sessionId}/mark-read`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: guideId }),
      });
      if (!response.ok) throw new Error('Failed to mark as read');
      return response.json();
    },
    onSuccess: () => {
      // Refresh both chat sessions and unread counts with specific parameters
      queryClient.invalidateQueries({ queryKey: ["/api/chat-sessions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/guide-unread-counts", currentGuideId] });
      queryClient.invalidateQueries({ queryKey: ["/api/guide-unread-counts"] });
      // Force refetch immediately
      setTimeout(() => {
        queryClient.refetchQueries({ queryKey: ["/api/guide-unread-counts", currentGuideId] });
      }, 100);
      toast({
        title: "Marked as Read",
        description: "All messages in this conversation are now marked as read.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to mark messages as read.",
        variant: "destructive",
      });
    }
  });

  // WebSocket connection for real-time notifications
  const { sendMessage } = useWebSocket(null, {
    onMessage: (data: any) => {
      if (data.type === 'chat_message') {
        // Show notification for new tourist messages
        if (data.message && data.message.senderType === 'user') {
          setNewMessageCount(prev => prev + 1);
          toast({
            title: "New Message from Tourist",
            description: `${data.message.content.substring(0, 50)}...`,
            action: (
              <button 
                onClick={() => refetchChatSessions()}
                className="text-blue-600 underline text-sm"
              >
                View
              </button>
            ),
          });
        }
        refetchChatSessions();
      }
    }
  });

  const activeGuide = guides.find((g) => g.id === currentGuideId);
  const guideAssignments = assignments.filter((a) => a.guideId === currentGuideId);
  const activeSessions = chatSessions.filter((s) => s.isActive && s.guideId === currentGuideId);

  // Query to get actual unread message counts for the current guide
  const { data: unreadCounts = {} } = useQuery<Record<number, number>>({
    queryKey: ["/api/guide-unread-counts", currentGuideId],
    queryFn: async () => {
      if (!currentGuideId) return {};
      const response = await fetch(`/api/guide-unread-counts?guideId=${currentGuideId}&timestamp=${Date.now()}`);
      if (!response.ok) throw new Error('Failed to fetch unread counts');
      return response.json();
    },
    refetchInterval: 2000, // Check for unread messages every 2 seconds
    enabled: !!currentGuideId,
  });

  // Check for unread messages using proper API-based counts
  const getUnreadMessageCount = (sessionId: number) => {
    return unreadCounts[sessionId] || 0;
  };

  // Function to check if session has recent tourist messages
  const hasRecentTouristMessage = (sessionId: number) => {
    return getUnreadMessageCount(sessionId) > 0;
  };

  // Total unread messages for current guide
  const totalUnreadMessages = Object.values(unreadCounts).reduce((total, count) => total + count, 0);

  // No longer need to fetch individual session messages since we use API-based unread counts

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href="/">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="mr-2" size={16} />
                  Back to Chat
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Guide Dashboard</h1>
                <p className="text-sm text-gray-600">Manage your assignments and chat sessions</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              {/* Guide Switcher */}
              <div className="flex items-center space-x-2">
                <span className="text-sm text-gray-600">Viewing:</span>
                <Select 
                  value={currentGuideId?.toString() || ""} 
                  onValueChange={(value) => setSelectedGuideId(parseInt(value))}
                >
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Select a guide" />
                  </SelectTrigger>
                  <SelectContent>
                    {guides.map((guide) => (
                      <SelectItem key={guide.id} value={guide.id.toString()}>
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span>{guide.name}</span>
                          <span className="text-gray-500 text-xs">({guide.email})</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button 
              onClick={() => setIsProfileModalOpen(true)}
              variant="outline"
              size="sm"
              className="flex items-center space-x-2"
            >
              <Settings className="w-4 h-4" />
              <span>Profile</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeGuide && (
          <div className="mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-travel-blue rounded-full flex items-center justify-center">
                    <User className="text-white" size={24} />
                  </div>
                  <div className="flex-1">
                    <h2 className="text-2xl font-bold text-gray-900">{activeGuide.name}</h2>
                    <p className="text-gray-600">{activeGuide.specialties?.join(", ")}</p>
                    <div className="flex items-center space-x-4 mt-2">
                      <Badge variant="secondary">
                        ⭐ {activeGuide.rating || 0} rating
                      </Badge>
                      <Badge variant="secondary">
                        {activeGuide.totalHelped || 0} guests helped
                      </Badge>
                      <Badge variant="secondary">
                        <Clock className="mr-1" size={12} />
                        {activeGuide.avgResponseTime || 0}m avg response
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="w-2 h-2 bg-success-green rounded-full"></div>
                      <span className="text-sm text-success-green font-medium">Available</span>
                    </div>
                    <p className="text-sm text-gray-500 mb-3">Languages: {activeGuide.languages?.join(", ")}</p>
                    <div className="flex space-x-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setIsSelfAssignmentModalOpen(true)}
                        className="text-xs"
                      >
                        <Calendar className="mr-1" size={14} />
                        New Assignment
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setIsProfileModalOpen(true)}
                        className="text-xs"
                      >
                        <Settings className="mr-1" size={14} />
                        Edit Profile
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <Tabs defaultValue="assignments" className="space-y-6" onValueChange={(value) => {
          if (value === 'chats') {
            setNewMessageCount(0);
          }
        }}>
          <TabsList>
            <TabsTrigger value="assignments">
              <Building2 className="mr-2" size={16} />
              Hotel Assignments
            </TabsTrigger>
            <TabsTrigger value="chats" className="relative">
              <MessageCircle className="mr-2" size={16} />
              Active Chats ({activeSessions.length})
              {totalUnreadMessages > 0 && (
                <NotificationBadge count={totalUnreadMessages} />
              )}
            </TabsTrigger>
            <TabsTrigger value="schedule">
              <Calendar className="mr-2" size={16} />
              Weekly Schedule
            </TabsTrigger>
          </TabsList>

          <TabsContent value="assignments">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {guideAssignments.map((assignment: any) => (
                <Card key={assignment.id}>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{assignment.hotel?.name}</span>
                      <Badge variant="default">
                        {assignment.customShifts?.length || 0} shifts
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm text-gray-600">
                        <strong>Days:</strong> {assignment.daysOfWeek?.map((day: number) => 
                          ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][day]
                        ).join(", ") || "None"}
                      </p>
                      <p className="text-sm text-gray-600">
                        <strong>Shifts:</strong> {assignment.customShifts?.map((shift: any) => 
                          `${shift.startTime}-${shift.endTime}`
                        ).join(", ") || "None"}
                      </p>
                      <p className="text-sm text-gray-600">
                        <strong>Address:</strong> {assignment.hotel?.address || "N/A"}
                      </p>
                      {assignment.hotel?.phone && (
                        <p className="text-sm text-gray-600">
                          <strong>Phone:</strong> {assignment.hotel.phone}
                        </p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
              {guideAssignments.length === 0 && (
                <Card className="col-span-full">
                  <CardContent className="p-6 text-center">
                    <Building2 className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No assignments yet</h3>
                    <p className="text-gray-600">Your hotel assignments will appear here once scheduled.</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="chats">
            <div className="space-y-4">
              {activeSessions.map((session: any) => (
                <Card key={session.id} className="hover:shadow-md transition-shadow relative">
                  <CardContent className="p-6">
                    <NotificationBadge count={getUnreadMessageCount(session.id)} />
                    <div className="flex items-center justify-between">
                      <div 
                        className="flex-1 cursor-pointer"
                        onClick={() => {
                          setSelectedChatSession(session);
                          setIsChatModalOpen(true);
                        }}
                      >
                        <div className="flex items-center space-x-2">
                          <h3 className="font-medium text-gray-900 capitalize">
                            {session.category.replace("-", " ")}
                          </h3>
                          {getUnreadMessageCount(session.id) > 0 && (
                            <Bell size={14} className="text-blue-600" />
                          )}
                        </div>
                        <p className="text-sm text-gray-600">
                          Started {new Date(session.createdAt).toLocaleString()}
                        </p>
                        <p className="text-xs text-blue-600 mt-1">
                          Click to open chat and reply
                        </p>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-success-green rounded-full"></div>
                          <span className="text-sm text-success-green">Active</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          {/* Mark as Read Button */}
                          {getUnreadMessageCount(session.id) > 0 && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={(e) => {
                                e.stopPropagation();
                                markSessionReadMutation.mutate(session.id);
                              }}
                              disabled={markSessionReadMutation.isPending}
                              className="flex items-center space-x-1 text-green-600 hover:text-green-700 hover:bg-green-50"
                            >
                              <CheckCheck size={14} />
                              <span className="text-xs">Mark Read</span>
                            </Button>
                          )}
                          {/* Delete Button */}
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={(e) => {
                              e.stopPropagation();
                              if (confirm('Are you sure you want to delete this conversation?')) {
                                deleteSessionMutation.mutate(session.id);
                              }
                            }}
                            disabled={deleteSessionMutation.isPending}
                            className="flex items-center space-x-1 text-red-600 hover:text-red-700 hover:bg-red-50"
                          >
                            <Trash2 size={14} />
                            <span className="text-xs">Delete</span>
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
              {activeSessions.length === 0 && (
                <Card>
                  <CardContent className="p-6 text-center">
                    <MessageCircle className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No active chats</h3>
                    <p className="text-gray-600">Your chat sessions will appear here when guests contact you.</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          <TabsContent value="schedule">
            <Card>
              <CardHeader>
                <CardTitle>Weekly Schedule</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-7 gap-4">
                  {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day, index) => {
                    const dayAssignments = guideAssignments.filter((a: any) => 
                      a.daysOfWeek?.includes(index)
                    );
                    return (
                      <div key={day} className="text-center">
                        <h3 className="font-medium text-gray-900 mb-2">{day}</h3>
                        <div className="space-y-2">
                          {dayAssignments.map((assignment: any) => 
                            assignment.customShifts?.map((shift: any, shiftIndex: number) => (
                              <div
                                key={`${assignment.id}-${shiftIndex}`}
                                className="p-2 rounded text-xs bg-blue-100 text-blue-800"
                              >
                                <div className="font-medium">{shift.startTime}-{shift.endTime}</div>
                                <div className="truncate">{assignment.hotel?.name}</div>
                              </div>
                            ))
                          )}
                          {dayAssignments.length === 0 && (
                            <div className="p-2 text-xs text-gray-400 border border-dashed border-gray-300 rounded">
                              No assignments
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Profile Modal */}
      {currentGuideId && (
        <GuideProfileModal 
          isOpen={isProfileModalOpen}
          onClose={() => setIsProfileModalOpen(false)}
          guideId={currentGuideId}
        />
      )}

      {/* Chat Modal */}
      {selectedChatSession && activeGuide && (
        <GuideChatModal
          isOpen={isChatModalOpen}
          onClose={() => {
            setIsChatModalOpen(false);
            setSelectedChatSession(null);
            refetchChatSessions();
          }}
          chatSession={selectedChatSession}
          currentGuide={activeGuide}
        />
      )}

      {/* Self Assignment Modal */}
      <GuideSelfAssignmentModal
        isOpen={isSelfAssignmentModalOpen}
        onClose={() => setIsSelfAssignmentModalOpen(false)}
      />
    </div>
  );
}
