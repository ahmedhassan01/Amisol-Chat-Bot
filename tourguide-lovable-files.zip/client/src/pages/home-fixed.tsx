import { useState } from "react";
import { Link } from "wouter";
import { MapPin, Settings, Bus } from "lucide-react";
import CategorySidebar from "@/components/category-sidebar";
import ChatInterface from "@/components/chat-interface";
import GuideInfoPanel from "@/components/guide-info-panel";
import HotelSelection from "@/components/hotel-selection";

function SafeGuideInfoPanel() {
  try {
    return <GuideInfoPanel />;
  } catch (error) {
    console.error('GuideInfoPanel error:', error);
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-4">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Guides & Info</h3>
        <p className="text-sm text-gray-600">Loading guide information...</p>
      </div>
    );
  }
}

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [chatSession, setChatSession] = useState<any>(null);
  const [selectedHotel, setSelectedHotel] = useState<any>(null);
  const [showHotelSelection, setShowHotelSelection] = useState(false);

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    setShowHotelSelection(true);
    setChatSession(null);
    setSelectedHotel(null);
  };

  const handleHotelSelect = (hotel: any, session: any) => {
    setSelectedHotel(hotel);
    setChatSession(session);
    setShowHotelSelection(false);
  };

  const handleBackToCategories = () => {
    setShowHotelSelection(false);
    setSelectedCategory(null);
    setChatSession(null);
    setSelectedHotel(null);
  };

  return (
    <div className="bg-gray-50 min-h-screen font-sans">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2 sm:space-x-3">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <MapPin className="text-white" size={16} />
              </div>
              <div>
                <h1 className="text-lg sm:text-xl font-bold text-gray-900">TourGuide Chat</h1>
                <p className="text-xs text-gray-500 hidden sm:block">24/7 Travel Assistance</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="hidden md:flex items-center space-x-2 text-sm">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-gray-600">24/7 Support</span>
              </div>
              
              <div className="flex items-center space-x-2">
                <Link href="/guide-dashboard">
                  <button className="inline-flex items-center px-2 py-2 sm:px-3 border border-gray-300 rounded-md text-xs sm:text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors">
                    <Bus className="mr-1 sm:mr-2" size={14} />
                    Guide
                  </button>
                </Link>
                <Link href="/admin">
                  <button className="inline-flex items-center px-2 py-2 sm:px-3 border border-transparent rounded-md text-xs sm:text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 transition-colors">
                    <Settings className="mr-1 sm:mr-2" size={14} />
                    Admin
                  </button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-2 sm:px-4 lg:px-8 py-2 sm:py-4 lg:py-6">
        <div className="flex flex-col lg:grid lg:grid-cols-4 gap-3 sm:gap-4 lg:gap-6 min-h-[calc(100vh-80px)] sm:min-h-[calc(100vh-100px)] lg:h-[calc(100vh-120px)]">
          {/* Category/Hotel Selection */}
          <div className="lg:col-span-1 order-1 lg:order-none">
            {!showHotelSelection ? (
              <CategorySidebar 
                selectedCategory={selectedCategory} 
                onSelectCategory={handleCategorySelect}
              />
            ) : (
              <HotelSelection 
                selectedCategory={selectedCategory!}
                onHotelSelected={handleHotelSelect}
                onBack={handleBackToCategories}
              />
            )}
          </div>
          
          {/* Chat Interface */}
          <div className="lg:col-span-2 order-2 lg:order-none flex-1 min-h-[400px] lg:min-h-0">
            {chatSession ? (
              <ChatInterface 
                selectedCategory={selectedCategory}
                chatSession={chatSession}
                selectedHotel={selectedHotel}
              />
            ) : (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 h-full flex items-center justify-center">
                <div className="text-center p-4 sm:p-8">
                  <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-2">
                    {!selectedCategory ? "Select a Category" : "Choose Your Hotel"}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {!selectedCategory 
                      ? "Choose a category to start your conversation with our expert guides" 
                      : "Select your hotel to connect with the right guide"
                    }
                  </p>
                </div>
              </div>
            )}
          </div>
          
          {/* Guide Info Panel - Hidden on mobile */}
          <div className="lg:col-span-1 order-3 lg:order-none hidden lg:block">
            <GuideInfoPanel />
          </div>
        </div>
      </div>

      {/* Mobile Floating Action Button */}
      <div className="fixed bottom-6 right-6 sm:hidden z-50">
        <Link href="/guide-dashboard">
          <button className="bg-blue-600 hover:bg-blue-700 text-white rounded-full p-4 shadow-lg transition-all duration-200 hover:scale-110">
            <Bus size={20} />
          </button>
        </Link>
      </div>
    </div>
  );
}