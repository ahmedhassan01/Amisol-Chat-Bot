import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { Users, Building2, Calendar, Megaphone, Phone, Plus, Edit, Trash2, BarChart3 } from "lucide-react";
import { Link } from "wouter";

export default function AdminWorking() {
  const [activeTab, setActiveTab] = useState("overview");
  const { toast } = useToast();
  const { getAuthHeaders } = useAuth();
  const queryClient = useQueryClient();

  // Queries
  const { data: guides = [] } = useQuery({ queryKey: ["/api/guides"] });
  const { data: hotels = [] } = useQuery({ queryKey: ["/api/hotels"] });
  const { data: assignments = [] } = useQuery({ queryKey: ["/api/guide-assignments"] });
  const { data: announcements = [] } = useQuery({ queryKey: ["/api/announcements"] });
  const { data: emergencyContacts = [] } = useQuery({ queryKey: ["/api/emergency-contacts"] });

  // Guide Management
  const [newGuide, setNewGuide] = useState({ name: "", email: "", phone: "", languages: "", specialties: "" });
  const [editingGuide, setEditingGuide] = useState(null);

  const createGuideMutation = useMutation({
    mutationFn: async (guide) => {
      const formattedGuide = {
        ...guide,
        languages: guide.languages ? guide.languages.split(',').map(s => s.trim()).filter(s => s) : [],
        specialties: guide.specialties ? guide.specialties.split(',').map(s => s.trim()).filter(s => s) : []
      };
      const response = await fetch("/api/guides", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          ...getAuthHeaders()
        },
        body: JSON.stringify(formattedGuide),
      });
      if (!response.ok) throw new Error("Failed to create guide");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/guides"] });
      setNewGuide({ name: "", email: "", phone: "", languages: "", specialties: "" });
      toast({ title: "Guide created successfully" });
    },
  });

  const updateGuideMutation = useMutation({
    mutationFn: async ({ id, ...guide }) => {
      const response = await fetch(`/api/guides/${id}`, {
        method: "PATCH",
        headers: { 
          "Content-Type": "application/json",
          ...getAuthHeaders()
        },
        body: JSON.stringify(guide),
      });
      if (!response.ok) throw new Error("Failed to update guide");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/guides"] });
      setEditingGuide(null);
      toast({ title: "Guide updated successfully" });
    },
  });

  const deleteGuideMutation = useMutation({
    mutationFn: async (id) => {
      const response = await fetch(`/api/guides/${id}`, { 
        method: "DELETE",
        headers: getAuthHeaders()
      });
      if (!response.ok) throw new Error("Failed to delete guide");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/guides"] });
      toast({ title: "Guide deleted successfully" });
    },
  });

  // Hotel Management
  const [newHotel, setNewHotel] = useState({ name: "", address: "", phone: "", email: "" });
  const [editingHotel, setEditingHotel] = useState(null);

  const createHotelMutation = useMutation({
    mutationFn: async (hotel) => {
      const response = await fetch("/api/hotels", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          ...getAuthHeaders()
        },
        body: JSON.stringify(hotel),
      });
      if (!response.ok) throw new Error("Failed to create hotel");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/hotels"] });
      setNewHotel({ name: "", address: "", phone: "", email: "" });
      toast({ title: "Hotel created successfully" });
    },
  });

  const updateHotelMutation = useMutation({
    mutationFn: async ({ id, ...hotel }) => {
      const response = await fetch(`/api/hotels/${id}`, {
        method: "PATCH",
        headers: { 
          "Content-Type": "application/json",
          ...getAuthHeaders()
        },
        body: JSON.stringify(hotel),
      });
      if (!response.ok) throw new Error("Failed to update hotel");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/hotels"] });
      setEditingHotel(null);
      toast({ title: "Hotel updated successfully" });
    },
  });

  const deleteHotelMutation = useMutation({
    mutationFn: async (id) => {
      const response = await fetch(`/api/hotels/${id}`, { 
        method: "DELETE",
        headers: getAuthHeaders()
      });
      if (!response.ok) throw new Error("Failed to delete hotel");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/hotels"] });
      toast({ title: "Hotel deleted successfully" });
    },
  });

  // Announcement Management
  const [newAnnouncement, setNewAnnouncement] = useState({ title: "", content: "", type: "info" });
  
  // Announcement editing
  const [editingAnnouncement, setEditingAnnouncement] = useState<any>(null);
  const [isEditAnnouncementModalOpen, setIsEditAnnouncementModalOpen] = useState(false);
  
  // File upload for announcements
  const [announcementFile, setAnnouncementFile] = useState<File | null>(null);

  const createAnnouncementMutation = useMutation({
    mutationFn: async (announcement: any) => {
      const formData = new FormData();
      formData.append('title', announcement.title);
      formData.append('content', announcement.content);
      formData.append('type', announcement.type);
      
      if (announcementFile) {
        formData.append('file', announcementFile);
      }

      const response = await fetch("/api/announcements", {
        method: "POST",
        headers: getAuthHeaders(),
        body: formData,
      });
      if (!response.ok) throw new Error("Failed to create announcement");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/announcements"] });
      setNewAnnouncement({ title: "", content: "", type: "info" });
      setAnnouncementFile(null);
      toast({ title: "Announcement created successfully" });
    },
  });

  // Update announcement mutation
  const updateAnnouncementMutation = useMutation({
    mutationFn: async ({ id, announcement }: { id: number, announcement: any }) => {
      const formData = new FormData();
      formData.append('title', announcement.title);
      formData.append('content', announcement.content);
      formData.append('type', announcement.type);
      
      if (announcementFile) {
        formData.append('file', announcementFile);
      } else if (!announcement.fileUrl) {
        // If fileUrl is null/empty, it means the user removed the file
        formData.append('removeFile', 'true');
      }

      const response = await fetch(`/api/announcements/${id}`, {
        method: "PUT",
        headers: getAuthHeaders(),
        body: formData,
      });
      if (!response.ok) throw new Error("Failed to update announcement");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/announcements"] });
      setIsEditAnnouncementModalOpen(false);
      setEditingAnnouncement(null);
      setAnnouncementFile(null);
      toast({ title: "Announcement updated successfully" });
    },
  });

  const deleteAnnouncementMutation = useMutation({
    mutationFn: async (id) => {
      const response = await fetch(`/api/announcements/${id}`, { 
        method: "DELETE",
        headers: getAuthHeaders()
      });
      if (!response.ok) throw new Error("Failed to delete announcement");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/announcements"] });
      toast({ title: "Announcement deleted successfully" });
    },
  });

  // Emergency Contact Management
  const [newContact, setNewContact] = useState({ name: "", phone: "", whatsappNumber: "", type: "" });

  // Assignment Management
  const [newAssignment, setNewAssignment] = useState({
    guideId: "",
    hotelId: "",
    daysOfWeek: [],
    customShifts: [{ startTime: "09:00", endTime: "17:00" }],
    weekStartDates: [""],
    isActive: true,
  });
  const [editingAssignment, setEditingAssignment] = useState(null);

  const createContactMutation = useMutation({
    mutationFn: async (contact) => {
      const response = await fetch("/api/emergency-contacts", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          ...getAuthHeaders()
        },
        body: JSON.stringify(contact),
      });
      if (!response.ok) throw new Error("Failed to create contact");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-contacts"] });
      setNewContact({ name: "", phone: "", whatsappNumber: "", type: "" });
      toast({ title: "Emergency contact created successfully" });
    },
  });

  const deleteContactMutation = useMutation({
    mutationFn: async (id) => {
      const response = await fetch(`/api/emergency-contacts/${id}`, { 
        method: "DELETE",
        headers: getAuthHeaders()
      });
      if (!response.ok) throw new Error("Failed to delete contact");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emergency-contacts"] });
      toast({ title: "Emergency contact deleted successfully" });
    },
  });

  // Assignment mutations
  const createAssignmentMutation = useMutation({
    mutationFn: async (assignment) => {
      const response = await fetch("/api/guide-assignments", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          ...getAuthHeaders()
        },
        body: JSON.stringify({
          ...assignment,
          guideId: parseInt(assignment.guideId),
          hotelId: parseInt(assignment.hotelId),
        }),
      });
      if (!response.ok) throw new Error("Failed to create assignment");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/guide-assignments"] });
      setNewAssignment({
        guideId: "",
        hotelId: "",
        daysOfWeek: [],
        customShifts: [{ startTime: "09:00", endTime: "17:00" }],
        weekStartDates: [""],
        isActive: true,
      });
      toast({ title: "Guide assignment created successfully" });
    },
  });

  const deleteAssignmentMutation = useMutation({
    mutationFn: async (id) => {
      const response = await fetch(`/api/guide-assignments/${id}`, { 
        method: "DELETE",
        headers: getAuthHeaders()
      });
      if (!response.ok) throw new Error("Failed to delete assignment");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/guide-assignments"] });
      toast({ title: "Assignment deleted successfully" });
    },
  });

  return (
    <div className="min-h-screen bg-gray-50 p-6 compact-form">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
            <p className="text-gray-600">Manage guides, hotels, assignments, and announcements</p>
          </div>
          <div className="flex gap-4">
            <Link href="/admin-analytics">
              <Button variant="outline">
                <BarChart3 className="mr-2 h-4 w-4" />
                Analytics
              </Button>
            </Link>
            <Link href="/">
              <Button variant="outline">Back to Home</Button>
            </Link>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="guides">Guides</TabsTrigger>
            <TabsTrigger value="hotels">Hotels</TabsTrigger>
            <TabsTrigger value="assignments">Assignments</TabsTrigger>
            <TabsTrigger value="announcements">Announcements</TabsTrigger>
            <TabsTrigger value="emergency">Emergency</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Guides</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{guides.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Hotels</CardTitle>
                  <Building2 className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{hotels.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Assignments</CardTitle>
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{assignments.length}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Announcements</CardTitle>
                  <Megaphone className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{announcements.length}</div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Guides</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {guides.slice(0, 5).map((guide) => (
                      <div key={guide.id} className="flex items-center justify-between">
                        <div>
                          <div className="font-medium">{guide.name}</div>
                          <div className="text-sm text-gray-500">{guide.email}</div>
                        </div>
                        <Badge variant={guide.isActive ? "secondary" : "destructive"}>
                          {guide.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Announcements</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {announcements.slice(0, 5).map((announcement) => (
                      <div key={announcement.id} className="flex items-center justify-between">
                        <div>
                          <div className="font-medium">{announcement.title}</div>
                          <div className="text-sm text-gray-500">{announcement.content.substring(0, 50)}...</div>
                        </div>
                        <Badge variant={announcement.type === "urgent" ? "destructive" : "secondary"}>
                          {announcement.type || "info"}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Guides Tab */}
          <TabsContent value="guides" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Add New Guide</CardTitle>
                <CardDescription>Create a new tour guide profile</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="guide-name">Name</Label>
                    <Input
                      id="guide-name"
                      value={newGuide.name}
                      onChange={(e) => setNewGuide({ ...newGuide, name: e.target.value })}
                      placeholder="Guide name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="guide-email">Email</Label>
                    <Input
                      id="guide-email"
                      type="email"
                      value={newGuide.email}
                      onChange={(e) => setNewGuide({ ...newGuide, email: e.target.value })}
                      placeholder="guide@example.com"
                    />
                  </div>
                  <div>
                    <Label htmlFor="guide-phone">Phone</Label>
                    <Input
                      id="guide-phone"
                      value={newGuide.phone}
                      onChange={(e) => setNewGuide({ ...newGuide, phone: e.target.value })}
                      placeholder="+1234567890"
                    />
                  </div>
                  <div>
                    <Label htmlFor="guide-languages">Languages</Label>
                    <Input
                      id="guide-languages"
                      value={newGuide.languages}
                      onChange={(e) => setNewGuide({ ...newGuide, languages: e.target.value })}
                      placeholder="English, Arabic, German"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="guide-specialties">Specialties</Label>
                  <Input
                    id="guide-specialties"
                    value={newGuide.specialties}
                    onChange={(e) => setNewGuide({ ...newGuide, specialties: e.target.value })}
                    placeholder="Desert tours, Historical sites, Diving"
                  />
                </div>
                <Button 
                  onClick={() => createGuideMutation.mutate(newGuide)}
                  disabled={createGuideMutation.isPending}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Guide
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Existing Guides</CardTitle>
                <CardDescription>Manage your tour guides</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {guides.map((guide) => (
                    <div key={guide.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="font-medium">{guide.name}</div>
                        <div className="text-sm text-gray-500">{guide.email} • {guide.phone}</div>
                        <div className="text-sm text-gray-500">
                          Languages: {Array.isArray(guide.languages) ? guide.languages.join(", ") : guide.languages || "Not specified"}
                        </div>
                        <div className="text-sm text-gray-500">
                          Specialties: {Array.isArray(guide.specialties) ? guide.specialties.join(", ") : guide.specialties || "Not specified"}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={guide.isActive ? "secondary" : "destructive"}>
                          {guide.isActive ? "Active" : "Inactive"}
                        </Badge>
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm" onClick={() => setEditingGuide(guide)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Edit Guide</DialogTitle>
                              <DialogDescription>Update guide information</DialogDescription>
                            </DialogHeader>
                            {editingGuide && (
                              <div className="space-y-4">
                                <div>
                                  <Label>Name</Label>
                                  <Input
                                    value={editingGuide.name}
                                    onChange={(e) => setEditingGuide({ ...editingGuide, name: e.target.value })}
                                  />
                                </div>
                                <div>
                                  <Label>Email</Label>
                                  <Input
                                    value={editingGuide.email}
                                    onChange={(e) => setEditingGuide({ ...editingGuide, email: e.target.value })}
                                  />
                                </div>
                                <div>
                                  <Label>Phone</Label>
                                  <Input
                                    value={editingGuide.phone || ""}
                                    onChange={(e) => setEditingGuide({ ...editingGuide, phone: e.target.value })}
                                  />
                                </div>
                                <Button 
                                  onClick={() => updateGuideMutation.mutate(editingGuide)}
                                  disabled={updateGuideMutation.isPending}
                                >
                                  Update Guide
                                </Button>
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Guide</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete {guide.name}? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => deleteGuideMutation.mutate(guide.id)}>
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Hotels Tab */}
          <TabsContent value="hotels" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Add New Hotel</CardTitle>
                <CardDescription>Register a new hotel in the system</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="hotel-name">Hotel Name</Label>
                    <Input
                      id="hotel-name"
                      value={newHotel.name}
                      onChange={(e) => setNewHotel({ ...newHotel, name: e.target.value })}
                      placeholder="Hotel name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="hotel-phone">Phone</Label>
                    <Input
                      id="hotel-phone"
                      value={newHotel.phone}
                      onChange={(e) => setNewHotel({ ...newHotel, phone: e.target.value })}
                      placeholder="+1234567890"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="hotel-address">Address</Label>
                  <Input
                    id="hotel-address"
                    value={newHotel.address}
                    onChange={(e) => setNewHotel({ ...newHotel, address: e.target.value })}
                    placeholder="Hotel address"
                  />
                </div>
                <div>
                  <Label htmlFor="hotel-email">Email</Label>
                  <Input
                    id="hotel-email"
                    type="email"
                    value={newHotel.email}
                    onChange={(e) => setNewHotel({ ...newHotel, email: e.target.value })}
                    placeholder="hotel@example.com"
                  />
                </div>
                <Button 
                  onClick={() => createHotelMutation.mutate(newHotel)}
                  disabled={createHotelMutation.isPending}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Hotel
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Existing Hotels</CardTitle>
                <CardDescription>Manage registered hotels</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {hotels.map((hotel) => (
                    <div key={hotel.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="font-medium">{hotel.name}</div>
                        <div className="text-sm text-gray-500">{hotel.address}</div>
                        <div className="text-sm text-gray-500">{hotel.phone} • {hotel.email}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button variant="outline" size="sm" onClick={() => setEditingHotel(hotel)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                          </DialogTrigger>
                          <DialogContent>
                            <DialogHeader>
                              <DialogTitle>Edit Hotel</DialogTitle>
                              <DialogDescription>Update hotel information</DialogDescription>
                            </DialogHeader>
                            {editingHotel && (
                              <div className="space-y-4">
                                <div>
                                  <Label>Hotel Name</Label>
                                  <Input
                                    value={editingHotel.name}
                                    onChange={(e) => setEditingHotel({ ...editingHotel, name: e.target.value })}
                                  />
                                </div>
                                <div>
                                  <Label>Address</Label>
                                  <Input
                                    value={editingHotel.address || ""}
                                    onChange={(e) => setEditingHotel({ ...editingHotel, address: e.target.value })}
                                  />
                                </div>
                                <div>
                                  <Label>Phone</Label>
                                  <Input
                                    value={editingHotel.phone || ""}
                                    onChange={(e) => setEditingHotel({ ...editingHotel, phone: e.target.value })}
                                  />
                                </div>
                                <div>
                                  <Label>Email</Label>
                                  <Input
                                    value={editingHotel.email || ""}
                                    onChange={(e) => setEditingHotel({ ...editingHotel, email: e.target.value })}
                                  />
                                </div>
                                <Button 
                                  onClick={() => updateHotelMutation.mutate(editingHotel)}
                                  disabled={updateHotelMutation.isPending}
                                >
                                  Update Hotel
                                </Button>
                              </div>
                            )}
                          </DialogContent>
                        </Dialog>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Hotel</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete {hotel.name}? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => deleteHotelMutation.mutate(hotel.id)}>
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Assignments Tab */}
          <TabsContent value="assignments" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Create Guide Assignment</CardTitle>
                <CardDescription>Assign guides to hotels with detailed schedules (backup for when guides forget)</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="assignment-guide">Guide</Label>
                    <Select
                      value={newAssignment.guideId}
                      onValueChange={(value) => setNewAssignment({ ...newAssignment, guideId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select a guide" />
                      </SelectTrigger>
                      <SelectContent>
                        {guides.map((guide) => (
                          <SelectItem key={guide.id} value={guide.id.toString()}>
                            {guide.name || `Guide ${guide.id}`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="assignment-hotel">Hotel</Label>
                    <Select
                      value={newAssignment.hotelId}
                      onValueChange={(value) => setNewAssignment({ ...newAssignment, hotelId: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select a hotel" />
                      </SelectTrigger>
                      <SelectContent>
                        {hotels.map((hotel) => (
                          <SelectItem key={hotel.id} value={hotel.id.toString()}>
                            {hotel.name || `Hotel ${hotel.id}`}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label>Days of Week</Label>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {[
                      { value: 0, label: "Sunday" },
                      { value: 1, label: "Monday" },
                      { value: 2, label: "Tuesday" },
                      { value: 3, label: "Wednesday" },
                      { value: 4, label: "Thursday" },
                      { value: 5, label: "Friday" },
                      { value: 6, label: "Saturday" }
                    ].map((day) => (
                      <label key={day.value} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          checked={newAssignment.daysOfWeek.includes(day.value)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setNewAssignment({
                                ...newAssignment,
                                daysOfWeek: [...newAssignment.daysOfWeek, day.value]
                              });
                            } else {
                              setNewAssignment({
                                ...newAssignment,
                                daysOfWeek: newAssignment.daysOfWeek.filter(d => d !== day.value)
                              });
                            }
                          }}
                        />
                        <span className="text-sm">{day.label}</span>
                      </label>
                    ))}
                  </div>
                </div>

                <div>
                  <Label>Shift Times</Label>
                  {newAssignment.customShifts.map((shift, index) => (
                    <div key={index} className="flex gap-2 items-center mt-2">
                      <Input
                        type="time"
                        value={shift.startTime}
                        onChange={(e) => {
                          const updatedShifts = [...newAssignment.customShifts];
                          updatedShifts[index] = { ...shift, startTime: e.target.value };
                          setNewAssignment({ ...newAssignment, customShifts: updatedShifts });
                        }}
                      />
                      <span>to</span>
                      <Input
                        type="time"
                        value={shift.endTime}
                        onChange={(e) => {
                          const updatedShifts = [...newAssignment.customShifts];
                          updatedShifts[index] = { ...shift, endTime: e.target.value };
                          setNewAssignment({ ...newAssignment, customShifts: updatedShifts });
                        }}
                      />
                      {newAssignment.customShifts.length > 1 && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const updatedShifts = newAssignment.customShifts.filter((_, i) => i !== index);
                            setNewAssignment({ ...newAssignment, customShifts: updatedShifts });
                          }}
                        >
                          Remove
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2"
                    onClick={() => {
                      setNewAssignment({
                        ...newAssignment,
                        customShifts: [...newAssignment.customShifts, { startTime: "09:00", endTime: "17:00" }]
                      });
                    }}
                  >
                    Add Shift
                  </Button>
                </div>

                <div>
                  <Label>Week Start Dates</Label>
                  {newAssignment.weekStartDates.map((date, index) => (
                    <div key={index} className="flex gap-2 items-center mt-2">
                      <Input
                        type="date"
                        value={date}
                        onChange={(e) => {
                          const updatedDates = [...newAssignment.weekStartDates];
                          updatedDates[index] = e.target.value;
                          setNewAssignment({ ...newAssignment, weekStartDates: updatedDates });
                        }}
                      />
                      {newAssignment.weekStartDates.length > 1 && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            const updatedDates = newAssignment.weekStartDates.filter((_, i) => i !== index);
                            setNewAssignment({ ...newAssignment, weekStartDates: updatedDates });
                          }}
                        >
                          Remove
                        </Button>
                      )}
                    </div>
                  ))}
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2"
                    onClick={() => {
                      setNewAssignment({
                        ...newAssignment,
                        weekStartDates: [...newAssignment.weekStartDates, ""]
                      });
                    }}
                  >
                    Add Week
                  </Button>
                </div>

                <Button 
                  onClick={() => createAssignmentMutation.mutate(newAssignment)}
                  disabled={createAssignmentMutation.isPending}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Create Assignment
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Existing Assignments</CardTitle>
                <CardDescription>Manage guide assignments and schedules</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {assignments.map((assignment) => (
                    <div key={assignment.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="font-medium">
                          {assignment.guide?.name || `Guide ${assignment.guideId}`} → {assignment.hotel?.name || `Hotel ${assignment.hotelId}`}
                        </div>
                        <div className="text-sm text-gray-500">
                          Days: {assignment.daysOfWeek?.map(day => 
                            ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][day]
                          ).join(", ")}
                        </div>
                        <div className="text-sm text-gray-500">
                          Times: {assignment.customShifts?.map(shift => 
                            `${shift.startTime}-${shift.endTime}`
                          ).join(", ")}
                        </div>
                        <div className="text-sm text-gray-500">
                          Weeks: {assignment.weekStartDates?.join(", ")}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={assignment.isActive ? "secondary" : "destructive"}>
                          {assignment.isActive ? "Active" : "Inactive"}
                        </Badge>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Assignment</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete this assignment? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => deleteAssignmentMutation.mutate(assignment.id)}>
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Announcements Tab */}
          <TabsContent value="announcements" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Create Announcement</CardTitle>
                <CardDescription>Send important messages to all users</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="announcement-title">Title</Label>
                  <Input
                    id="announcement-title"
                    value={newAnnouncement.title}
                    onChange={(e) => setNewAnnouncement({ ...newAnnouncement, title: e.target.value })}
                    placeholder="Announcement title"
                  />
                </div>
                <div>
                  <Label htmlFor="announcement-content">Content</Label>
                  <Textarea
                    id="announcement-content"
                    value={newAnnouncement.content}
                    onChange={(e) => setNewAnnouncement({ ...newAnnouncement, content: e.target.value })}
                    placeholder="Announcement content"
                    rows={4}
                  />
                </div>
                <div>
                  <Label htmlFor="announcement-type">Type</Label>
                  <Select
                    value={newAnnouncement.type}
                    onValueChange={(value) => setNewAnnouncement({ ...newAnnouncement, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="info">Info</SelectItem>
                      <SelectItem value="warning">Warning</SelectItem>
                      <SelectItem value="urgent">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {/* File Upload */}
                <div>
                  <Label htmlFor="announcement-file">Attach File (PDF, Excel, Images, Videos, Audio, PowerPoint, etc.)</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <Input
                      id="announcement-file"
                      type="file"
                      accept=".pdf,.xlsx,.xls,.doc,.docx,.jpg,.jpeg,.png,.gif,.webp,.txt,.csv,.zip,.rar,.mp4,.avi,.mov,.wmv,.flv,.webm,.mkv,.m4v,.3gp,.mp3,.wav,.ogg,.pptx,.ppt"
                      onChange={(e) => {
                        const file = e.target.files?.[0] || null;
                        setAnnouncementFile(file);
                      }}
                      className="flex-1"
                    />
                    {announcementFile && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setAnnouncementFile(null)}
                      >
                        Clear
                      </Button>
                    )}
                  </div>
                  {announcementFile && (
                    <p className="text-sm text-gray-600 mt-1">
                      Selected: {announcementFile.name} ({(announcementFile.size / 1024 / 1024).toFixed(1)} MB)
                    </p>
                  )}
                </div>
                
                <Button 
                  onClick={() => createAnnouncementMutation.mutate(newAnnouncement)}
                  disabled={createAnnouncementMutation.isPending}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Create Announcement
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Active Announcements</CardTitle>
                <CardDescription>Manage system announcements</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {announcements.map((announcement) => (
                    <div key={announcement.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="font-medium">{announcement.title}</div>
                        <div className="text-sm text-gray-500">{announcement.content}</div>
                        <div className="text-xs text-gray-400 mt-1">
                          {new Date(announcement.createdAt).toLocaleDateString()}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={announcement.type === "urgent" ? "destructive" : 
                                     announcement.type === "warning" ? "default" : "secondary"}>
                          {announcement.type || "info"}
                        </Badge>
                        
                        {/* Show file download link if available */}
                        {announcement.fileUrl && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => window.open(announcement.fileUrl, '_blank')}
                          >
                            📎
                          </Button>
                        )}
                        
                        {/* Edit Button */}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setEditingAnnouncement(announcement);
                            setIsEditAnnouncementModalOpen(true);
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Announcement</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete this announcement? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => deleteAnnouncementMutation.mutate(announcement.id)}>
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Emergency Contacts Tab */}
          <TabsContent value="emergency" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Add Emergency Contact</CardTitle>
                <CardDescription>Add important emergency contact information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="contact-name">Contact Name</Label>
                    <Input
                      id="contact-name"
                      value={newContact.name}
                      onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                      placeholder="Emergency contact name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="contact-type">Type</Label>
                    <Input
                      id="contact-type"
                      value={newContact.type}
                      onChange={(e) => setNewContact({ ...newContact, type: e.target.value })}
                      placeholder="Medical, Police, etc."
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="contact-phone">Phone Number</Label>
                    <Input
                      id="contact-phone"
                      value={newContact.phone}
                      onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                      placeholder="+1234567890"
                    />
                  </div>
                  <div>
                    <Label htmlFor="contact-whatsapp">WhatsApp</Label>
                    <Input
                      id="contact-whatsapp"
                      value={newContact.whatsappNumber}
                      onChange={(e) => setNewContact({ ...newContact, whatsappNumber: e.target.value })}
                      placeholder="+1234567890"
                    />
                  </div>
                </div>
                <Button 
                  onClick={() => createContactMutation.mutate(newContact)}
                  disabled={createContactMutation.isPending}
                >
                  <Plus className="mr-2 h-4 w-4" />
                  Add Contact
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Emergency Contacts</CardTitle>
                <CardDescription>Manage emergency contact information</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {emergencyContacts.map((contact) => (
                    <div key={contact.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex-1">
                        <div className="font-medium">{contact.name}</div>
                        <div className="text-sm text-gray-500">{contact.type}</div>
                        <div className="text-sm text-gray-500">
                          Phone: {contact.phone} • WhatsApp: {contact.whatsappNumber}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={contact.isActive ? "secondary" : "destructive"}>
                          {contact.isActive ? "Active" : "Inactive"}
                        </Badge>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="outline" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Delete Emergency Contact</AlertDialogTitle>
                              <AlertDialogDescription>
                                Are you sure you want to delete {contact.name}? This action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => deleteContactMutation.mutate(contact.id)}>
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Edit Announcement Modal */}
      <Dialog open={isEditAnnouncementModalOpen} onOpenChange={setIsEditAnnouncementModalOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Announcement</DialogTitle>
            <DialogDescription>Update the announcement details</DialogDescription>
          </DialogHeader>
          {editingAnnouncement && (
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-title">Title</Label>
                <Input
                  id="edit-title"
                  value={editingAnnouncement.title}
                  onChange={(e) => setEditingAnnouncement({ ...editingAnnouncement, title: e.target.value })}
                  placeholder="Announcement title"
                />
              </div>
              <div>
                <Label htmlFor="edit-content">Content</Label>
                <Textarea
                  id="edit-content"
                  value={editingAnnouncement.content}
                  onChange={(e) => setEditingAnnouncement({ ...editingAnnouncement, content: e.target.value })}
                  placeholder="Announcement content"
                  rows={6}
                />
              </div>
              <div>
                <Label htmlFor="edit-type">Type</Label>
                <Select
                  value={editingAnnouncement.type}
                  onValueChange={(value) => setEditingAnnouncement({ ...editingAnnouncement, type: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="info">Info</SelectItem>
                    <SelectItem value="warning">Warning</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {/* Current file display */}
              {editingAnnouncement.fileUrl && (
                <div className="p-3 bg-gray-50 rounded-lg">
                  <Label className="text-sm font-medium">Current File</Label>
                  <div className="flex items-center justify-between mt-1">
                    <span className="text-sm text-gray-600">
                      📎 {editingAnnouncement.fileName || "Attached file"}
                    </span>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => window.open(editingAnnouncement.fileUrl, '_blank')}
                      >
                        Download
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => {
                          if (confirm('Are you sure you want to remove this file attachment?')) {
                            setEditingAnnouncement({
                              ...editingAnnouncement,
                              fileUrl: null,
                              fileName: null
                            });
                          }
                        }}
                      >
                        Remove
                      </Button>
                    </div>
                  </div>
                </div>
              )}
              
              {/* File Upload */}
              <div>
                <Label htmlFor="edit-file">
                  {editingAnnouncement.fileUrl ? "Replace File" : "Attach File"} (PDF, Excel, Images, Videos, Audio, PowerPoint, etc.)
                </Label>
                <div className="flex items-center gap-2 mt-1">
                  <Input
                    id="edit-file"
                    type="file"
                    accept=".pdf,.xlsx,.xls,.doc,.docx,.jpg,.jpeg,.png,.gif,.webp,.txt,.csv,.zip,.rar,.mp4,.avi,.mov,.wmv,.flv,.webm,.mkv,.m4v,.3gp,.mp3,.wav,.ogg,.pptx,.ppt"
                    onChange={(e) => {
                      const file = e.target.files?.[0] || null;
                      setAnnouncementFile(file);
                    }}
                    className="flex-1"
                  />
                  {announcementFile && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => setAnnouncementFile(null)}
                    >
                      Clear
                    </Button>
                  )}
                </div>
                {announcementFile && (
                  <p className="text-sm text-gray-600 mt-1">
                    New file: {announcementFile.name} ({(announcementFile.size / 1024 / 1024).toFixed(1)} MB)
                  </p>
                )}
              </div>
              
              <div className="flex justify-end gap-2 pt-4">
                <Button 
                  variant="outline" 
                  onClick={() => {
                    setIsEditAnnouncementModalOpen(false);
                    setEditingAnnouncement(null);
                    setAnnouncementFile(null);
                  }}
                >
                  Cancel
                </Button>
                <Button 
                  onClick={() => updateAnnouncementMutation.mutate({ 
                    id: editingAnnouncement.id, 
                    announcement: editingAnnouncement 
                  })}
                  disabled={updateAnnouncementMutation.isPending}
                >
                  {updateAnnouncementMutation.isPending ? "Updating..." : "Update Announcement"}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}