import { useState } from "react";
import { Link } from "wouter";
import { MapPin, Settings, Bus, ArrowRightLeft, AlertTriangle, Route, UserRound, HelpingHand } from "lucide-react";

export default function HomeSimple() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const categories = [
    {
      id: "hotel-change",
      title: "Hotel Change",
      icon: ArrowRightLeft,
      color: "bg-blue-100 text-blue-600"
    },
    {
      id: "hotel-complain", 
      title: "Hotel Complain",
      icon: AlertTriangle,
      color: "bg-orange-100 text-orange-600"
    },
    {
      id: "booking-tours",
      title: "Booking Tours", 
      icon: Route,
      color: "bg-green-100 text-green-600"
    },
    {
      id: "medical-assistance",
      title: "Need a Doctor",
      icon: UserRound,
      color: "bg-red-100 text-red-600"
    },
    {
      id: "guide-assistance",
      title: "Need Guide Assistant",
      icon: HelpingHand,
      color: "bg-purple-100 text-purple-600"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <MapPin className="text-white" size={20} />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">TourGuide Chat</h1>
                <p className="text-sm text-gray-600">24/7 Travel Assistance</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <Link href="/guide-dashboard">
                <button className="flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                  <Bus className="mr-2" size={16} />
                  Guide
                </button>
              </Link>
              <Link href="/admin">
                <button className="flex items-center px-4 py-2 border border-transparent rounded-md text-sm font-medium text-white bg-blue-600 hover:bg-blue-700">
                  <Settings className="mr-2" size={16} />
                  Admin
                </button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Categories */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-sm border p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">How can we help you?</h2>
              <div className="space-y-3">
                {categories.map((category) => {
                  const IconComponent = category.icon;
                  return (
                    <button
                      key={category.id}
                      onClick={() => setSelectedCategory(category.id)}
                      className={`w-full p-4 rounded-lg border text-left transition-all hover:shadow-md ${
                        selectedCategory === category.id 
                          ? 'border-blue-500 bg-blue-50' 
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${category.color}`}>
                          <IconComponent size={20} />
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-900">{category.title}</h3>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Chat Area */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-sm border h-96 flex items-center justify-center">
              {selectedCategory ? (
                <div className="text-center">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">
                    Category Selected: {categories.find(c => c.id === selectedCategory)?.title}
                  </h3>
                  <p className="text-gray-600">
                    Please select your hotel to connect with the right guide
                  </p>
                  <button 
                    onClick={() => alert('Hotel selection feature coming next!')}
                    className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                  >
                    Continue to Hotel Selection
                  </button>
                </div>
              ) : (
                <div className="text-center">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Select a Category</h3>
                  <p className="text-gray-600">
                    Choose a category to start your conversation with our expert guides
                  </p>
                </div>
              )}
            </div>
          </div>

        </div>
      </div>

      {/* Mobile Floating Button */}
      <div className="fixed bottom-6 right-6 sm:hidden">
        <Link href="/guide-dashboard">
          <button className="bg-blue-600 hover:bg-blue-700 text-white rounded-full p-4 shadow-lg">
            <Bus size={20} />
          </button>
        </Link>
      </div>
    </div>
  );
}