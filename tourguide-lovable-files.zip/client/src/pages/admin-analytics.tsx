import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "wouter";
import { 
  ArrowLeft, 
  BarChart3, 
  Users, 
  MessageSquare, 
  Clock, 
  TrendingUp,
  Activity,
  Hotel,
  Target,
  Star,
  Phone,
  Calendar,
  Download
} from "lucide-react";

interface AnalyticsData {
  overview: {
    totalGuides: number;
    totalHotels: number;
    totalSessions: number;
    activeSessions: number;
    sessionsLast30Days: number;
    avgResponseTimeMinutes: number;
    totalMessages: number;
  };
  categoryBreakdown: Record<string, number>;
  dailyActivity: Array<{
    date: string;
    sessions: number;
    messages: number;
  }>;
  topPerformingGuides: Array<{
    id: number;
    name: string;
    totalHelped: number;
    rating: number;
    avgResponseTime: number;
  }>;
}

interface GuidePerformanceData {
  guideId: number;
  guideName: string;
  totalSessions: number;
  completedSessions: number;
  totalMessages: number;
  completionRate: number;
  avgResponseTime: number;
  categories: Record<string, number>;
}

interface ChatVolumeData {
  totalSessions: number;
  totalMessages: number;
  hourlyDistribution: Array<{ hour: number; count: number }>;
  dailyTrend: Array<{ date: string; sessions: number }>;
  peakHour: number;
}

interface ResponseTimeData {
  averageResponseTime: number;
  medianResponseTime: number;
  totalResponses: number;
  hourlyAverages: Array<{
    hour: number;
    avgResponseTime: number;
    responseCount: number;
  }>;
  responseTimeDistribution: {
    under1Min: number;
    under5Min: number;
    under15Min: number;
    over15Min: number;
  };
}

interface HotelActivityData {
  hotelId: number;
  hotelName: string;
  totalSessions: number;
  assignedGuides: number;
  categories: Record<string, number>;
}

export default function AdminAnalytics() {
  const [dateRange, setDateRange] = useState<{start: string; end: string} | null>(null);

  // Analytics queries
  const { data: dashboardData, isLoading: dashboardLoading } = useQuery<AnalyticsData>({
    queryKey: ['/api/analytics/dashboard'],
    onError: (error) => console.error('Dashboard analytics error:', error)
  });

  const { data: guidePerformance, isLoading: guideLoading } = useQuery<GuidePerformanceData[]>({
    queryKey: ['/api/analytics/guide-performance', dateRange],
    onError: (error) => console.error('Guide performance error:', error)
  });

  const { data: chatVolume, isLoading: volumeLoading } = useQuery<ChatVolumeData>({
    queryKey: ['/api/analytics/chat-volume', dateRange],
    onError: (error) => console.error('Chat volume error:', error)
  });

  const { data: responseTime, isLoading: responseLoading } = useQuery<ResponseTimeData>({
    queryKey: ['/api/analytics/response-time', dateRange],
    onError: (error) => console.error('Response time error:', error)
  });

  const { data: hotelActivity, isLoading: hotelLoading } = useQuery<HotelActivityData[]>({
    queryKey: ['/api/analytics/hotel-activity', dateRange],
    onError: (error) => console.error('Hotel activity error:', error)
  });

  // Utility functions for formatting
  const formatCategory = (category: string) => {
    return category.split('-').map(word => 
      word.charAt(0).toUpperCase() + word.slice(1)
    ).join(' ');
  };

  const formatTimeHour = (hour: number) => {
    return `${hour.toString().padStart(2, '0')}:00`;
  };

  const exportData = () => {
    const exportData = {
      dashboard: dashboardData,
      guides: guidePerformance,
      volume: chatVolume,
      responseTime: responseTime,
      hotels: hotelActivity,
      exportedAt: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `tourguide-analytics-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (dashboardLoading) {
    return (
      <div className="bg-gray-50 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <BarChart3 className="h-12 w-12 text-travel-blue mx-auto mb-4 animate-pulse" />
          <p className="text-gray-600">Loading analytics...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href="/admin">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="mr-2" size={16} />
                  Back to Admin
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Analytics Dashboard</h1>
                <p className="text-sm text-gray-600">Comprehensive performance insights and reports</p>
              </div>
            </div>
            <Button onClick={exportData} variant="outline" size="sm">
              <Download className="mr-2" size={16} />
              Export Data
            </Button>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="guides">Guide Performance</TabsTrigger>
            <TabsTrigger value="volume">Chat Volume</TabsTrigger>
            <TabsTrigger value="response">Response Times</TabsTrigger>
            <TabsTrigger value="hotels">Hotel Activity</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Key Metrics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Users className="h-8 w-8 text-travel-blue" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Active Guides</p>
                      <p className="text-2xl font-bold text-gray-900">{dashboardData?.overview.totalGuides || 0}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <MessageSquare className="h-8 w-8 text-success-green" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Total Sessions</p>
                      <p className="text-2xl font-bold text-gray-900">{dashboardData?.overview.totalSessions || 0}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Clock className="h-8 w-8 text-warm-orange" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Avg Response Time</p>
                      <p className="text-2xl font-bold text-gray-900">{dashboardData?.overview.avgResponseTimeMinutes || 0}m</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center">
                    <Activity className="h-8 w-8 text-purple-500" />
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-600">Active Sessions</p>
                      <p className="text-2xl font-bold text-gray-900">{dashboardData?.overview.activeSessions || 0}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Category Breakdown */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Target className="mr-2" size={20} />
                    Request Categories (Last 30 Days)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {dashboardData?.categoryBreakdown && Object.entries(dashboardData.categoryBreakdown).map(([category, count]) => (
                      <div key={category} className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">{formatCategory(category)}</span>
                        <div className="flex items-center space-x-2">
                          <Badge variant="secondary">{count}</Badge>
                          <div className="w-20 h-2 bg-gray-200 rounded">
                            <div 
                              className="h-2 bg-travel-blue rounded" 
                              style={{
                                width: `${(count / Math.max(...Object.values(dashboardData.categoryBreakdown))) * 100}%`
                              }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Top Performing Guides */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Star className="mr-2" size={20} />
                    Top Performing Guides
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {dashboardData?.topPerformingGuides?.map((guide, index) => (
                      <div key={guide.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-travel-blue text-white rounded-full flex items-center justify-center text-sm font-medium">
                            {index + 1}
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">{guide.name}</p>
                            <p className="text-xs text-gray-500">{guide.totalHelped} guests helped</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium text-gray-900">★ {guide.rating}/5</p>
                          <p className="text-xs text-gray-500">{guide.avgResponseTime}m avg</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Daily Activity Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="mr-2" size={20} />
                  Daily Activity (Last 7 Days)
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {dashboardData?.dailyActivity?.map((day) => (
                    <div key={day.date} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900">{new Date(day.date).toLocaleDateString()}</p>
                        <p className="text-sm text-gray-500">{new Date(day.date).toLocaleDateString('en-US', { weekday: 'long' })}</p>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="text-center">
                          <p className="text-sm font-medium text-gray-900">{day.sessions}</p>
                          <p className="text-xs text-gray-500">sessions</p>
                        </div>
                        <div className="text-center">
                          <p className="text-sm font-medium text-gray-900">{day.messages}</p>
                          <p className="text-xs text-gray-500">messages</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Guide Performance Tab */}
          <TabsContent value="guides" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="mr-2" size={20} />
                  Guide Performance Metrics
                </CardTitle>
              </CardHeader>
              <CardContent>
                {guideLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-pulse">Loading guide performance...</div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {guidePerformance?.map((guide) => (
                      <div key={guide.guideId} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="font-medium text-gray-900">{guide.guideName}</h3>
                          <Badge variant={guide.completionRate > 80 ? "default" : "secondary"}>
                            {guide.completionRate}% completion
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                          <div>
                            <p className="text-gray-500">Total Sessions</p>
                            <p className="font-medium">{guide.totalSessions}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Messages Sent</p>
                            <p className="font-medium">{guide.totalMessages}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Avg Response</p>
                            <p className="font-medium">{guide.avgResponseTime}m</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Top Category</p>
                            <p className="font-medium">
                              {Object.entries(guide.categories).length > 0 
                                ? formatCategory(Object.entries(guide.categories).sort((a, b) => b[1] - a[1])[0][0])
                                : 'N/A'
                              }
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Chat Volume Tab */}
          <TabsContent value="volume" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <MessageSquare className="h-8 w-8 text-travel-blue mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{chatVolume?.totalSessions || 0}</p>
                    <p className="text-sm text-gray-600">Total Sessions</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <Activity className="h-8 w-8 text-success-green mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{chatVolume?.totalMessages || 0}</p>
                    <p className="text-sm text-gray-600">Total Messages</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <Clock className="h-8 w-8 text-warm-orange mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{formatTimeHour(chatVolume?.peakHour || 0)}</p>
                    <p className="text-sm text-gray-600">Peak Hour</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Hourly Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Hourly Session Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {chatVolume?.hourlyDistribution?.map((item) => (
                    <div key={item.hour} className="flex items-center space-x-3">
                      <span className="w-12 text-sm text-gray-600">{formatTimeHour(item.hour)}</span>
                      <div className="flex-1 h-4 bg-gray-200 rounded">
                        <div 
                          className="h-4 bg-travel-blue rounded" 
                          style={{
                            width: `${(item.count / Math.max(...(chatVolume.hourlyDistribution?.map(h => h.count) || [1]))) * 100}%`
                          }}
                        ></div>
                      </div>
                      <span className="w-8 text-sm text-gray-600">{item.count}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Response Times Tab */}
          <TabsContent value="response" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <Clock className="h-8 w-8 text-travel-blue mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{responseTime?.averageResponseTime || 0}m</p>
                    <p className="text-sm text-gray-600">Average</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <Target className="h-8 w-8 text-success-green mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{responseTime?.medianResponseTime || 0}m</p>
                    <p className="text-sm text-gray-600">Median</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <Activity className="h-8 w-8 text-warm-orange mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{responseTime?.totalResponses || 0}</p>
                    <p className="text-sm text-gray-600">Total Responses</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <TrendingUp className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">
                      {responseTime?.responseTimeDistribution?.under5Min || 0}
                    </p>
                    <p className="text-sm text-gray-600">Under 5min</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Response Time Distribution */}
            <Card>
              <CardHeader>
                <CardTitle>Response Time Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {responseTime?.responseTimeDistribution && Object.entries(responseTime.responseTimeDistribution).map(([range, count]) => (
                    <div key={range} className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">
                        {range.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                      </span>
                      <div className="flex items-center space-x-2">
                        <Badge variant="secondary">{count}</Badge>
                        <div className="w-20 h-2 bg-gray-200 rounded">
                          <div 
                            className="h-2 bg-travel-blue rounded" 
                            style={{
                              width: `${(count / Math.max(...Object.values(responseTime.responseTimeDistribution))) * 100}%`
                            }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Hotel Activity Tab */}
          <TabsContent value="hotels" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Hotel className="mr-2" size={20} />
                  Hotel Activity Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                {hotelLoading ? (
                  <div className="text-center py-8">
                    <div className="animate-pulse">Loading hotel activity...</div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {hotelActivity?.map((hotel) => (
                      <div key={hotel.hotelId} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="font-medium text-gray-900">{hotel.hotelName}</h3>
                          <Badge variant="outline">{hotel.totalSessions} sessions</Badge>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <p className="text-gray-500">Assigned Guides</p>
                            <p className="font-medium">{hotel.assignedGuides}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Total Sessions</p>
                            <p className="font-medium">{hotel.totalSessions}</p>
                          </div>
                          <div>
                            <p className="text-gray-500">Top Category</p>
                            <p className="font-medium">
                              {Object.entries(hotel.categories).length > 0 
                                ? formatCategory(Object.entries(hotel.categories).sort((a, b) => b[1] - a[1])[0][0])
                                : 'N/A'
                              }
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}