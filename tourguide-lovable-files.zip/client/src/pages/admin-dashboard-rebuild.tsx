import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Users, Building2, Calendar, Megaphone, AlertTriangle, BarChart3, Plus } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

export default function AdminDashboardRebuild() {
  const [activeTab, setActiveTab] = useState("guides");

  // Simple data fetching - testing each endpoint individually
  const { data: guides = [], isLoading: guidesLoading } = useQuery({
    queryKey: ["/api/guides"]
  });

  const { data: hotels = [], isLoading: hotelsLoading } = useQuery({
    queryKey: ["/api/hotels"]
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="mr-2" size={16} />
                Back to Chat
              </Button>
            </Link>

            <div className="flex items-center gap-4">
              <div>
                <h1 className="text-xl font-bold text-gray-900">Admin Dashboard</h1>
                <p className="text-sm text-gray-600">Manage tourism guide system</p>
              </div>
              
              <Link href="/admin-analytics">
                <Button variant="outline" size="sm">
                  <BarChart3 className="mr-2" size={16} />
                  Analytics
                </Button>
              </Link>
            </div>
          </div>

          {/* Basic Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="guides">
                <Users size={16} className="mr-2" />
                Guides
              </TabsTrigger>
              <TabsTrigger value="hotels">
                <Building2 size={16} className="mr-2" />
                Hotels
              </TabsTrigger>
              <TabsTrigger value="assignments">
                <Calendar size={16} className="mr-2" />
                Assignments
              </TabsTrigger>
              <TabsTrigger value="announcements">
                <Megaphone size={16} className="mr-2" />
                Announcements
              </TabsTrigger>
              <TabsTrigger value="emergency">
                <AlertTriangle size={16} className="mr-2" />
                Emergency
              </TabsTrigger>
            </TabsList>

            {/* Guides Tab */}
            <TabsContent value="guides" className="space-y-4">
              <h2 className="text-lg font-semibold">Guide Management</h2>
              
              {guidesLoading ? (
                <p>Loading guides...</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {guides.map((guide: any) => (
                    <Card key={guide.id}>
                      <CardHeader>
                        <CardTitle className="flex items-center justify-between">
                          <span>{guide.name}</span>
                          <Badge variant={guide.isActive ? "default" : "secondary"}>
                            {guide.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600">{guide.email}</p>
                        {guide.phone && <p className="text-sm text-gray-600">{guide.phone}</p>}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* Hotels Tab */}
            <TabsContent value="hotels" className="space-y-4">
              <h2 className="text-lg font-semibold">Hotel Management</h2>
              
              {hotelsLoading ? (
                <p>Loading hotels...</p>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {hotels.map((hotel: any) => (
                    <Card key={hotel.id}>
                      <CardHeader>
                        <CardTitle>{hotel.name}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600">{hotel.address}</p>
                        {hotel.phone && <p className="text-sm text-gray-600">{hotel.phone}</p>}
                        {hotel.email && <p className="text-sm text-gray-600">{hotel.email}</p>}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </TabsContent>

            {/* Placeholder tabs */}
            <TabsContent value="assignments" className="space-y-4">
              <h2 className="text-lg font-semibold">Guide Assignments</h2>
              <p>Assignment management coming soon...</p>
            </TabsContent>

            <TabsContent value="announcements" className="space-y-4">
              <h2 className="text-lg font-semibold">Announcements</h2>
              <p>Announcement management coming soon...</p>
            </TabsContent>

            <TabsContent value="emergency" className="space-y-4">
              <h2 className="text-lg font-semibold">Emergency Contacts</h2>
              <p>Emergency contact management coming soon...</p>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}