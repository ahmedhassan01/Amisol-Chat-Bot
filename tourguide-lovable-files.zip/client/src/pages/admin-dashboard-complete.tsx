import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, BarChart3, Plus, Users, Building2, Calendar, Megaphone, AlertTriangle, Edit, Trash2 } from "lucide-react";

export default function AdminDashboardComplete() {
  const [activeTab, setActiveTab] = useState("guides");

  // Data fetching
  const { data: guides = [] } = useQuery<any[]>({
    queryKey: ["/api/guides"]
  });

  const { data: hotels = [] } = useQuery<any[]>({
    queryKey: ["/api/hotels"]
  });

  const { data: assignments = [] } = useQuery<any[]>({
    queryKey: ["/api/guide-assignments"]
  });

  const { data: announcements = [] } = useQuery<any[]>({
    queryKey: ["/api/announcements"]
  });

  const { data: emergencyContacts = [] } = useQuery<any[]>({
    queryKey: ["/api/emergency-contacts"]
  });

  return React.createElement("div", {
    className: "min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4"
  },
    React.createElement("div", {
      className: "max-w-7xl mx-auto"
    },
      React.createElement("div", {
        className: "bg-white rounded-lg shadow-lg p-6"
      },
        // Header
        React.createElement("div", {
          className: "flex items-center justify-between mb-6"
        },
          React.createElement(Link, { href: "/" },
            React.createElement("button", {
              className: "flex items-center gap-2 px-3 py-2 text-gray-600 hover:text-gray-900 rounded-md"
            },
              React.createElement(ArrowLeft, { size: 16 }),
              "Back to Chat"
            )
          ),
          React.createElement("div", {
            className: "flex items-center gap-4"
          },
            React.createElement("div", {},
              React.createElement("h1", {
                className: "text-xl font-bold text-gray-900"
              }, "Admin Dashboard"),
              React.createElement("p", {
                className: "text-sm text-gray-600"
              }, "Tourism Guide Management")
            ),
            React.createElement(Link, { href: "/admin-analytics" },
              React.createElement("button", {
                className: "flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-md hover:bg-gray-50"
              },
                React.createElement(BarChart3, { size: 16 }),
                "Analytics"
              )
            )
          )
        ),

        // Navigation Tabs
        React.createElement("div", {
          className: "border-b border-gray-200 mb-6"
        },
          React.createElement("nav", {
            className: "flex space-x-8"
          },
            [
              { id: 'guides', label: 'Guides', icon: Users },
              { id: 'hotels', label: 'Hotels', icon: Building2 },
              { id: 'assignments', label: 'Assignments', icon: Calendar },
              { id: 'announcements', label: 'Announcements', icon: Megaphone },
              { id: 'emergency', label: 'Emergency', icon: AlertTriangle }
            ].map(({ id, label, icon: Icon }) =>
              React.createElement("button", {
                key: id,
                onClick: () => setActiveTab(id),
                className: `flex items-center gap-2 py-2 px-1 border-b-2 font-medium text-sm ${
                  activeTab === id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`
              },
                React.createElement(Icon, { size: 16 }),
                label
              )
            )
          )
        ),

        // Tab Content - Guides
        activeTab === 'guides' && React.createElement("div", {
          className: "space-y-4"
        },
          React.createElement("div", {
            className: "flex justify-between items-center"
          },
            React.createElement("h2", {
              className: "text-lg font-semibold"
            }, "Guide Management"),
            React.createElement("button", {
              className: "flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            },
              React.createElement(Plus, { size: 16 }),
              "Add Guide"
            )
          ),
          React.createElement("div", {
            className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
          },
            guides.map((guide: any) =>
              React.createElement("div", {
                key: guide.id,
                className: "bg-gray-50 p-4 rounded-lg border"
              },
                React.createElement("div", {
                  className: "flex items-center justify-between mb-2"
                },
                  React.createElement("h3", {
                    className: "font-semibold"
                  }, guide.name),
                  React.createElement("div", {
                    className: "flex items-center gap-2"
                  },
                    React.createElement("span", {
                      className: `px-2 py-1 text-xs rounded-full ${
                        guide.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`
                    }, guide.isActive ? 'Active' : 'Inactive'),
                    React.createElement("button", {
                      className: "p-1 hover:bg-gray-200 rounded"
                    },
                      React.createElement(Edit, { size: 14 })
                    )
                  )
                ),
                React.createElement("p", {
                  className: "text-sm text-gray-600"
                }, guide.email),
                guide.phone && React.createElement("p", {
                  className: "text-sm text-gray-600"
                }, guide.phone),
                guide.specialties && React.createElement("p", {
                  className: "text-xs text-gray-500 mt-2"
                }, `Specialties: ${guide.specialties}`)
              )
            )
          )
        ),

        // Tab Content - Hotels
        activeTab === 'hotels' && React.createElement("div", {
          className: "space-y-4"
        },
          React.createElement("div", {
            className: "flex justify-between items-center"
          },
            React.createElement("h2", {
              className: "text-lg font-semibold"
            }, "Hotel Management"),
            React.createElement("button", {
              className: "flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            },
              React.createElement(Plus, { size: 16 }),
              "Add Hotel"
            )
          ),
          React.createElement("div", {
            className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
          },
            hotels.map((hotel: any) =>
              React.createElement("div", {
                key: hotel.id,
                className: "bg-gray-50 p-4 rounded-lg border"
              },
                React.createElement("div", {
                  className: "flex items-center justify-between mb-2"
                },
                  React.createElement("h3", {
                    className: "font-semibold"
                  }, hotel.name),
                  React.createElement("button", {
                    className: "p-1 hover:bg-gray-200 rounded"
                  },
                    React.createElement(Edit, { size: 14 })
                  )
                ),
                React.createElement("p", {
                  className: "text-sm text-gray-600"
                }, hotel.address),
                hotel.phone && React.createElement("p", {
                  className: "text-sm text-gray-600"
                }, hotel.phone),
                hotel.email && React.createElement("p", {
                  className: "text-sm text-gray-600"
                }, hotel.email)
              )
            )
          )
        ),

        // Tab Content - Assignments
        activeTab === 'assignments' && React.createElement("div", {
          className: "space-y-4"
        },
          React.createElement("div", {
            className: "flex justify-between items-center"
          },
            React.createElement("h2", {
              className: "text-lg font-semibold"
            }, "Guide Assignments"),
            React.createElement("button", {
              className: "flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            },
              React.createElement(Plus, { size: 16 }),
              "New Assignment"
            )
          ),
          React.createElement("div", {
            className: "space-y-4"
          },
            assignments.map((assignment: any) =>
              React.createElement("div", {
                key: assignment.id,
                className: "bg-gray-50 p-4 rounded-lg border"
              },
                React.createElement("div", {
                  className: "flex items-center justify-between mb-2"
                },
                  React.createElement("h3", {
                    className: "font-semibold"
                  }, `${assignment.guide?.name || 'Unknown Guide'} → ${assignment.hotel?.name || 'Unknown Hotel'}`),
                  React.createElement("div", {
                    className: "flex items-center gap-2"
                  },
                    React.createElement("span", {
                      className: `px-2 py-1 text-xs rounded-full ${
                        assignment.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`
                    }, assignment.isActive ? 'Active' : 'Inactive'),
                    React.createElement("button", {
                      className: "p-1 hover:bg-gray-200 rounded"
                    },
                      React.createElement(Edit, { size: 14 })
                    )
                  )
                ),
                React.createElement("p", {
                  className: "text-sm text-gray-600"
                }, "Schedule details available")
              )
            )
          )
        ),

        // Tab Content - Announcements
        activeTab === 'announcements' && React.createElement("div", {
          className: "space-y-4"
        },
          React.createElement("div", {
            className: "flex justify-between items-center"
          },
            React.createElement("h2", {
              className: "text-lg font-semibold"
            }, "Announcements"),
            React.createElement("button", {
              className: "flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            },
              React.createElement(Plus, { size: 16 }),
              "New Announcement"
            )
          ),
          React.createElement("div", {
            className: "space-y-4"
          },
            announcements.map((announcement: any) =>
              React.createElement("div", {
                key: announcement.id,
                className: "bg-gray-50 p-4 rounded-lg border"
              },
                React.createElement("div", {
                  className: "flex items-center justify-between mb-2"
                },
                  React.createElement("h3", {
                    className: "font-semibold"
                  }, announcement.title),
                  React.createElement("div", {
                    className: "flex items-center gap-2"
                  },
                    React.createElement("span", {
                      className: `px-2 py-1 text-xs rounded-full ${
                        announcement.urgency === 'urgent' ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'
                      }`
                    }, announcement.urgency),
                    React.createElement("button", {
                      className: "p-1 hover:bg-gray-200 rounded"
                    },
                      React.createElement(Edit, { size: 14 })
                    )
                  )
                ),
                React.createElement("p", {
                  className: "text-sm text-gray-600"
                }, announcement.content),
                React.createElement("p", {
                  className: "text-xs text-gray-500 mt-2"
                }, new Date(announcement.createdAt).toLocaleDateString())
              )
            )
          )
        ),

        // Tab Content - Emergency
        activeTab === 'emergency' && React.createElement("div", {
          className: "space-y-4"
        },
          React.createElement("div", {
            className: "flex justify-between items-center"
          },
            React.createElement("h2", {
              className: "text-lg font-semibold"
            }, "Emergency Contacts"),
            React.createElement("button", {
              className: "flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
            },
              React.createElement(Plus, { size: 16 }),
              "Add Contact"
            )
          ),
          React.createElement("div", {
            className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"
          },
            emergencyContacts.map((contact: any) =>
              React.createElement("div", {
                key: contact.id,
                className: "bg-gray-50 p-4 rounded-lg border"
              },
                React.createElement("div", {
                  className: "flex items-center justify-between mb-2"
                },
                  React.createElement("h3", {
                    className: "font-semibold"
                  }, contact.name),
                  React.createElement("div", {
                    className: "flex items-center gap-2"
                  },
                    React.createElement("span", {
                      className: `px-2 py-1 text-xs rounded-full ${
                        contact.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`
                    }, contact.isActive ? 'Active' : 'Inactive'),
                    React.createElement("button", {
                      className: "p-1 hover:bg-gray-200 rounded"
                    },
                      React.createElement(Edit, { size: 14 })
                    )
                  )
                ),
                React.createElement("p", {
                  className: "text-sm text-gray-600"
                }, contact.phone),
                React.createElement("p", {
                  className: "text-sm text-gray-600"
                }, contact.description)
              )
            )
          )
        )
      )
    )
  );
}