import { useState } from "react";
import { Link } from "wouter";
import { MapPin, Settings, Bus } from "lucide-react";
import CategorySidebar from "@/components/category-sidebar";
import ChatInterface from "@/components/chat-interface";
import GuideInfoPanel from "@/components/guide-info-panel";
import HotelSelection from "@/components/hotel-selection";

export default function HomeBasic() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [chatSession, setChatSession] = useState<any>(null);
  const [selectedHotel, setSelectedHotel] = useState<any>(null);
  const [showHotelSelection, setShowHotelSelection] = useState(false);

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    setShowHotelSelection(true);
    setChatSession(null);
    setSelectedHotel(null);
  };

  const handleHotelSelect = (hotel: any, session: any) => {
    setSelectedHotel(hotel);
    setChatSession(session);
    setShowHotelSelection(false);
  };

  const handleBackToCategories = () => {
    setShowHotelSelection(false);
    setSelectedCategory(null);
    setChatSession(null);
    setSelectedHotel(null);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Simple Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <MapPin className="text-white" size={20} />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">TourGuide Chat</h1>
                <p className="text-sm text-gray-500">24/7 Travel Assistance</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Link href="/guide-dashboard">
                <button className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50">
                  <Bus className="mr-2" size={16} />
                  Guide
                </button>
              </Link>
              <Link href="/admin">
                <button className="inline-flex items-center px-3 py-2 border border-transparent rounded-md text-sm font-medium text-white bg-blue-600 hover:bg-blue-700">
                  <Settings className="mr-2" size={16} />
                  Admin
                </button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Simple Content Grid */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 h-[calc(100vh-120px)]">
          {/* Category/Hotel Selection */}
          <div className="lg:col-span-1">
            {!showHotelSelection ? (
              <CategorySidebar
                selectedCategory={selectedCategory}
                onSelectCategory={handleCategorySelect}
              />
            ) : selectedCategory ? (
              <HotelSelection
                selectedCategory={selectedCategory}
                onHotelSelected={handleHotelSelect}
                onBack={handleBackToCategories}
              />
            ) : null}
          </div>
          
          {/* Chat Interface */}
          <div className="lg:col-span-2">
            {chatSession && selectedHotel ? (
              <ChatInterface
                selectedCategory={selectedCategory}
                chatSession={chatSession}
                selectedHotel={selectedHotel}
              />
            ) : (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 h-full flex items-center justify-center">
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <MapPin className="text-blue-600" size={24} />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Welcome to TourGuide Chat</h3>
                  <p className="text-gray-600 max-w-sm">
                    Select a category to start chatting with our travel experts who are here to help 24/7.
                  </p>
                </div>
              </div>
            )}
          </div>
          
          {/* Guide Info Panel */}
          <div className="lg:col-span-1">
            <GuideInfoPanel />
          </div>
        </div>
      </div>
    </div>
  );
}