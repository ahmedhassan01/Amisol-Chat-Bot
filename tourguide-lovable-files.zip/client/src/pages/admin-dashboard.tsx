import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, BarChart3, Plus, Users, Building2, Calendar, Megaphone, AlertTriangle } from "lucide-react";

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("guides");

  // Basic data fetching
  const { data: guides = [] } = useQuery<any[]>({
    queryKey: ["/api/guides"]
  });

  const { data: hotels = [] } = useQuery<any[]>({
    queryKey: ["/api/hotels"]
  });

  const { data: assignments = [] } = useQuery<any[]>({
    queryKey: ["/api/guide-assignments"]
  });

  const { data: announcements = [] } = useQuery<any[]>({
    queryKey: ["/api/announcements"]
  });

  const { data: emergencyContacts = [] } = useQuery<any[]>({
    queryKey: ["/api/emergency-contacts"]
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <Link href="/">
              <button className="flex items-center gap-2 px-3 py-2 text-gray-600 hover:text-gray-900 rounded-md">
                <ArrowLeft size={16} />
                Back to Chat
              </button>
            </Link>

            <div className="flex items-center gap-4">
              <div>
                <h1 className="text-xl font-bold text-gray-900">Admin Dashboard</h1>
                <p className="text-sm text-gray-600">Tourism Guide Management</p>
              </div>
              
              <Link href="/admin-analytics">
                <button className="flex items-center gap-2 px-3 py-2 border border-gray-300 rounded-md hover:bg-gray-50">
                  <BarChart3 size={16} />
                  Analytics
                </button>
              </Link>
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="border-b border-gray-200 mb-6">
            <nav className="flex space-x-8">
              {[
                { id: 'guides', label: 'Guides', icon: Users },
                { id: 'hotels', label: 'Hotels', icon: Building2 },
                { id: 'assignments', label: 'Assignments', icon: Calendar },
                { id: 'announcements', label: 'Announcements', icon: Megaphone },
                { id: 'emergency', label: 'Emergency', icon: AlertTriangle }
              ].map(({ id, label, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setActiveTab(id)}
                  className={`flex items-center gap-2 py-2 px-1 border-b-2 font-medium text-sm ${
                    activeTab === id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Icon size={16} />
                  {label}
                </button>
              ))}
            </nav>
          </div>

          {/* Tab Content */}
          {activeTab === 'guides' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold">Guide Management</h2>
                <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                  <Plus size={16} />
                  Add Guide
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {(guides as any[]).map((guide: any) => (
                  <div key={guide.id} className="bg-gray-50 p-4 rounded-lg border">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">{guide.name}</h3>
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        guide.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {guide.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">{guide.email}</p>
                    {guide.phone && <p className="text-sm text-gray-600">{guide.phone}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'hotels' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold">Hotel Management</h2>
                <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                  <Plus size={16} />
                  Add Hotel
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {(hotels as any[]).map((hotel: any) => (
                  <div key={hotel.id} className="bg-gray-50 p-4 rounded-lg border">
                    <h3 className="font-semibold mb-2">{hotel.name}</h3>
                    <p className="text-sm text-gray-600">{hotel.address}</p>
                    {hotel.phone && <p className="text-sm text-gray-600">{hotel.phone}</p>}
                    {hotel.email && <p className="text-sm text-gray-600">{hotel.email}</p>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'assignments' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold">Guide Assignments</h2>
                <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                  <Plus size={16} />
                  New Assignment
                </button>
              </div>
              
              <div className="space-y-4">
                {(assignments as any[]).map((assignment: any) => (
                  <div key={assignment.id} className="bg-gray-50 p-4 rounded-lg border">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">
                        {assignment.guide?.name} → {assignment.hotel?.name}
                      </h3>
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        assignment.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {assignment.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">
                      Schedule details available
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'announcements' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold">Announcements</h2>
                <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                  <Plus size={16} />
                  New Announcement
                </button>
              </div>
              
              <div className="space-y-4">
                {(announcements as any[]).map((announcement: any) => (
                  <div key={announcement.id} className="bg-gray-50 p-4 rounded-lg border">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">{announcement.title}</h3>
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        announcement.urgency === 'urgent' ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {announcement.urgency}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">{announcement.content}</p>
                    <p className="text-xs text-gray-500 mt-2">
                      {new Date(announcement.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'emergency' && (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold">Emergency Contacts</h2>
                <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
                  <Plus size={16} />
                  Add Contact
                </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {(emergencyContacts as any[]).map((contact: any) => (
                  <div key={contact.id} className="bg-gray-50 p-4 rounded-lg border">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">{contact.name}</h3>
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        contact.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {contact.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600">{contact.phone}</p>
                    <p className="text-sm text-gray-600">{contact.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}