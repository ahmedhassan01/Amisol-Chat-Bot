import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";

export default function AdminSimple() {
  const [activeTab, setActiveTab] = useState("overview");

  const { data: guides = [] } = useQuery<any[]>({
    queryKey: ["/api/guides"]
  });

  const { data: hotels = [] } = useQuery<any[]>({
    queryKey: ["/api/hotels"]
  });

  return (
    <div style={{ padding: "20px", minHeight: "100vh", backgroundColor: "#f3f4f6" }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto", backgroundColor: "white", borderRadius: "8px", padding: "24px", boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)" }}>
        
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "24px" }}>
          <Link href="/">
            <button style={{ padding: "8px 16px", border: "1px solid #ccc", borderRadius: "4px", backgroundColor: "white", cursor: "pointer" }}>
              ← Back to Chat
            </button>
          </Link>
          
          <div>
            <h1 style={{ fontSize: "24px", fontWeight: "bold", margin: "0" }}>Admin Dashboard</h1>
            <p style={{ color: "#666", margin: "0" }}>Tourism Guide Management</p>
          </div>
          
          <Link href="/admin-analytics">
            <button style={{ padding: "8px 16px", border: "1px solid #3b82f6", borderRadius: "4px", backgroundColor: "#3b82f6", color: "white", cursor: "pointer" }}>
              📊 Analytics
            </button>
          </Link>
        </div>

        {/* Tabs */}
        <div style={{ borderBottom: "1px solid #e5e7eb", marginBottom: "24px" }}>
          <div style={{ display: "flex", gap: "32px" }}>
            {[
              { id: 'overview', label: 'Overview' },
              { id: 'guides', label: 'Guides' },
              { id: 'hotels', label: 'Hotels' }
            ].map(({ id, label }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                style={{
                  padding: "8px 0",
                  border: "none",
                  backgroundColor: "transparent",
                  borderBottom: activeTab === id ? "2px solid #3b82f6" : "2px solid transparent",
                  color: activeTab === id ? "#3b82f6" : "#666",
                  fontWeight: activeTab === id ? "600" : "400",
                  cursor: "pointer"
                }}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && (
          <div>
            <h2 style={{ fontSize: "20px", fontWeight: "600", marginBottom: "16px" }}>System Overview</h2>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: "16px" }}>
              <div style={{ padding: "16px", backgroundColor: "#f9fafb", borderRadius: "8px", border: "1px solid #e5e7eb" }}>
                <h3 style={{ fontSize: "16px", fontWeight: "600", margin: "0 0 8px 0" }}>Total Guides</h3>
                <p style={{ fontSize: "24px", fontWeight: "bold", color: "#3b82f6", margin: "0" }}>{(guides as any[]).length}</p>
              </div>
              <div style={{ padding: "16px", backgroundColor: "#f9fafb", borderRadius: "8px", border: "1px solid #e5e7eb" }}>
                <h3 style={{ fontSize: "16px", fontWeight: "600", margin: "0 0 8px 0" }}>Total Hotels</h3>
                <p style={{ fontSize: "24px", fontWeight: "bold", color: "#3b82f6", margin: "0" }}>{(hotels as any[]).length}</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'guides' && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
              <h2 style={{ fontSize: "20px", fontWeight: "600", margin: "0" }}>Guide Management</h2>
              <button style={{ padding: "8px 16px", backgroundColor: "#3b82f6", color: "white", border: "none", borderRadius: "4px", cursor: "pointer" }}>
                + Add Guide
              </button>
            </div>
            
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "16px" }}>
              {(guides as any[]).map((guide: any) => (
                <div key={guide.id} style={{ padding: "16px", backgroundColor: "#f9fafb", borderRadius: "8px", border: "1px solid #e5e7eb" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
                    <h3 style={{ fontSize: "16px", fontWeight: "600", margin: "0" }}>{guide.name}</h3>
                    <span style={{
                      padding: "4px 8px",
                      fontSize: "12px",
                      borderRadius: "12px",
                      backgroundColor: guide.isActive ? "#dcfce7" : "#f3f4f6",
                      color: guide.isActive ? "#166534" : "#374151"
                    }}>
                      {guide.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  <p style={{ fontSize: "14px", color: "#666", margin: "4px 0" }}>{guide.email}</p>
                  {guide.phone && <p style={{ fontSize: "14px", color: "#666", margin: "4px 0" }}>{guide.phone}</p>}
                  {guide.specialties && <p style={{ fontSize: "12px", color: "#666", margin: "8px 0 0 0" }}>Specialties: {guide.specialties}</p>}
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'hotels' && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "16px" }}>
              <h2 style={{ fontSize: "20px", fontWeight: "600", margin: "0" }}>Hotel Management</h2>
              <button style={{ padding: "8px 16px", backgroundColor: "#3b82f6", color: "white", border: "none", borderRadius: "4px", cursor: "pointer" }}>
                + Add Hotel
              </button>
            </div>
            
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: "16px" }}>
              {(hotels as any[]).map((hotel: any) => (
                <div key={hotel.id} style={{ padding: "16px", backgroundColor: "#f9fafb", borderRadius: "8px", border: "1px solid #e5e7eb" }}>
                  <h3 style={{ fontSize: "16px", fontWeight: "600", marginBottom: "8px" }}>{hotel.name}</h3>
                  <p style={{ fontSize: "14px", color: "#666", margin: "4px 0" }}>{hotel.address}</p>
                  {hotel.phone && <p style={{ fontSize: "14px", color: "#666", margin: "4px 0" }}>{hotel.phone}</p>}
                  {hotel.email && <p style={{ fontSize: "14px", color: "#666", margin: "4px 0" }}>{hotel.email}</p>}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}