import { useState } from "react";
import { Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ArrowLeft, Plus, Users, Building2, Calendar, Megaphone, FileText, AlertTriangle, Upload, Download } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Guide, Hotel, GuideAssignment, Announcement, EmergencyContact } from "@shared/schema";

export default function AdminDashboardWorking() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("guides");

  // Fetch data
  const { data: guides = [] } = useQuery<Guide[]>({
    queryKey: ["/api/guides"]
  });

  const { data: hotels = [] } = useQuery<Hotel[]>({
    queryKey: ["/api/hotels"]
  });

  const { data: assignments = [] } = useQuery<(GuideAssignment & { guide: Guide; hotel: Hotel })[]>({
    queryKey: ["/api/guide-assignments"]
  });

  const { data: announcements = [] } = useQuery<Announcement[]>({
    queryKey: ["/api/announcements"]
  });

  const { data: emergencyContacts = [] } = useQuery<EmergencyContact[]>({
    queryKey: ["/api/emergency-contacts"]
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="mr-2" size={16} />
                Back to Chat
              </Button>
            </Link>

            <div>
              <h1 className="text-xl font-bold text-gray-900">Admin Dashboard</h1>
              <p className="text-sm text-gray-600">Manage guides, hotels, and system settings</p>
            </div>
          </div>

          {/* Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="guides" className="flex items-center gap-2">
                <Users size={16} />
                Guides
              </TabsTrigger>
              <TabsTrigger value="hotels" className="flex items-center gap-2">
                <Building2 size={16} />
                Hotels
              </TabsTrigger>
              <TabsTrigger value="assignments" className="flex items-center gap-2">
                <Calendar size={16} />
                Assignments
              </TabsTrigger>
              <TabsTrigger value="announcements" className="flex items-center gap-2">
                <Megaphone size={16} />
                Announcements
              </TabsTrigger>
              <TabsTrigger value="emergency" className="flex items-center gap-2">
                <AlertTriangle size={16} />
                Emergency
              </TabsTrigger>
            </TabsList>

            {/* Guides Tab */}
            <TabsContent value="guides" className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold">Guide Management</h2>
                <Button>
                  <Plus className="mr-2" size={16} />
                  Add Guide
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {guides.map((guide) => (
                  <Card key={guide.id}>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span>{guide.name}</span>
                        <Badge variant={guide.isActive ? "default" : "secondary"}>
                          {guide.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600">{guide.email}</p>
                      {guide.phone && <p className="text-sm text-gray-600">{guide.phone}</p>}
                      {guide.specialties && (
                        <div className="mt-2">
                          <p className="text-xs text-gray-500">Specialties:</p>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {guide.specialties.map((specialty, idx) => (
                              <Badge key={idx} variant="outline" className="text-xs">
                                {specialty}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Hotels Tab */}
            <TabsContent value="hotels" className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold">Hotel Management</h2>
                <Button>
                  <Plus className="mr-2" size={16} />
                  Add Hotel
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {hotels.map((hotel) => (
                  <Card key={hotel.id}>
                    <CardHeader>
                      <CardTitle>{hotel.name}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600">{hotel.address}</p>
                      {hotel.phone && <p className="text-sm text-gray-600">{hotel.phone}</p>}
                      {hotel.email && <p className="text-sm text-gray-600">{hotel.email}</p>}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Assignments Tab */}
            <TabsContent value="assignments" className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold">Guide Assignments</h2>
                <Button>
                  <Plus className="mr-2" size={16} />
                  New Assignment
                </Button>
              </div>
              
              <div className="space-y-4">
                {assignments.map((assignment) => (
                  <Card key={assignment.id}>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span>{assignment.guide?.name} → {assignment.hotel?.name}</span>
                        <Badge variant={assignment.isActive ? "default" : "secondary"}>
                          {assignment.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600">
                        Days: {assignment.daysOfWeek ? JSON.stringify(assignment.daysOfWeek) : 'Not specified'}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Announcements Tab */}
            <TabsContent value="announcements" className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold">Announcements</h2>
                <Button>
                  <Plus className="mr-2" size={16} />
                  New Announcement
                </Button>
              </div>
              
              <div className="space-y-4">
                {announcements.map((announcement) => (
                  <Card key={announcement.id}>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span>{announcement.title}</span>
                        <Badge variant={announcement.urgency === 'urgent' ? "destructive" : "default"}>
                          {announcement.urgency}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600">{announcement.content}</p>
                      <p className="text-xs text-gray-500 mt-2">
                        {new Date(announcement.createdAt).toLocaleDateString()}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Emergency Tab */}
            <TabsContent value="emergency" className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-lg font-semibold">Emergency Contacts</h2>
                <Button>
                  <Plus className="mr-2" size={16} />
                  Add Contact
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {emergencyContacts.map((contact) => (
                  <Card key={contact.id}>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span>{contact.name}</span>
                        <Badge variant={contact.isActive ? "default" : "secondary"}>
                          {contact.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600">{contact.phone}</p>
                      <p className="text-sm text-gray-600">{contact.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}