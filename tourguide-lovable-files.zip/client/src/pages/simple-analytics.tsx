import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Users, MessageSquare, Clock, Activity, Building2, Star, BarChart3, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";

export default function SimpleAnalytics() {
  const { data: analytics } = useQuery({
    queryKey: ["/api/analytics/dashboard"],
  });

  const { data: guidePerformance = [] } = useQuery({
    queryKey: ["/api/analytics/guide-performance"],
  });

  const { data: chatVolume } = useQuery({
    queryKey: ["/api/analytics/chat-volume"],
  });

  const { data: responseTime } = useQuery({
    queryKey: ["/api/analytics/response-time"],
  });

  const { data: hotelActivity = [] } = useQuery({
    queryKey: ["/api/analytics/hotel-activity"],
  });

  const formatTimeHour = (hour: number) => {
    if (hour === 0) return "12:00 AM";
    if (hour < 12) return `${hour}:00 AM`;
    if (hour === 12) return "12:00 PM";
    return `${hour - 12}:00 PM`;
  };

  return (
    <div className="bg-gray-50 min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <Link href="/admin">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="mr-2" size={16} />
                  Back to Dashboard
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Analytics Dashboard</h1>
                <p className="text-sm text-gray-600">Tourism guide system insights and reports</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">
              <BarChart3 className="mr-2" size={16} />
              Overview
            </TabsTrigger>
            <TabsTrigger value="guides">
              <Users className="mr-2" size={16} />
              Guide Performance
            </TabsTrigger>
            <TabsTrigger value="volume">
              <MessageSquare className="mr-2" size={16} />
              Chat Volume
            </TabsTrigger>
            <TabsTrigger value="hotels">
              <Building2 className="mr-2" size={16} />
              Hotel Activity
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <Users className="h-8 w-8 text-travel-blue mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{guidePerformance?.length || 0}</p>
                    <p className="text-sm text-gray-600">Active Guides</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <MessageSquare className="h-8 w-8 text-success-green mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{chatVolume?.totalSessions || 0}</p>
                    <p className="text-sm text-gray-600">Total Sessions</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <Activity className="h-8 w-8 text-warm-orange mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{chatVolume?.totalMessages || 0}</p>
                    <p className="text-sm text-gray-600">Total Messages</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <Clock className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{responseTime?.averageResponseTime || 0}m</p>
                    <p className="text-sm text-gray-600">Avg Response Time</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Top Performing Guides */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Star className="mr-2" size={20} />
                  Top Performing Guides
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {guidePerformance?.slice(0, 5).map((guide: any, index: number) => (
                    <div key={guide.guideId} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-travel-blue rounded-full flex items-center justify-center text-white font-bold">
                          {index + 1}
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-900">{guide.guideName}</h3>
                          <p className="text-sm text-gray-600">{guide.totalSessions} sessions handled</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <Badge variant={guide.completionRate > 80 ? "default" : "secondary"}>
                          {guide.completionRate}% completion
                        </Badge>
                        <p className="text-sm text-gray-500 mt-1">{guide.totalMessages} messages</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Guide Performance Tab */}
          <TabsContent value="guides" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <Users className="h-8 w-8 text-travel-blue mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{guidePerformance?.length || 0}</p>
                    <p className="text-sm text-gray-600">Total Guides</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <MessageSquare className="h-8 w-8 text-success-green mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">
                      {guidePerformance?.reduce((acc: number, g: any) => acc + g.totalSessions, 0) || 0}
                    </p>
                    <p className="text-sm text-gray-600">Total Sessions</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <TrendingUp className="h-8 w-8 text-warm-orange mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">
                      {Math.round(guidePerformance?.reduce((acc: number, g: any) => acc + g.completionRate, 0) / Math.max(guidePerformance?.length || 1, 1)) || 0}%
                    </p>
                    <p className="text-sm text-gray-600">Avg Completion Rate</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Guide Performance Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {guidePerformance?.map((guide: any) => (
                    <div key={guide.guideId} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-semibold text-gray-900">{guide.guideName}</h3>
                        <Badge variant={guide.completionRate > 80 ? "default" : "secondary"}>
                          {guide.completionRate}% completion
                        </Badge>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600">Total Sessions</p>
                          <p className="font-medium">{guide.totalSessions}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Messages Sent</p>
                          <p className="font-medium">{guide.totalMessages}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Avg Response Time</p>
                          <p className="font-medium">{guide.avgResponseTime}m</p>
                        </div>
                      </div>
                      {Object.keys(guide.categories || {}).length > 0 && (
                        <div className="mt-3">
                          <p className="text-sm text-gray-600 mb-2">Categories Handled:</p>
                          <div className="flex flex-wrap gap-1">
                            {Object.entries(guide.categories || {}).map(([category, count]: [string, any]) => (
                              <Badge key={category} variant="outline" className="text-xs">
                                {category}: {count}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Chat Volume Tab */}
          <TabsContent value="volume" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <MessageSquare className="h-8 w-8 text-travel-blue mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{chatVolume?.totalSessions || 0}</p>
                    <p className="text-sm text-gray-600">Total Sessions</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <Activity className="h-8 w-8 text-success-green mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{chatVolume?.totalMessages || 0}</p>
                    <p className="text-sm text-gray-600">Total Messages</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <Clock className="h-8 w-8 text-warm-orange mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{formatTimeHour(chatVolume?.peakHour || 0)}</p>
                    <p className="text-sm text-gray-600">Peak Hour</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Hourly Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-6 md:grid-cols-12 gap-2 text-xs">
                  {(chatVolume?.hourlyDistribution || []).map((item: any) => (
                    <div key={item.hour} className="text-center">
                      <div className="bg-gray-200 rounded h-16 flex items-end justify-center mb-1">
                        <div 
                          className="bg-travel-blue rounded-t w-full"
                          style={{ height: `${Math.max((item.count / Math.max(...(chatVolume?.hourlyDistribution || []).map((h: any) => h.count), 1)) * 100, 2)}%` }}
                        ></div>
                      </div>
                      <p className="text-gray-600">{item.hour}h</p>
                      <p className="font-medium">{item.count}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Hotel Activity Tab */}
          <TabsContent value="hotels" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <Building2 className="h-8 w-8 text-travel-blue mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">{hotelActivity?.length || 0}</p>
                    <p className="text-sm text-gray-600">Total Hotels</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <MessageSquare className="h-8 w-8 text-success-green mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">
                      {hotelActivity?.reduce((acc: number, h: any) => acc + h.totalSessions, 0) || 0}
                    </p>
                    <p className="text-sm text-gray-600">Total Sessions</p>
                  </div>
                </CardContent>
              </Card>
              <Card>
                <CardContent className="p-6">
                  <div className="text-center">
                    <Users className="h-8 w-8 text-warm-orange mx-auto mb-2" />
                    <p className="text-2xl font-bold text-gray-900">
                      {hotelActivity?.reduce((acc: number, h: any) => acc + h.assignedGuides, 0) || 0}
                    </p>
                    <p className="text-sm text-gray-600">Assigned Guides</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Hotel Activity Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {hotelActivity?.map((hotel: any) => (
                    <div key={hotel.hotelId} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <h3 className="font-semibold text-gray-900">{hotel.hotelName}</h3>
                        <Badge variant="outline">
                          {hotel.totalSessions} sessions
                        </Badge>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-gray-600">Assigned Guides</p>
                          <p className="font-medium">{hotel.assignedGuides}</p>
                        </div>
                        <div>
                          <p className="text-gray-600">Chat Sessions</p>
                          <p className="font-medium">{hotel.totalSessions}</p>
                        </div>
                      </div>
                      {Object.keys(hotel.categories || {}).length > 0 && (
                        <div className="mt-3">
                          <p className="text-sm text-gray-600 mb-2">Request Categories:</p>
                          <div className="flex flex-wrap gap-1">
                            {Object.entries(hotel.categories || {}).map(([category, count]: [string, any]) => (
                              <Badge key={category} variant="outline" className="text-xs">
                                {category}: {count}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}