export default function BasicHome() {
  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <div className="max-w-4xl mx-auto">
        
        {/* Header */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">TourGuide Chat</h1>
          <p className="text-gray-600">24/7 Travel Assistance</p>
          <div className="mt-4 space-x-4">
            <a href="/guide-dashboard" className="inline-block px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
              Guide Dashboard
            </a>
            <a href="/admin" className="inline-block px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700">
              Admin
            </a>
          </div>
        </div>

        {/* Categories */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Select a Category</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            <div className="p-4 border border-gray-200 rounded-lg hover:border-blue-500 cursor-pointer">
              <h3 className="font-medium text-gray-900">Hotel Change</h3>
              <p className="text-sm text-gray-600">Need assistance with changing your hotel booking</p>
            </div>

            <div className="p-4 border border-gray-200 rounded-lg hover:border-orange-500 cursor-pointer">
              <h3 className="font-medium text-gray-900">Hotel Complain</h3>
              <p className="text-sm text-gray-600">Report issues with your current accommodation</p>
            </div>

            <div className="p-4 border border-gray-200 rounded-lg hover:border-green-500 cursor-pointer">
              <h3 className="font-medium text-gray-900">Booking Tours</h3>
              <p className="text-sm text-gray-600">Book exciting tours and activities</p>
            </div>

            <div className="p-4 border border-gray-200 rounded-lg hover:border-red-500 cursor-pointer">
              <h3 className="font-medium text-gray-900">Need a Doctor</h3>
              <p className="text-sm text-gray-600">Medical assistance and healthcare services</p>
            </div>

            <div className="p-4 border border-gray-200 rounded-lg hover:border-purple-500 cursor-pointer">
              <h3 className="font-medium text-gray-900">Need Guide Assistant</h3>
              <p className="text-sm text-gray-600">General assistance and local guidance</p>
            </div>

          </div>
        </div>

        {/* Chat Area */}
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Chat Interface</h2>
          <div className="h-64 bg-gray-50 rounded border p-4 flex items-center justify-center">
            <p className="text-gray-600">Select a category above to start chatting with our guides</p>
          </div>
        </div>

      </div>
    </div>
  );
}