import { Link } from "wouter";
import { ArrowLeft, BarChart3 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function AdminDashboardMinimal() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg p-6">
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="mr-2" size={16} />
                Back to Chat
              </Button>
            </Link>

            <div className="flex items-center gap-4">
              <div>
                <h1 className="text-xl font-bold text-gray-900">Admin Dashboard</h1>
                <p className="text-sm text-gray-600">Tourism Guide Management</p>
              </div>
              
              <Link href="/admin-analytics">
                <Button variant="outline" size="sm">
                  <BarChart3 className="mr-2" size={16} />
                  Analytics
                </Button>
              </Link>
            </div>
          </div>

          {/* Simple content */}
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg">
              <h2 className="text-lg font-semibold mb-2">Guide Management</h2>
              <p className="text-gray-600">Manage your tourism guides and their assignments.</p>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <h2 className="text-lg font-semibold mb-2">Hotel Management</h2>
              <p className="text-gray-600">Manage hotel partnerships and assignments.</p>
            </div>
            
            <div className="bg-gray-50 p-4 rounded-lg">
              <h2 className="text-lg font-semibold mb-2">System Status</h2>
              <p className="text-gray-600">Everything is running smoothly.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}