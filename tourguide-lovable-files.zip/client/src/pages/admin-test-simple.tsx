export default function AdminTestSimple() {
  return (
    <div style={{ padding: "20px" }}>
      <h1>Admin Dashboard Test</h1>
      <p>This is a simple test page to verify the route is working.</p>
      <div style={{ backgroundColor: "#f0f0f0", padding: "20px", borderRadius: "8px" }}>
        <h2>If you can see this, the routing is working!</h2>
        <p>The admin route is functioning correctly.</p>
      </div>
    </div>
  );
}