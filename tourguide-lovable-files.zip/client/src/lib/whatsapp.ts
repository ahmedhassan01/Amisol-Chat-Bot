interface WhatsAppContact {
  id: number;
  name: string;
  type: string;
  phone?: string;
  whatsappNumber?: string;
  isActive: boolean;
}

interface WhatsAppMessage {
  contactType: string;
  message: string;
  urgency?: 'low' | 'medium' | 'high' | 'emergency';
}

interface WhatsAppResponse {
  success: boolean;
  whatsappUrl?: string;
  contact?: WhatsAppContact;
  error?: string;
}

/**
 * Generate a WhatsApp URL for direct messaging
 */
export function generateWhatsAppUrl(phoneNumber: string, message: string): string {
  // Remove any non-numeric characters except +
  const cleanNumber = phoneNumber.replace(/[^\d+]/g, '');
  
  // Encode the message for URL
  const encodedMessage = encodeURIComponent(message);
  
  return `https://wa.me/${cleanNumber}?text=${encodedMessage}`;
}

/**
 * Send an emergency message via WhatsApp
 */
export async function sendEmergencyWhatsApp(
  contactType: 'medical' | 'guide-manager' | 'general',
  customMessage?: string
): Promise<WhatsAppResponse> {
  try {
    const defaultMessages = {
      medical: "🚨 EMERGENCY: Medical assistance required urgently. Tourist needs immediate help. Please respond ASAP.",
      'guide-manager': "📞 URGENT: Guide assistance needed. Tourist requires immediate support from management.",
      general: "ℹ️ ASSISTANCE: Tourist needs help with their travel arrangements. Please provide support."
    };

    const message = customMessage || defaultMessages[contactType];

    const response = await fetch('/api/whatsapp/emergency', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        contactType,
        message,
        timestamp: new Date().toISOString(),
        urgency: contactType === 'medical' ? 'emergency' : 'high'
      }),
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data: WhatsAppResponse = await response.json();
    return data;
  } catch (error) {
    console.error('WhatsApp emergency send error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Failed to send WhatsApp message'
    };
  }
}

/**
 * Open WhatsApp with pre-filled message
 */
export function openWhatsApp(phoneNumber: string, message: string): void {
  const url = generateWhatsAppUrl(phoneNumber, message);
  window.open(url, '_blank', 'noopener,noreferrer');
}

/**
 * Get emergency contact information
 */
export async function getEmergencyContacts(): Promise<WhatsAppContact[]> {
  try {
    const response = await fetch('/api/emergency-contacts');
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error('Error fetching emergency contacts:', error);
    return [];
  }
}

/**
 * Handle medical emergency with automatic WhatsApp integration
 */
export async function handleMedicalEmergency(
  location?: string,
  description?: string
): Promise<boolean> {
  try {
    const emergencyMessage = `🚨 MEDICAL EMERGENCY 🚨

Tourist requires immediate medical assistance.

${location ? `Location: ${location}` : ''}
${description ? `Description: ${description}` : ''}

Time: ${new Date().toLocaleString()}

Please respond immediately with medical support instructions or dispatch emergency services.`;

    const result = await sendEmergencyWhatsApp('medical', emergencyMessage);
    
    if (result.success && result.whatsappUrl) {
      // Auto-open WhatsApp for immediate contact
      window.open(result.whatsappUrl, '_blank', 'noopener,noreferrer');
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('Medical emergency handling error:', error);
    return false;
  }
}

/**
 * Format phone number for WhatsApp
 */
export function formatPhoneForWhatsApp(phone: string): string {
  // Remove all non-numeric characters except +
  let cleaned = phone.replace(/[^\d+]/g, '');
  
  // If number doesn't start with +, assume it needs country code
  if (!cleaned.startsWith('+')) {
    // You might want to add default country code logic here
    // For now, we'll assume international format is provided
    cleaned = '+' + cleaned;
  }
  
  return cleaned;
}

/**
 * Validate WhatsApp number format
 */
export function isValidWhatsAppNumber(phone: string): boolean {
  // Basic validation for international phone number format
  const whatsappRegex = /^\+[1-9]\d{1,14}$/;
  const formatted = formatPhoneForWhatsApp(phone);
  return whatsappRegex.test(formatted);
}

/**
 * Create a comprehensive emergency report
 */
export function createEmergencyReport(data: {
  type: 'medical' | 'security' | 'transport' | 'accommodation';
  severity: 'low' | 'medium' | 'high' | 'critical';
  location?: string;
  description?: string;
  contactInfo?: string;
}): string {
  const { type, severity, location, description, contactInfo } = data;
  
  const severityEmojis = {
    low: 'ℹ️',
    medium: '⚠️', 
    high: '🚨',
    critical: '🆘'
  };

  const typeLabels = {
    medical: 'MEDICAL EMERGENCY',
    security: 'SECURITY INCIDENT', 
    transport: 'TRANSPORT ISSUE',
    accommodation: 'ACCOMMODATION PROBLEM'
  };

  return `${severityEmojis[severity]} ${typeLabels[type]} ${severityEmojis[severity]}

Severity: ${severity.toUpperCase()}
Time: ${new Date().toLocaleString()}
${location ? `Location: ${location}` : ''}
${description ? `Description: ${description}` : ''}
${contactInfo ? `Contact: ${contactInfo}` : ''}

Please provide immediate assistance.

Sent via TourGuide Chat Emergency System`;
}
